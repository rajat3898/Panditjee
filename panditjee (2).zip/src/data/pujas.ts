/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Puja } from '../types';

export const PUJAS_DATA: Puja[] = [
  // SCREEN 1: KUNDALI & CONSULTATIONS (category: 'consultation')
  {
    id: 'kundali_milan',
    title: 'Kundali Milan (Horoscope Matching)',
    sanskritName: 'कुण्डली मिलान- गणना/वर-वधू-कुण्डली मिलान',
    description: 'Detailed Vedic horoscope compatibility rendering (Ashtakoot Guna Milan) to assess marital stability, health, and mutual growth for prospective brides and grooms.',
    benefits: [
      'Checks standard mental, emotional, and physical compatibility.',
      'Identifies presence of Manglik Dosha and provides direct Vedic remedies.',
      'Forecasts family harmony, progeny prospects, and career scaling together.'
    ],
    duration: '45 Minutes',
    standardPrice: 253, // 220 + 15% = 253
    premiumPrice: 450,
    ePujaPrice: 199,
    image: 'https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Bride birth details (Date, precise Time, City)',
      'Groom birth details (Date, precise Time, City)',
      'Current planetary balance notes (if any)'
    ],
    category: 'consultation'
  },
  {
    id: 'kundali_nirman_under18',
    title: 'Kundali Nirman - Under 18 Years (with Predictions)',
    sanskritName: 'कुण्डली निर्माण - भविष्यवाणी के साथ ( हिन्दी में ) 18 वर्ष से कम उम्र वालों के लिए',
    description: 'Special comprehensive natal chart setup for children and teenagers under 18. Provides guidance on health, initial character development, and academic lines in Hindi.',
    benefits: [
      'Maps innate intellectual and academic talents early in life.',
      'Addresses weak planetary periods affecting concentration or health.',
      'Suggests auspicious primary gemstones or educational colors.'
    ],
    duration: '1 Hour',
    standardPrice: 506, // 440 + 15% = 506
    premiumPrice: 899,
    ePujaPrice: 399,
    image: 'https://images.unsplash.com/photo-1543007630-9710e4a00a20?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Exact birth date of the child',
      'Precise birth time (AM/PM)',
      'Location of birth (Patna or other cities)'
    ],
    category: 'consultation'
  },
  {
    id: 'kundali_nirman_adult',
    title: 'Kundali Nirman - Adults (with Predictions)',
    sanskritName: 'कुण्डली निर्माण - भविष्यवाणी के साथ ( हिन्दी में )',
    description: 'The definitive adult Janmapatrika creation with detailed, long-term lifecycle predictions in Hindi, outlining career trajectories, wealth accumulation, and family milestones.',
    benefits: [
      'Calculates exact planetary degrees, Lagna chart, and Navamsha.',
      'Provides standard 120-year Vimshottari Mahadasha timeline charts.',
      'Highlights crucial transition stages, sade-sati impacts, and remedies.'
    ],
    duration: '1 Hour',
    standardPrice: 633, // 550 + 15% = 633
    premiumPrice: 1150,
    ePujaPrice: 499,
    image: 'https://images.unsplash.com/photo-1532156111818-12cd230a6e35?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Full birth birthdate records',
      'Accurate birth time',
      'Accurate birth city'
    ],
    category: 'consultation'
  },
  {
    id: 'jyotish_paramarsh',
    title: 'Jyotish Paramarsh (Palmistry & Horoscope Reading)',
    sanskritName: 'ज्योतिष परामर्श-शुल्क ( हस्तरेखा अथवा जन्म-कुण्डली परीक्षण )',
    description: 'Personalized interactive consultation with our chief acharya. Get solutions on palm lines, recurring bad dreams, blocked finances, or career confusion.',
    benefits: [
      'Direct, compassionate session with remedial focus.',
      'Assesses primary mount lines (life line, head line, fate line/sun line).',
      'Recommends specific, easy-to-do temple pujas or fasts.'
    ],
    duration: '30 Minutes',
    standardPrice: 196, // 170 + 15% = 196
    premiumPrice: 350,
    ePujaPrice: 150,
    image: 'https://images.unsplash.com/photo-1606326608606-aa0b62935f2b?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'High-resolution photo of palms (if virtual)',
      'List of core life questions written down'
    ],
    category: 'consultation'
  },

  // SCREEN 2 & 3: SHIV RUDRABHISHEK VARIATIONS (category: 'puja-archana')
  {
    id: 'rudrabhishek_shravan_monday',
    title: 'Rudrabhishek - Shravan Monday / Mahashivratri Special',
    sanskritName: 'रुद्राभिषेक - सावन सोमवारी/महाशिवरात्रि',
    description: 'Extremely powerful liquid bath offered onto Shivling representing celestial alignment on Mondays of Shravan month or holy Mahashivratri night.',
    benefits: [
      'Attracts divine Shiva-Shakti energies for deep house purification.',
      'Extinguishes chronic family disputes, mental trauma, and stresses.',
      'Enhances positive flow of cosmic luck and spiritual advancement.'
    ],
    duration: '2 Hours',
    standardPrice: 3163, // 2750 + 15% = 3163
    premiumPrice: 4800,
    ePujaPrice: 2100,
    image: 'https://images.unsplash.com/photo-1620121692029-d088224ddc74?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Raw Cow Milk (5 Liters)',
      'Sugarcane juice (1 Liter)',
      'Fresh Honey, Curd, and Desi Ghee',
      'Bael Patra (108 pieces unblemished)',
      'Datura fruit and flowers',
      'Holy Ganga Jal'
    ],
    category: 'puja-archana'
  },
  {
    id: 'rudrabhishek_shravan_other',
    title: 'Rudrabhishek - Other Days in Shravan Month',
    sanskritName: 'रुद्राभिषेक- सावन में अन्य दिन',
    description: 'Daily Shivling abhishekam during the auspicious month of Shravan, maintaining high planetary protective vibes throughout this holy season.',
    benefits: [
      'Cleanses previous blockages and establishes continuous wellness.',
      'Soothes hot tempers and instills great patience in family members.',
      'Excellent for pacifying weak Moon positions in natal charts.'
    ],
    duration: '2 Hours',
    standardPrice: 2657, // 2310 + 15% = 2657
    premiumPrice: 3950,
    ePujaPrice: 1800,
    image: 'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Raw milk & pure honey jars',
      'Bael Patra, Sandalwood paste',
      'Incense sticks & brass ghee lamps',
      'Mandar / Kaner flowers'
    ],
    category: 'puja-archana'
  },
  {
    id: 'rudrabhishek',
    title: 'Rudrabhishek - Mondays & Special Festival Days',
    sanskritName: 'रुद्राभिषेक - सोमवार/विशेष दिन',
    description: 'Traditional liquid stream offering performed on regular Mondays or special scriptural dates (Pradosh, Shivratri, Ekadashi) to attain high celestial grace.',
    benefits: [
      'Establishes deep mental serenity, focus, and cleanses the house aura.',
      'Invokes blessings of the entire Shiva parivar (Ganesha, Gauri, Kartikeya).',
      'Resolves career delays and legal distresses.'
    ],
    duration: '2 Hours',
    standardPrice: 2657, // 2310 + 15% = 2657
    premiumPrice: 3950,
    ePujaPrice: 1800,
    image: 'https://images.unsplash.com/photo-1608976414774-8db9af2b7405?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Ganga Jal, milk, curd, honey, ghee',
      'Bael Patra, sandalwood paste, Janeu pairs',
      'Camphor (Kapoor) and red Kalava thread',
      'Seasonal sweet prasadam'
    ],
    category: 'puja-archana'
  },
  {
    id: 'rudrabhishek_other_days',
    title: 'Rudrabhishek - Normal Weekdays',
    sanskritName: 'रुद्राभिषेक - अन्य दिन',
    description: 'A deeply meditative, calm weekday abhishekam ceremony for quiet domestic peace, regular health maintenance, and continuous cosmic grace.',
    benefits: [
      'Provides a consistent spiritual energy field inside the household.',
      'Calms hyperactive thoughts and enhances educational focusing.',
      'Attracts steady, righteous income channels.'
    ],
    duration: '1.5 Hours',
    standardPrice: 1898, // 1650 + 15% = 1898
    premiumPrice: 2950,
    ePujaPrice: 1350,
    image: 'https://images.unsplash.com/photo-1447069387593-a5de0862481e?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Standard raw panchamrit fluids',
      'Fresh Bilva leaves & flowers',
      'Aromatic dhoop and earthen clay lamp',
      'Sweet sugar rock candy (Mishri)'
    ],
    category: 'puja-archana'
  },
  {
    id: 'maharudrabhishek_3hours',
    title: 'Maha Rudrabhishek (3 Hours Special)',
    sanskritName: 'महारुद्राभिषेक ( तीन घंटा )',
    description: 'An expansive, highly scriptural 3-hour ceremony involving 11 full recitations of Sri Rudram (Rudra-Ekadashini) and highly intensive liquid stream offerings on Shiva Lingam.',
    benefits: [
      'Saves families from serious unexpected health crises or accidents.',
      'Dissolves heavy, long-standing financial debts and commercial losses.',
      'Strongly counters heavy Saturn Dasha effects (Sade Sati, Dhaiya).'
    ],
    duration: '3 Hours',
    standardPrice: 6452, // 5610 + 15% = 6452
    premiumPrice: 9500,
    ePujaPrice: 4500,
    image: 'https://images.unsplash.com/photo-1561542320-9a18cd340469?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Parad / Stone Shivling setup',
      '11 distinct pouring elements (Milk, Sugarcane juice, Honey, Rosewater, etc.)',
      '108 white lotus buds or red hibiscus',
      'Maha-Naiveredhya prasad platters',
      'Complete Havan wood and herbs collection'
    ],
    category: 'puja-archana'
  },
  {
    id: 'satyanarayan',
    title: 'Sri Satyanarayan Puja & Katha',
    sanskritName: 'सत्यनारायण पूजा',
    description: 'Beautiful traditional recitation of Satyanarayan Katha from Skanda Purana devoted to Lord Vishnu. Spreads message of honesty, righteousness, and familial love.',
    benefits: [
      'Establishes deep household peace, mutual trust, and positive mindsets.',
      'Ideally recommended for monthly full moon (Purnima) resolutions.',
      'Safeguards children\'s values and educational progress.'
    ],
    duration: '2 Hours',
    standardPrice: 1392, // 1210 + 15% = 1392
    premiumPrice: 2100,
    ePujaPrice: 950,
    image: 'https://images.unsplash.com/photo-1609137144814-633cf46ceef8?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Sri Satyanarayan Deity photo',
      'Suji Halwa Prasad (prepared with pure cow ghee & sugar)',
      'Raw Bananas and fresh leaves',
      'Panchamrit, dry matchbooks, holy threads'
    ],
    category: 'puja-archana'
  },
  {
    id: 'ramarcha_puja',
    title: 'Sri Ramarcha Puja',
    sanskritName: 'रामार्चा पूजा',
    description: 'An elaborate, grand traditional chanting ceremony dedicated to Lord Rama, Sita Mata, Lakshman ji, Hanuman ji, and the entire divine Ram Darbar court.',
    benefits: [
      'Attracts supreme righteousness, victory over long struggles, and order.',
      'Clears structural court matters and settles property disputes.',
      'Fills family relations with absolute devotion and mutual respect.'
    ],
    duration: '3 Hours',
    standardPrice: 2657, // 2310 + 15% = 2657
    premiumPrice: 3950,
    ePujaPrice: 1800,
    image: 'https://images.unsplash.com/photo-1620121692029-d088224ddc74?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Ram Darbar complete photo set',
      'Saffron (Kesar), yellow sandalwood paste (Chandan)',
      'Fresh Basil (Tulsi leaves) - 108 pieces',
      'Sweet Prasad (Ladoos/Peda)',
      'Red altar cloth & Kalash'
    ],
    category: 'puja-archana'
  },
  {
    id: 'hanumat_puja',
    title: 'Hanumat Puja (Lord Hanuman Worship)',
    sanskritName: 'हनुमत-पूजा',
    description: 'A deeply energized prayer dedicated to Bajrangbali Lord Hanuman. Excellent for generating high motivation, raw physical strength, and spiritual courage.',
    benefits: [
      'Defends the household from bad spirits, nightmares, and chronic fears.',
      'Balances severe planetary blockages of planet Saturn (Shani dev).',
      'Improves self-esteem, self-discipline, and career execution.'
    ],
    duration: '2 Hours',
    standardPrice: 2657, // 2310 + 15% = 2657
    premiumPrice: 3950,
    ePujaPrice: 1800,
    image: 'https://images.unsplash.com/photo-1609137839397-6345b5e33003?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Lord Hanuman copper/clay idol or photo',
      'Pure Jasmine oil (Chameli oil) & orange Sindoor paste',
      'Red hibiscus flowers & garland',
      'Besan Ladoos (6 pieces)',
      'Red sacred flag'
    ],
    category: 'puja-archana'
  },
  {
    id: 'grahashanti_single',
    title: 'Grahashanti Puja (For a Single Planet)',
    sanskritName: 'ग्रहशान्ति पूजा ( एक ग्रह की पूजा ) १ घंटा',
    description: 'Targeted single-planet chanting and homam designed to soothe negative radiation from one specific star (e.g. Rahu dasha, Saturn transit, or combust Jupiter).',
    benefits: [
      'Directly stabilizes high volatility in careers caused by a single planet.',
      'Enhances positive energy flow of the targeted dasha lord.',
      'Minimizes heavy friction in court issues or marital delays.'
    ],
    duration: '1 Hour',
    standardPrice: 2415, // 2100 + 15% = 2415
    premiumPrice: 3500,
    ePujaPrice: 1500,
    image: 'https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Specific color cloth representing the target planet',
      'Specific grain matching the planet (e.g., Black Sesame for Saturn)',
      'Havan wood and cow ghee containers',
      'Navgraha boards'
    ],
    category: 'puja-archana'
  },
  {
    id: 'navgrahshanti',
    title: 'Navgrahashanti Maha Puja (All 9 Planets)',
    sanskritName: 'नवग्रहशान्ति पूजा (सभी ग्रहों की पूजा) ४ घंटा',
    description: 'The definitive 4-hour comprehensive pacification ceremony. Recites sacred Vedic and Puranic mantras for all nine planets to invoke total household protection and balance.',
    benefits: [
      'Relieves intense stress arising from unfavorable Sade Sati or Dhaiya periods.',
      'Unblocks stagnant career progress, property purchases, and health status.',
      'Ensures ultimate peace and auspicious vibrations for all family members.'
    ],
    duration: '4 Hours',
    standardPrice: 12650, // 11000 + 15% = 12650
    premiumPrice: 17500,
    ePujaPrice: 7500,
    image: 'https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Navgraha Chowki and 9 color-coded cloths',
      'Navdhanya (9 types of raw grains representing planets)',
      'Specific samidha branches (Apamarga, Peepal, Shami, etc.)',
      'Camphor, cow ghee, dried coconut halves',
      'Saffron and Asthagandha powders'
    ],
    category: 'puja-archana'
  },
  {
    id: 'grihapravesh',
    title: 'Griha Pravesh Puja',
    sanskritName: 'गृह प्रवेश पूजा एवं वास्तु शांति',
    description: 'A highly sacred ceremony performed before moving into a new home to cleanse negative vibes, satisfy planetary systems, and invite auspicious energies.',
    benefits: [
      'Purifies all five elements of the residence, neutralizing structural faults.',
      'Secures divine protection for dwellers and shields from negative gazes.',
      'Boosts prosperity, health, and standard of living for family members.'
    ],
    duration: '3.5 to 4 Hours',
    standardPrice: 5865, // 5100 * 1.15 = 5865
    premiumPrice: 9775,  // 8500 * 1.15 = 9775
    ePujaPrice: 3565,    // 3100 * 1.15 = 3565
    image: 'https://images.unsplash.com/photo-1561542320-9a18cd340469?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'New Copper Kalash',
      'Fresh Green Coconut',
      'Holy Ganga Jal (pure from Haridwar/Patna)',
      'Panchadhatu (Set of 5 raw metals)',
      'Havan Wood & Dry Mango Pieces',
      'Ashta-gandha paste & Lotus Seeds',
      'Colorful rangoli powder blocks',
      'Sweat prasad / Ladoos',
      'Coin offerings & Red altar cloths',
      'Gau Mutra (purified)'
    ],
    category: 'puja-archana'
  },
  {
    id: 'vastushanti',
    title: 'Vastu Shanti Ceremony',
    sanskritName: 'वास्तु शांति यज्ञ',
    description: 'A structural planetary sacrifice that balances directional anomalies and magnetic disharmony inside offices, apartments, or plots in Patna.',
    benefits: [
      'Reduces architectural friction, enhancing focus and career success.',
      'Soothes domestic friction and recurring business challenges.',
      'Recharges living rooms and work desks with fresh cosmic energy.'
    ],
    duration: '3 Hours',
    standardPrice: 5175, // 4500 * 1.15 = 5175
    premiumPrice: 8165,  // 7100 * 1.15 ~ 8165
    ePujaPrice: 3220,    // 2800 * 1.15 = 3220
    image: 'https://images.unsplash.com/photo-1543007630-9710e4a00a20?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Vastu Purush Idol (Brass / Silver)',
      'Copper Nails & Saffron thread spindles',
      'Havan Kund (highly-durable copper)',
      'Samidha Wood & Ghee containers',
      'Navadhanya (Nine raw planetary grains)',
      'Moss turf & Black Sesame seeds',
      'Supari (Betel nuts) and Paan leaves',
      'Chirag clay lamps',
      'Bael fruit for Purna-ahuti'
    ],
    category: 'puja-archana'
  },
  {
    id: 'ganeshahavan',
    title: 'Vighnaharta Ganesha Havan',
    sanskritName: 'विघ्नहर्ता गणेश हवन',
    description: 'A powerful fire ritual invoking Lord Ganesha before starting any new venture, building project, or career shift to preemptively dissolve hurdles.',
    benefits: [
      'Preemptively eliminates barriers in paperwork, business, or education.',
      'Invites good fortune, intelligence, and organizational synergy.',
      'Bears auspicious fruit for financial security and home expansion.'
    ],
    duration: '2.5 Hours',
    standardPrice: 4025, // 3500 * 1.15 = 4025
    premiumPrice: 6325,  // 5500 * 1.15 = 6325
    ePujaPrice: 2070,    // 1800 * 1.15 = 2070
    image: 'https://images.unsplash.com/photo-1609137839397-6345b5e33003?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Lord Ganesha Idol / Photo',
      'Durva Grass (fresh green sweetgrass)',
      'Modak / Ladoos (Ganesha\'s favorite sweets)',
      'Red Kaner Flowers',
      'Pitted Dates & Cashews (Dry fruits)',
      'Asthagandha paste and Red thread Kalava',
      'Havan Havi mixture (108 precious herbs)',
      'Pure Desi Cow Ghee',
      'Loban dhoop incense'
    ],
    category: 'puja-archana'
  },
  {
    id: 'mrityunjaya',
    title: 'Maha Mrityunjaya Havan',
    sanskritName: 'महा मृत्युंजय हवन एवं जप',
    description: 'Crucial life-saving, age-bestowing fire sacrifice invoking Shiva as Mars-dissolving deity. Conducted to protect sick family members from terminal crises.',
    benefits: [
      'Offsets unexpected physical risks and heals critical underlying ailments.',
      'Infuses psychological strength and resolves subconscious phobias.',
      'Acts as a strong astrological shield during volatile planetary Dashas.'
    ],
    duration: '4 to 5 Hours',
    standardPrice: 8625,  // 7500 * 1.15 = 8625
    premiumPrice: 12650, // 11000 * 1.15 = 12650
    ePujaPrice: 5175,    // 4500 * 1.15 = 5175
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Rudraksha Malas (for consecrated chanting)',
      'Maha-mrityunjaya yantra board',
      'Giloy stems (herbal nectar stems)',
      'Black Sesame seeds',
      'Durva grass bundle',
      'Pure honey jars',
      'Spoon setups for Continuous Ghee streams',
      'Sweet Guggal dust & Loban bits',
      'Panchamrit preparation',
      'Yellow mustard seed blocks (Sarso)'
    ],
    category: 'puja-archana'
  },
  {
    id: 'vivah',
    title: 'Vedic Vivah Sanskar',
    sanskritName: 'वैदिक विवाह संस्कार',
    description: 'The ancient holy matrimonial ceremony binding two souls through precise scriptural mantras, Pheras around the sacred fire, and final Sindoor Dan.',
    benefits: [
      'Chants seven holy vows to establish life-long emotional and physical harmony.',
      'Invokes blessings of ancestral lineages (Gotras) and cosmic creators.',
      'Establishes a balanced, peaceful, and spiritually inclined household.'
    ],
    duration: '5 to 6 Hours',
    standardPrice: 12650, // 11000 * 1.15 = 12650
    premiumPrice: 20700, // 18000 * 1.15 = 20700
    ePujaPrice: 8625,    // 7500 * 1.15 = 8625
    image: 'https://images.unsplash.com/photo-1607190074257-dd4b7af0309f?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Gathbandhan Sacred shawl set',
      'Sindoor (Pure Bihar vermilion)',
      'Laja (Puffed rice grain bowls for fire)',
      'Madhuparka bowls',
      'Saptapadi walking blocks (7 small platforms)',
      'Haldi paste & Mehendi cones',
      'Garlands (Jaimala) of fresh flowers',
      'Havan materials & sacred firewood logs',
      'Gold/Silver coin for Varuna Puja'
    ],
    category: 'puja-archana'
  },
  {
    id: 'kaalsarp',
    title: 'Kaal Sarp Dosh Nivaran',
    sanskritName: 'कालसर्प दोष निवारण पूजा',
    description: 'A dedicated redemption worship designed to free individuals from the grip of Rahu and Ketu, ensuring life blocks and high friction are neutralized.',
    benefits: [
      'Restores steady career progress and clears sudden relationship tension.',
      'Guards against mental distress, constant bad dreams, and unrest.',
      'Saves effort and gains from being lost to continuous delays.'
    ],
    duration: '3.5 Hours',
    standardPrice: 6325, // 5500 * 1.15 = 6325
    premiumPrice: 9430,  // 8200 * 1.15 ~ 9430
    ePujaPrice: 4025,    // 3500 * 1.15 = 4025
    image: 'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Pair of copper/silver Nag and Nagin idols',
      'Conch shell (Shankha)',
      'Black sesame, barley (jau) and black gram',
      'Saffron threads & Milk baths',
      'Lotus root powder',
      'Darbha grass rope',
      'Vedic copper kalash set',
      'Nageshwar mantra yantra sheets',
      'Sandalwood, camphor incense'
    ],
    category: 'puja-archana'
  },
  {
    id: 'chhathspecial',
    title: 'Chhath Puja Mahaparv Vrat Special',
    sanskritName: 'छठ पूजा विशेष महाअनुष्ठान',
    description: 'The ancient Vedic ritual centering worship of the Sun God (Surya Devta) and Chhathi Maiya, traditionally originating from the heart of Bihar.',
    benefits: [
      'Brings unparalleled health, skin rejuvenation, and physical energy.',
      'Secures extreme child protection, intelligence, and family welfare.',
      'Aligns your family directly with planetary lifeforce and solar energy.'
    ],
    duration: 'Multi-day custom support',
    standardPrice: 7475, // 6500 * 1.15 = 7475
    premiumPrice: 11385, // 9900 * 1.15 ~ 11385
    ePujaPrice: 4485,    // 3900 * 1.15 ~ 4485
    image: 'https://images.unsplash.com/photo-1616036740257-9449ea1f6605?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Bamboo Soop & Daura baskets',
      'Thekua flour, pure jaggery, organic ghee',
      'Sugarcane stalks with leaves',
      'Raddish, Raw Turmeric rhizomes',
      'Sutni, Sweet Potato, Dab coconut',
      'Sindoor (Patna premium vermilion)',
      'Ganga Jal, brass pitchers (Lota)',
      'Dhooop, dry coconut bowls'
    ],
    category: 'puja-archana'
  },

  // SCREEN 3 & 4 DETAILS: JAP & PATH (category: 'jap-path')
  {
    id: 'hanumanchalisa_108',
    title: 'Hanuman Chalisa Path (108 Recitations)',
    sanskritName: 'हनुमानचालीसा पाठ ( १०८ पाठ )',
    description: 'An intensely energetic recitation of the legendary Hanuman Chalisa 108 times by a group of certified Vedic priests. Fills your place with amazing holy soundwaves.',
    benefits: [
      'Establishes an impenetrable spiritual defense against bad alignments.',
      'Calms severe psychological anxieties, nervous tension, and phobias.',
      'Fosters intense self-discipline, success in goals, and good sleep.'
    ],
    duration: '4 Hours',
    standardPrice: 1392, // 1210 + 15% = 1392
    premiumPrice: 2100,
    ePujaPrice: 950,
    image: 'https://images.unsplash.com/photo-1609137839397-6345b5e33003?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Lord Hanuman picture / altar',
      'Besan Boondi sweets / Prasad',
      'Red flowers, garlands, and vermilion',
      'Large oil lamp and matches'
    ],
    category: 'jap-path'
  },
  {
    id: 'stotra_kavach_path',
    title: 'Stotra / Kavach / Aditya Hridaya Path',
    sanskritName: 'रामरक्षास्तोत्र/हनुमत कवच/आदित्य हृदय पाठ/अन्य पाठ ( एक पाठ )',
    description: 'Specialized continuous chanting of selected shielding shields like Ramraksha Stotra, Hanumat Kavach, or Aditya Hridaya Path for success and health.',
    benefits: [
      'Sparks high mental courage and direct victory over administrative blocks.',
      'Clears continuous feeling of listlessness, building active solar life energy.',
      'Neutralizes the effect of bad glances and psychological worries.'
    ],
    duration: '1 Hour',
    standardPrice: 322, // 280 + 15% = 322
    premiumPrice: 600,
    ePujaPrice: 251,
    image: 'https://images.unsplash.com/photo-1543007630-9710e4a00a20?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Scripture book of the chosen path (e.g., Ramraksha booklet)',
      'Water vessel (lota) & mango leaf',
      'Roli, sandal, and yellow flowers'
    ],
    category: 'jap-path'
  },
  {
    id: 'sunderkand_single_path',
    title: 'Sunderkand Path (Single Recitation)',
    sanskritName: 'सुन्दरकाण्ड पाठ ( एक पाठ )',
    description: 'Devoted traditional chanting of the Sunderkand chapter from Ramcharitmanas, describing Bajrangbali\'s intelligence and dynamic actions to establish positivity.',
    benefits: [
      'Wipes out deep fears and replaces them with pure self-belief.',
      'Auspicious for child welfare, academic progress, and sound sleep.',
      'Soothes structural tensions in marital domains.'
    ],
    duration: '1.5 Hours',
    standardPrice: 322, // 280 + 15% = 322
    premiumPrice: 600,
    ePujaPrice: 251,
    image: 'https://images.unsplash.com/photo-1609137839397-6345b5e33003?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Srimad Ramcharitmanas scripture text',
      'Lord Rama & Hanuman pictures',
      'Incense dhoop, ghee and sugar crystals',
      'Tulsi sprigs and red hibiscus'
    ],
    category: 'jap-path'
  },
  {
    id: 'valmiki_sunderkand_path',
    title: 'Srimad Valmiki Sunderkand Path',
    sanskritName: 'वाल्मीकि सुन्दरकाण्ड ( एक पाठ )',
    description: 'Premium chanting of Sunderkand in its original classical Sanskrit verses as composed by Sage Valmiki. Unleashes profound, classical spiritual frequencies of success.',
    benefits: [
      'Extremely powerful scriptural resonance to settle immense blockages.',
      'Develops pristine eloquence of speech, memory, and cognitive focus.',
      'Brings deep success in major career ventures and long court disputes.'
    ],
    duration: '3 Hours',
    standardPrice: 2657, // 2310 + 15% = 2657
    premiumPrice: 3950,
    ePujaPrice: 1800,
    image: 'https://images.unsplash.com/photo-1532156111818-12cd230a6e35?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Original Sanskrit Valmiki Ramayana scripture copy',
      'Yellow/Golden cloth decoration for altar',
      'Fresh fruit basket & nuts',
      'Camphor holder & brass ghee lamp'
    ],
    category: 'jap-path'
  },
  {
    id: 'durga_saptashati_samput',
    title: 'Durga Saptashati Path (With Samput)',
    sanskritName: 'दुर्गासप्तशती पाठ ( सम्पुट )',
    description: 'The supreme scriptural path of 700 verses of Devi Mahatmya, customized with specific target mantras (Samput) chanted by specialized priests to resolve severe hardships.',
    benefits: [
      'Provides absolute protection against physical threats and life risks.',
      'Clears massive family blockages and legal disputes beautifully.',
      'Overthrows dark energies and malicious cosmic glances.'
    ],
    duration: '4 Hours',
    standardPrice: 2657, // 2310 + 15% = 2657
    premiumPrice: 3950,
    ePujaPrice: 1800,
    image: 'https://images.unsplash.com/photo-1616036740257-9449ea1f6605?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Durga Saptashati Holy Scripture',
      'Goddess Durga photo/idol with red clothing',
      'Coconut wrapped in red kalava thread',
      'Red kumkum, whole cloves, cardamoms, and dry fruits'
    ],
    category: 'jap-path'
  },
  {
    id: 'durga_saptashati_sadharan',
    title: 'Durga Saptashati Path (Normal Recitation)',
    sanskritName: 'दुर्गासप्तशती पाठ साधारण',
    description: 'A complete regular recitation of the sacred Devi Mahatmya chapters declaring the victories of ancient Mother Durga over dark demonic forces.',
    benefits: [
      'Brings high active energy levels and removes spiritual lethargy.',
      'Restores active happiness and filters bad vibes from rooms.',
      'Grasps peace and career opportunities.'
    ],
    duration: '2.5 Hours',
    standardPrice: 1277, // 1110 + 15% = 1277
    premiumPrice: 1999,
    ePujaPrice: 850,
    image: 'https://images.unsplash.com/photo-1561542320-9a18cd340469?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Durga Saptashati book',
      'Sandal paste, rice grains, red flowers',
      'Earthen lamp with pure sesame oil or ghee'
    ],
    category: 'jap-path'
  },
  {
    id: 'kalash_sthapan_durga_path_9days',
    title: 'Kalash Sthapan with 9-Day Durga Path',
    sanskritName: 'कलशस्थापन/दुर्गा पाठ सहित ( नौ दिन )',
    description: 'Comprehensive 9-day grand Navratri ceremony. Includes holy Kalash Sthapan on sandy soil, barley seed sowing, Akhand Jyot, and systematic daily recitations.',
    benefits: [
      'Imbues your living spaces with legendary positive vibrations.',
      'Grants profound ancestral blessings and long-term business success.',
      'Brings deep fulfillment of cherished personal wishes.'
    ],
    duration: '9 Days (Daily recitations)',
    standardPrice: 9488, // 8250 + 15% = 9488
    premiumPrice: 14500,
    ePujaPrice: 6500,
    image: 'https://images.unsplash.com/photo-1616036740257-9449ea1f6605?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Copper/Clay large Kalash and raw clay',
      'Barley grains (Jau) for sowing',
      'Fully complete Sringar kit for Goddess Durga (comb, mirror, bindi, bangle, etc.)',
      'Whole dry coconut (Gola) with dry husk intact',
      'Pure brass Akhand Deepak'
    ],
    category: 'jap-path'
  },
  {
    id: 'manokamna_yajna',
    title: 'Manokamna Yajna (Wish-Fulfill Sacrifice)',
    sanskritName: 'मनोकामना यज्ञ',
    description: 'A customized, powerful fire sacrifice (havan) targeting personal dreams (e.g. business expansion, purchasing a house, or marital union).',
    benefits: [
      'Fuels speedy development of desired career milestones.',
      'Overcomes hidden karmic inertia that holds back successes.',
      'Cultivates sharp spiritual alignment and deep mental happiness.'
    ],
    duration: '3 Hours',
    standardPrice: 6452, // 5610 + 15% = 6452
    premiumPrice: 9500,
    ePujaPrice: 4500,
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Clean copper Havan Kund',
      'Havan Wood (Mango/Sandal pieces) & pure ghee container (2 Liters)',
      'Precious dry herbs matching your aspirations (lotus seeds, sweet guggal)',
      'Damp coconut halves'
    ],
    category: 'jap-path'
  },
  {
    id: 'janmangalanusthan',
    title: 'Janmangalanusthan (Birthday Divine Ceremony)',
    sanskritName: 'जन्ममंगलानुष्ठान',
    description: 'A dynamic, high-vibrational birthday ceremony invoking the eight legendary immortals (Ashta Chiranjivi) for outstanding health, long life, and academic focus.',
    benefits: [
      'Repels sudden unexpected physical dangers or chronic childhood sickness.',
      'Saturates the mindset of the student with deep learning focus.',
      'Generates outstanding fortune and shields from malicious glances.'
    ],
    duration: '2 Hours',
    standardPrice: 1392, // 1210 + 15% = 1392
    premiumPrice: 2100,
    ePujaPrice: 950,
    image: 'https://images.unsplash.com/photo-1543007630-9710e4a00a20?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Altar photos of the Ashta Chiranjivis',
      'Seasonal dry fruits & fresh sweet ladoos',
      'Yellow mustard seeds (Sarso) for environmental shield',
      'Sacred defense thread (Mauli kalava)'
    ],
    category: 'jap-path'
  },
  {
    id: 'dhwaj_sankalp',
    title: 'Dhwaj Sankalp (Vedic Flag Consecration)',
    sanskritName: 'ध्वज संकल्प',
    description: 'Auspicious consecration and hoisting of public banners and flags (featuring Hanuman ji or divine icons) at the rooftop of houses or shop gates to invite triumph.',
    benefits: [
      'Signifies spiritual victory of good forces over immediate negativity.',
      'Protects property against evil projections and commercial losses.',
      'Brings great fame and respect in public and administrative lines.'
    ],
    duration: '30 Minutes',
    standardPrice: 138, // 120 + 15% = 138
    premiumPrice: 300,
    ePujaPrice: 99,
    image: 'https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Triangular sacred flag (Saffron or yellow)',
      'Bamboo flag pole',
      'Vermilion paste, uncooked rice, whole betel nut',
      'Sweet offerings'
    ],
    category: 'jap-path'
  },
  {
    id: 'mundan_no_music',
    title: 'Vedic Mundan Sanskar (Quiet Tonsure)',
    sanskritName: 'मुण्डन ( बाजा नहीं बजेगा )',
    description: 'Graceful, highly-peaceful baby tonsure ceremony focused on traditional chants and gentle fire prayers, keeping the ceremony quiet without loud bands.',
    benefits: [
      'Purges structural previous birth blockages from child\'s hair strands.',
      'Keeps the baby completely serene, avoiding excessive trauma of loud music.',
      'Boosts brain temperature balance and healthy regular hair growth.'
    ],
    duration: '1.5 Hours',
    standardPrice: 633, // 550 + 15% = 633
    premiumPrice: 1200,
    ePujaPrice: 450,
    image: 'https://images.unsplash.com/photo-1561542320-9a18cd340469?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Sacred copper plate for tonsuring',
      'Unused sterile razor (provided by of sanitized barber)',
      'Fresh cow milk, curd, and pure turmeric paste for skin soothing',
      'New white cotton baby clothes'
    ],
    category: 'jap-path'
  },
  {
    id: 'ramavat_diksha',
    title: 'Ramavat Sampraday Holy Diksha Initiation',
    sanskritName: 'रामावत सम्प्रदाय में दीक्षा',
    description: 'Ancient, solemn spiritual initiation into the legendary Ramavat Sampraday under our chief priest, granting holy Ram-Naam mantras and sacred Tulsi beads.',
    benefits: [
      'Links the seeker directly with the holy lineage of Ramanandis.',
      'Establishes permanent self-discipline, speech control, and high ethics.',
      'Awakens immense spiritual focus and dissolves deep ancestral blocks.'
    ],
    duration: '1 Hour',
    standardPrice: 69, // 60 + 15% = 69
    premiumPrice: 150,
    ePujaPrice: 50,
    image: 'https://images.unsplash.com/photo-1532156111818-12cd230a6e35?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      '108-bead genuine Tulsi Japa Mala',
      'Traditional Gopichandan logs for तिलक dhar',
      'Saffron silk scarf offering for the Guru'
    ],
    category: 'jap-path'
  },
  {
    id: 'mahamrityunjaya_jap_per_thousand',
    title: 'Maha Mrityunjaya & Planetary Jap (Per 1,000 Chants)',
    sanskritName: 'महामृत्युंजय जप/अन्य ग्रह जप ( संकल्प एवं हवन के समय यजमान की उपस्थिति आवश्यक है )',
    description: 'Systematic Vedic chanting of Maha Mrityunjaya or other targeted planetary mantras in multiples of 1,000 counts. Devotee\'s presence during Sankalp & final Havan is mandatory.',
    benefits: [
      'Dashes out intense physical threats and rejuvenates life energy.',
      'Safeguards against bad planetary phases (grah dasha changes).',
      'Instills massive cosmic confidence to withstand severe stress.'
    ],
    duration: 'Chants based (Flexible)',
    standardPrice: 380, // 330 + 15% = 380
    premiumPrice: 750,
    ePujaPrice: 250,
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Rudraksha chanting malas',
      'Wooden counting monitoring board',
      'Havan wood & custom therapeutic herbs mixtures'
    ],
    category: 'jap-path'
  },
  {
    id: 'pind_daan_gaya_patna',
    title: 'Pind Daan & Tarpan Seva (Gaya / Patna)',
    sanskritName: 'पिंडदान एवं महातर्पण सेवा (गयाजी / पटना गंगा घाट)',
    description: 'Complete Vedic ancestral rites conducted on the banks of the sacred Falgu River in Gaya or Ghats of Patna (Holy Ganga). Includes Pitra Tarpan, Pinda offerings (custom barley-flour and sesame mixtures), and worship of ancestral deities led by specialized Panda priests to liberate departed souls.',
    benefits: [
      'Grants eternal salvation (Moksha) and extreme satisfaction to departed ancestors.',
      'Strongly pacifies severe Pitra Dosha in natal charts, restoring peace, children\'s success, and family wealth.',
      'Includes traditional Brahmin Bhojan, Vastradaan, and priest Dakshina for a complete ritual.'
    ],
    duration: '3 Hours',
    standardPrice: 5175, // 4500 + 15% = 5175
    premiumPrice: 8625,  // 7500 + 15% = 8625
    ePujaPrice: 3565,    // 3100 + 15% = 3565
    image: 'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Barley Flour (Jau ka Atta)',
      'Black Sesame seeds (Kala Til)',
      'Pure Honey and Cow Ghee',
      'Darbha Grass (Kusha)',
      'Sandalwood Powder (Chandan)',
      'Raw Rice and Gangajal',
      'White sweets (for Pinda Bhog)',
      'Sacred white thread threads'
    ],
    category: 'ancestor-rites'
  },
  {
    id: 'tripindi_shradh_varshik',
    title: 'Varshik Shradh & Tripindi Shradh Karma',
    sanskritName: 'वार्षिक श्राद्ध / त्रिपिंडी श्राद्ध कर्म',
    description: 'A highly specialized, complete Pitru Shradh honoring three generations of ancestors. Perfect for the annual death anniversary (Varshik Shradh) or resolving severe ancestral blockages (Tripindi Shradh) through sacred fire (Homam), Tarpan, and customized Brahmin charity.',
    benefits: [
      'Dissolves recurring professional delays, health struggles, or business blockages caused by unappeased souls.',
      'Washes away obstacles in lineage growth and child development.',
      'Saturates the home atmosphere with extreme positive energy and continuous ancestral cover.'
    ],
    duration: '4 Hours',
    standardPrice: 4025, // 3500 + 15% = 4025
    premiumPrice: 6900,  // 6000 + 15% = 6900
    ePujaPrice: 2510,    // 2180 + 15% = 2510
    image: 'https://images.unsplash.com/photo-1532156111818-12cd230a6e35?q=80&w=600&auto=format&fit=crop',
    samagriChecklist: [
      'Kusha grass rings (pavitri)',
      'Barley and sesame bags',
      'Traditional Havan wood (Mango/Bael)',
      'Panchamrit (Milk, Curd, Honey, Ghee, Sugar)',
      'Brahmin Bhojan ingredients set',
      'Daan items (White cloth, Umbrella, Ghee lamp)',
      'Black sesame seeds and camphor packets'
    ],
    category: 'ancestor-rites'
  }
];
