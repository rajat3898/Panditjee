/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { TravelDestination } from '../types';

export function getHotelStayByPrice(price: number): string {
  if (price < 6000) {
    return '2-Star Comfortable AC Guesthouse / Traditional Ashram';
  } else if (price < 15000) {
    return '3-Star Premium AC Hotel with modern pilgrim amenities';
  } else if (price < 30000) {
    return '4-Star Elegant Premium Hotel or Private Scenic Resort';
  } else {
    return '5-Star Ultra-Luxury Heritage Palace, Elite Resort or Royal Suites';
  }
}

export const RAW_TRAVEL_DESTINATIONS_DATA: any[] = [
  // 12 Jyotirlingas
  {
    id: 'baidyanath',
    name: 'Baba Baidyanath Dham (Deoghar)',
    location: 'Deoghar, Jharkhand (Near Bihar)',
    category: 'jyotirlinga',
    description: 'One of the highly revered 12 Jyotirlingas, where Ravana offering his heads received boons. Highly popular for Kanwar Yatra from Ganga banks at Sultanganj.',
    significance: 'Prasad offerings and Hridaya Peeth (conjoined Shakti Peeth & Jyotirlinga). Bring holy Ganga Jal to the holy lingam.',
    image: 'https://images.unsplash.com/photo-1616036740257-9449ea1f6605?q=80&w=600&auto=format&fit=crop', // River reflecting shrine
    packages: {
      budget: {
        price: 4999,
        stay: 'Premium Pilgrims Dharamshala / AC Room',
        transport: 'Direct AC Sleeper Weekly Train / Luxury Sleeper Coach',
        meals: 'Traditional Satvik North Indian Vegetarian meals',
        pujaIncluded: 'Group Sankalpa with senior native priest',
        inclusions: ['Direct Darshan Queue pass', 'Prasad packet delivery to home', 'Local Patna group assistance']
      },
      premium: {
        price: 9999,
        stay: '3-Star Premium Hotel with modern cooling systems',
        transport: 'Private AC Sedan travel (Patna Door-to-Door)',
        meals: 'Organic Satvik buffet meals (Breakfast & Dinner)',
        pujaIncluded: 'Exclusive Shodashopachara Rudra Abhishek Puja by personal Shastri',
        inclusions: ['VIP Fast-track queue entrance', 'Pooja raw materials included', 'Traditional angavastram shawl gifting', 'Local sightseeing included']
      },
      luxury: {
        price: 24999,
        stay: 'Chowdhury Mansion Heritage Suites / Finest Luxury Resort',
        transport: 'Private Chauffeur-driven Luxury SUV (Innova Crysta, Door-to-Door Patna)',
        meals: 'Unmatched 100% Satvik gourmet dining (Full-board)',
        pujaIncluded: 'Special Silver-Pot Panchamrit Mahaphala Abhishek conducted inside inner sanctum by 3 Acharyas',
        inclusions: ['State VIP Protocol Entrance', 'Silver plate blessed Bilva-patra prasadi', '24/7 personal guide Shastri', 'Home pickup & drop', 'Complimentary Rudraksha bead']
      }
    }
  },
  {
    id: 'kashivishwanath',
    name: 'Kashi Vishwanath Mandir',
    location: 'Varanasi, Uttar Pradesh',
    category: 'jyotirlinga',
    description: 'The golden spire temple on the high banks of Ganga. Lord Shiva\'s eternal dwelling representing moksha and extreme auspiciousness.',
    significance: 'Spiritual heart of India. Offers Ganga Aarti viewing on legendary Dashashwamedh Ghat.',
    image: 'https://images.unsplash.com/photo-1561361058-c24cecae35ca?q=80&w=600&auto=format&fit=crop', // Varanasi boats ghat
    packages: {
      budget: {
        price: 5500,
        stay: 'Neat spiritual ashram close to Ganga',
        transport: 'AC Chair Car / Express train from Patna Junction',
        meals: 'Savoury Banarasi satvik meals & street tea experience',
        pujaIncluded: 'Ganga Sankalpa & Group Abhishek',
        inclusions: ['Shared boat ride for Ganga Aarti', 'General queue queue setup help']
      },
      premium: {
        price: 11500,
        stay: '4-star elegant boutique hotel near Kashi Corridor',
        transport: 'Private Hatchback / Sedan (Patna to Varanasi)',
        meals: 'Fabulous multi-cuisine satvik meals (organic)',
        pujaIncluded: 'Special Vishwanath Sugandh Maha-Abhishek with pristine materials',
        inclusions: ['Reserved VIP fast entry pass through Kashi Corridor', 'Private boat slot for Subah-e-Banaras viewing', 'Banarasi silk souvenir gift']
      },
      luxury: {
        price: 29990,
        stay: 'Brijrama Palace Luxury Heritage Hotel (Taj Heritage luxury classes)',
        transport: 'Premium Luxury Sedan (Mercedes/BMW or Crysta Premium Class)',
        meals: 'Royal Satvik Thali dining overlooking ancient holy stairs',
        pujaIncluded: 'Inner-Sanctum Special Sparsh Maha-Bhisheka Puja with Vedic chants by 5 Sanskrit scholars',
        inclusions: ['State VIP lounge access', 'Exclusive hand-steered luxury boat for Aarti', 'Prasad basket containing organic herbs & dry fruits', 'Sanskrit scholar local host companion']
      }
    }
  },
  {
    id: 'kedarnath',
    name: 'Kedarnath Temple (Himalayas)',
    location: 'Rudraprayag, Uttarakhand',
    category: 'jyotirlinga',
    description: 'The jaw-dropping mountain-wrapped stone temple situated at 11,755 ft. Built by Pandavas, it holds the hump of Lord Shiva in celestial heights.',
    significance: 'Both Jyotirlinga & part of the legendary Char Dham, representing highest cosmic alignment.',
    image: 'https://images.unsplash.com/photo-1626621422470-ee6f2b7b5f54?q=80&w=600&auto=format&fit=crop', // Snowy mountain temples
    packages: {
      budget: {
        price: 12999,
        stay: 'State-run luxury group tents / local homestay near base',
        transport: 'Patna to Haridwar Train + Shared Traveller up to Gaurikund',
        meals: 'Warm, hydrating simple mountain Satvik dishes',
        pujaIncluded: 'Vedic Group Puja around the temple camp',
        inclusions: ['Trekking coordination support', 'Dham registration support']
      },
      premium: {
        price: 26999,
        stay: 'Spacious cozy deluxe heaters hotel room in Phata / Guptkashi',
        transport: 'Private AC cab from Haridwar/Dehradun to Gaurikund + Pony helper booking',
        meals: 'Freshly cooked high-altitude organic meals',
        pujaIncluded: 'Dedicated Bilva-patra archana with family gotra chanting',
        inclusions: ['Pony / Mule charges included', 'VIP Priority Darshan coupon', 'Warm blanket kit provided']
      },
      luxury: {
        price: 69999,
        stay: 'Kedarnath Luxury Premium Cottage Suites / Finest Himalayan Retreat',
        transport: 'Exclusive Helicopter Transfer (Phata/Dehradun to Kedarnath direct)',
        meals: 'Full board multi-course Satvik dining with immunity herbal soups',
        pujaIncluded: 'Auspicious early morning "Maha-Abhishek" inside temple vault with specialized priests',
        inclusions: ['VIP Helicopter landing protocol', 'Helicopter tickets fully sorted', 'Elite porter handling', 'Special woollen shawls and silver blessing coins', 'Emergency medical standby support']
      }
    }
  },
  {
    id: 'somnath',
    name: 'Somnath Jyotirlinga Temple',
    location: 'Veraval, Gujarat',
    category: 'jyotirlinga',
    description: 'The "Shrine Eternal" located on the Arabian Sea shore. Reconstructed seven times, it represents the resilient light of Shiva over time.',
    significance: 'The historical first of the 12 Jyotirlingas. Stunning light and sound show overlooking the ocean spray.',
    image: 'https://images.unsplash.com/photo-1609137144814-633cf46ceef8?q=80&w=600&auto=format&fit=crop', // Temple silhouette sunset
    packages: {
      budget: {
        price: 8999,
        stay: 'Somnath Trust AC Guest Houses close to ocean',
        transport: 'Patna to Ahmedabad Train + AC Express Coach to Somnath',
        meals: 'Traditional Gujarati Satvik Thali dining',
        pujaIncluded: 'Somnath Shardha Archana group chanting',
        inclusions: ['Sound and light show tickets', 'Local guide group help']
      },
      premium: {
        price: 18500,
        stay: 'Lords Inn / 3-Star Ocean-view premium resort',
        transport: 'Private AC Sedan from Rajkot / Diu Airport to Somnath',
        meals: 'Organic multi-cuisine vegetarian catering',
        pujaIncluded: 'Deep Puja Abhishek with pure ocean winds chanting custom gotra',
        inclusions: ['VIP Quick Temple Entry', 'Exclusive beach walking trail', 'Special Somnath silver pendant souvenir']
      },
      luxury: {
        price: 42000,
        stay: 'Somnath Heritage Palace Suites / Finest seaside hotel',
        transport: 'Private Luxury Sedan (Rajkot to Somnath direct) or Diu Flight transit',
        meals: 'Premium Satvik Royal Gujarati dining with sweet saffron delicacies',
        pujaIncluded: 'Special "Mahapuja" and Gangajal Rudrabhishek organized by top state temple board Shastri',
        inclusions: ['Executive state VIP escort', 'VIP front-row seats for sound-light show', 'Purity-certified silver idol gifting', 'Private sea-view deck access']
      }
    }
  },
  {
    id: 'mahakaleshwar',
    name: 'Mahakaleshwar Jyotirlinga (Ujjain)',
    location: 'Ujjain, Madhya Pradesh',
    category: 'jyotirlinga',
    description: 'The unique South-facing (Dakshinamurthi) Swayambhu Pujya Lingam. Famous globally for the divine early-morning "Bhasma Aarti" using holy pyre embers.',
    significance: 'The god of time (Mahakal) residing majestically along Shipra river banks.',
    image: 'https://images.unsplash.com/photo-1543007630-9710e4a00a20?q=80&w=600&auto=format&fit=crop', // Altar elements, fire
    packages: {
      budget: {
        price: 6500,
        stay: 'AC Rooms at decent dharamshala near Mahakal temple',
        transport: 'Patna to Ujjain direct sleeper train booking',
        meals: 'Traditional Satvik MP thali and malwa sweets',
        pujaIncluded: 'Bhasma Aarti registration group assistance',
        inclusions: ['Shipra Ghat holy bath coordinator', 'Quick queue guidelines']
      },
      premium: {
        price: 13500,
        stay: '3-star premium property like Abika Elite or similar',
        transport: 'Patna to Indore flight/3AC train + private Sedan transfer to Ujjain',
        meals: 'Fine organic vegetarian buffet dinners',
        pujaIncluded: 'Confirmed slot for Bhasma Aarti and dedicated Jal-Abhishek',
        inclusions: ['VIP Bhasma Aarti confirmed entry pass', 'Pooja dhoti/sari costume set provided', 'Custom copper kalash kit']
      },
      luxury: {
        price: 32500,
        stay: 'Radisson Blu Hotel Ujjain / Premium Palace Suites',
        transport: 'Indore Airport Luxury Car pick-up and drop (Crysta/Audi)',
        meals: 'Elite traditional Indian Satvik dining options',
        pujaIncluded: 'Exquisite "Maha Rudrabhishek" using 108 herbs, milk, and honey by temple chief Shastris',
        inclusions: ['State guest protocol VIP fast track', 'Front-row seats during Bhasma Aarti', 'Handpicked Rudraksha Mala blessing', 'Personal Sanskrit scholar concierge']
      }
    }
  },
  {
    id: 'mallikarjuna',
    name: 'Mallikarjuna Jyotirlinga Swamy',
    location: 'Srisailam, Andhra Pradesh',
    category: 'jyotirlinga',
    description: 'Located atop the magnificent Nallamala Hills along Krishna river. A unique conjunction of both a Jyotirlinga and a major Shakti Peeth.',
    significance: 'Spiritual peak representing Lord Shiva (Mallikarjuna) and Goddess Parvati (Bhramaramba) together.',
    image: 'https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?q=80&w=600&auto=format&fit=crop', // Sacred design
    packages: {
      budget: {
        price: 9999,
        stay: 'Devasthanam Guest House cottages',
        transport: 'Direct train to Hyderabad + AC Bus group transit to Srisailam',
        meals: 'Warm Satvik South Indian temple vegetarian thalis',
        pujaIncluded: 'Srisailam temple complex gotra sankalpa group puja',
        inclusions: ['Krishna River boating coordination', 'Dharshan quick tokens']
      },
      premium: {
        price: 19999,
        stay: '3-star private boutique resort on hills',
        transport: 'Private flight up to Hyderabad + private AC sedan transit Srisailam',
        meals: 'Pristine organic South-North Satvik delicacies',
        pujaIncluded: 'Exclusive Rudra Homam inside temple complex for planetary benefits',
        inclusions: ['VIP Seeghra Darshan (Priority)', 'Visit to Sakshi Ganapathi & Patala Ganga', 'Blessed temple silks']
      },
      luxury: {
        price: 44500,
        stay: 'Sri Sailam Premium Luxury Hill Chalets',
        transport: 'Chauffeur-driven premium SUV from Hyderabad Airport + private jungle trail escorts',
        meals: 'Luxury traditional Satvik foods served on fresh banana leaves',
        pujaIncluded: 'Auspicious Inner-Garbhagriha Sparsha Darshan & Panchamrut Maha-Abhishek by head archakar',
        inclusions: ['Police protocol VIP entry access', 'Direct temple prasadam and gold-lace vastram gifting', 'Private forest safari excursion', 'Dedicated senior local priest companion']
      }
    }
  },
  {
    id: 'omkareshwar',
    name: 'Omkareshwar Jyotirlinga Temple',
    location: 'Khandwa, Madhya Pradesh',
    category: 'jyotirlinga',
    description: 'An island shrine in the holy Narmada River shaped naturally like the sacred syllable "OM". Extremely calm, scenic, and deeply spiritual.',
    significance: 'Two temples (Omkareshwar and Mamleshwar) split but together constituting the single Jyotirlinga energy.',
    image: 'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?q=80&w=600&auto=format&fit=crop', // River landscape mountains
    packages: {
      budget: {
        price: 5999,
        stay: 'Comfortable Narmada Guest House',
        transport: 'Patna train up to Indore + Shared AC bus to Omkareshwar',
        meals: 'Simple Satvik MP vegetarian meals with buttermilk',
        pujaIncluded: 'River bath sankalpa + group Omkar chanting',
        inclusions: ['Shared motorboat ride with life jackets', 'Quick darshan guide']
      },
      premium: {
        price: 12500,
        stay: 'MPT Temple View Resort (State Premium Property)',
        transport: 'Patna flight to Indore + Private sedan up to Khandwa hills',
        meals: 'Traditional organic buffet options',
        pujaIncluded: 'Special Mamleshwar Sahasra-Lingarchana puja using clay lingams',
        inclusions: ['Private boat charter for Narmada circumambulation', 'VIP temple gate entry pass']
      },
      luxury: {
        price: 31000,
        stay: 'Narmada Luxury Heritage Cottages / Premium Spa retreats',
        transport: 'Indore Airport Luxury Car escort + custom speed-boat river taxi options',
        meals: 'Finest satvik dining, customized health plans',
        pujaIncluded: 'Grand Rudrabhishek with sacred Narmada streams by traditional Vedic scholars',
        inclusions: ['State guest VIP queue protocol', 'Scenic island helicopter view', 'Pure silver OM bracelet blessing', 'Personal spiritual mentor companion']
      }
    }
  },
  {
    id: 'bhimashankar',
    name: 'Bhimashankar Jyotirlinga',
    location: 'Pune, Maharashtra',
    category: 'jyotirlinga',
    description: 'Set in the lush, misty Sahyadri hills, the source of the Bhima River. A divine stone temple adorned with delicate ancient woodwork craftsmanship.',
    significance: 'Guarded by wild animal sanctuaries, representing Shiva in his protective forest form.',
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=600&auto=format&fit=crop', // Forest backdrop
    packages: {
      budget: {
        price: 7999,
        stay: 'Scenic mountain homestay / standard cottage',
        transport: 'Direct train to Pune + group AC bus to Bhimashankar forest',
        meals: 'Authentic Maharashtrian Satvik vegetarian meals',
        pujaIncluded: 'Group gotra sankalpa puja near ancient steps',
        inclusions: ['Forest sanctuary basic walk guide', 'Darshan assistance list']
      },
      premium: {
        price: 16500,
        stay: 'Blue Mormon Jungle Resort / Deluxe mountain villas',
        transport: 'Patna flight to Pune + Private Sedan up to Sahyadri crest',
        meals: 'Organic Satvik farm-to-table vegetarian buffet',
        pujaIncluded: 'Special Laghu-Rudra Abhishek under ancient stone carvings with pristine samagri',
        inclusions: ['VIP Fast Entry card', 'Sightseeing to Gupt Bhimashankar coordinates', 'Traditional dhotar wear blessing']
      },
      luxury: {
        price: 36000,
        stay: 'The Machan Ultra Luxury Resort Lonavala / Forest Valley Suite',
        transport: 'Pune Airport Premium SUV crysta or luxury coach pick-up with personal host',
        meals: 'Aromatic Satvik delicacies with wild mountain herbs',
        pujaIncluded: 'Exquisite Sparsha Abhishek with 108 Bael leaves and silver cobra elements inside peak hours',
        inclusions: ['VIP Protocol State Guard clearance', 'Exclusive botanical private trail with guide', 'Blessed Rudraksha mala with pure gold caps', '24/7 personal travel companion']
      }
    }
  },
  {
    id: 'trimbakeshwar',
    name: 'Trimbakeshwar Jyotirlinga',
    location: 'Nashik, Maharashtra',
    category: 'jyotirlinga',
    description: 'Located at the foothills of Brahmagiri, the birthplace of Godavari River. Features a unique hollowed lingam holding three small faces representing Brahma, Vishnu, and Maheshwar.',
    significance: 'Core center for resolving serious Saturn planetary faults, Pitra Dosh, and Kaal Sarp defects.',
    image: 'https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?q=80&w=600&auto=format&fit=crop', // Sacred altar elements
    packages: {
      budget: {
        price: 7500,
        stay: 'Neat spiritual ashram close to temple steps',
        transport: 'Direct train to Nashik Road / AC Weekly lines',
        meals: 'Maharashtrian Satvik standard lunch/dinner thali',
        pujaIncluded: 'Vedic Kushavarta Tirtha sankalpa bath group',
        inclusions: ['Astrological checkup help from local priest', 'Quick entry tokens']
      },
      premium: {
        price: 15500,
        stay: '3-Star Premium Grape County Resort / Express Nashik Inn',
        transport: 'Patna flight to Mumbai + Private AC sedan transit up to Nashik',
        meals: 'Delicious organic multi-cuisine satvik meals',
        pujaIncluded: 'Special Kaal Sarp Shanti Puja or Tripindi Shradha conducted by registered Trimbak Shastri',
        inclusions: ['VIP Entrance Queue permit', 'All necessary puja metals and cloths provided', 'Nashik vineyard/sightseeing coach']
      },
      luxury: {
        price: 38900,
        stay: 'Radisson Blu Resort Nashik / Premium Heritage Valley Villa',
        transport: 'Mumbai/Nashik Airport Luxury Car pick-up and drop (Crysta/Mercedes)',
        meals: 'Premium Satvik Maharashtrian Panch-Prana Dining (Gold standard)',
        pujaIncluded: 'Auspicious early morning "Maha-Rudra Homam" in designated holy halls with top vedic scholars',
        inclusions: ['State Guest protocol VIP fast entry', 'Prasad basket containing sacred Godavari minerals', 'Personalized Kundli dasha checkup by head desk editor', 'Sanskrit speaking traditional host']
      }
    }
  },
  {
    id: 'nageshwar',
    name: 'Nageshwar Jyotirlinga Mandir',
    location: 'Dwarka, Gujarat',
    category: 'jyotirlinga',
    description: 'The monumental shrine located along Dwarka coastal routes, featuring a giant 82-ft sitting Lord Shiva statue visible across lands.',
    significance: 'Guards you from poison, evil lines, and grants immunity from chronic conditions.',
    image: 'https://images.unsplash.com/photo-1609137839397-6345b5e33003?q=80&w=600&auto=format&fit=crop', // Giant Ganesha or deity statue style
    packages: {
      budget: {
        price: 8500,
        stay: 'Comfortable dharamshala room near Dwarkadhish steps',
        transport: 'Patna to Dwarka Express sleeper train booking',
        meals: 'Gujarati satvik meals and local buttermilk',
        pujaIncluded: 'Group snake-pendant gotra sankalpa puja',
        inclusions: ['Dwarkadhish temple queue guiding help', 'Shared local auto coach']
      },
      premium: {
        price: 17500,
        stay: 'Mercure Dwarka / 3-star deluxe ocean view resort',
        transport: 'Flight up to Jamnagar/Rajkot + private AC sedan transit',
        meals: 'Delicious multi-style organic satvik catering',
        pujaIncluded: 'Dedicated Rudra Abhishek using milk and honey with personal Shastri',
        inclusions: ['VIP Fast Entry ticket', 'Ferry ticket to Bet Dwarka temple', 'Sandalwood fragrant box gift']
      },
      luxury: {
        price: 39500,
        stay: 'Dwarka Beach Heritage Resort Luxury Sea Suite',
        transport: 'Jamnagar Airport Premium Luxury SUV pick-up (Innova Crysta or Audi)',
        meals: 'Custom Satvik Royal culinary catering',
        pujaIncluded: 'Grand Sparsh Abhishek with copper kalash Vedic chants inside holy hours by temple board Shastris',
        inclusions: ['State Guest VIP passes for Nageshwar and Dwarkadhish', 'Private speedboat charter to Beyt Dwarka', 'Blessed gold-plated Trishul talisman', '24/7 personal guide companion']
      }
    }
  },
  {
    id: 'ramanathaswamy',
    name: 'Ramanathaswamy (Rameshwaram)',
    location: 'Rameshwaram, Tamil Nadu',
    category: 'jyotirlinga',
    description: 'The massive temple constructed on Rameshwaram island, featuring India\'s longest, beautifully carved stone corridors. The lingam was sculpted by Goddess Sita and worshipped by Ram.',
    significance: 'Both a prime Jyotirlinga and the Southern edge of Chardham (Moksha Dham). Features 22 holy water wells for bathing.',
    image: 'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?q=80&w=600&auto=format&fit=crop', // Coastal temple geometry
    packages: {
      budget: {
        price: 12500,
        stay: 'Neat private guesthouse close to temple gate',
        transport: 'Direct Sleeper train transit to Madurai / Rameshwaram',
        meals: 'Delicious South Indian satvik tiffin & meals on banana leaves',
        pujaIncluded: '22 Holy Wells bathing coordination with personal guide helper',
        inclusions: ['Pamban Bridge train view coordinator', 'Local auto sightseeing']
      },
      premium: {
        price: 24500,
        stay: 'Daiwik Hotel / Rameshwaram Luxury Inn class',
        transport: 'Flight to Madurai + private AC Sedan Door-to-door transit to Rameshwaram',
        meals: 'Organic Satvik South-North buffet lines',
        pujaIncluded: 'Special Ramanatha Spatika Linga early-dawn dharshan pass & Rudrabhishek',
        inclusions: ['VIP Quick Temple Entry for 22 wells and main lingam', 'Private car to Dhanushkodi (end of India road)', 'Silken angavastram shawl souvenir']
      },
      luxury: {
        price: 52000,
        stay: 'Jiva Resort Rameshwaram / Sea View Luxury Suites',
        transport: 'Madurai Airport Premium SUV Crysta with executive helper desk',
        meals: 'Grand organic Satvik Thali feast served with pristine local ingredients',
        pujaIncluded: 'Inner-sanctum customized Sparsha-Abhishekam with silver pot Ganga Jal carried from Patna',
        inclusions: ['State security VIP protocol queue pass', 'Private luxury guide with direct access', 'Dhanushkodi sunset private customized tour', 'Authenticated solid silver Ram-Sita blessing coin']
      }
    }
  },
  {
    id: 'grishneshwar',
    name: 'Grishneshwar Jyotirlinga Temple',
    location: 'Aurangabad, Maharashtra',
    category: 'jyotirlinga',
    description: 'The final, 12th Jyotirlinga located next to the prehistoric Ellora caves. Constructed using vibrant pink-red sandstone, featuring carvings of gods.',
    significance: 'A sacred site representing the miraculous resurrection of a dead child via devotion.',
    image: 'https://images.unsplash.com/photo-1626621422470-ee6f2b7b5f54?q=80&w=600&auto=format&fit=crop', // Pink sandstone temple look
    packages: {
      budget: {
        price: 7200,
        stay: 'Comfortable hotel room near Ellora road',
        transport: 'Direct train to Aurangabad / Weekly superfast train',
        meals: 'Tasty Maharashtrian vegetarian simple thali',
        pujaIncluded: 'Group gotra sankalpa pujaran helper coordination',
        inclusions: ['Ellora Caves entry ticket (General)', 'Shared local transit']
      },
      premium: {
        price: 14500,
        stay: 'Keys Select / 3-star stylish Aurangabad business hotel',
        transport: 'Patna flight to Aurangabad + private AC hatchback/sedan transfer',
        meals: 'Certified organic healthy satvik buffet dinners',
        pujaIncluded: 'Exclusive Kumkum/Chandan Maha-Archana inside main halls',
        inclusions: ['VIP Fast Entrance access card', 'Guided private tour of Ellora Cave monuments', 'Chandan block souvenir']
      },
      luxury: {
        price: 33500,
        stay: 'Vivanta Aurangabad (Taj Premium Experience) / WelcomeHotel Rama',
        transport: 'Aurangabad Airport Premium SUV Crysta or luxury Mercedes escort',
        meals: 'Aromatic Satvik delicacies served in royal setups',
        pujaIncluded: 'Auspicious Bare-chest inner chamber Vedic Abhishek chanting by head temple priests',
        inclusions: ['High VIP Protocol entrance security lanes', 'Private luxury vehicle for Ellora & Daulatabad sightseeing', 'Beautiful certified miniature Shiva idol ornament gift', 'Dedicated bilingual linguist guide']
      }
    }
  },

  // Char Dham (Moksha Dham)
  {
    id: 'badrinath',
    name: 'Badrinath Dham (Himalayas)',
    location: 'Chamoli, Uttarakhand',
    category: 'chardham',
    description: 'The monumental holy seat of Lord Vishnu (Badrinarayan) nestled between Nara and Narayana mountain ranges. Features a natural warm sulfur spring bath (Tapt Kund) beneath snowy glaciers.',
    significance: 'Northern Dham and part of both Char Dham and Chhota Champak Dham. Grants extreme liberation.',
    image: 'https://images.unsplash.com/photo-1626621422470-ee6f2b7b5f54?q=80&w=600&auto=format&fit=crop', // Snowy peak colorful temple
    packages: {
      budget: {
        price: 13500,
        stay: 'AC pilgrim suites at Badrinath Trust Guest House',
        transport: 'Haridwar Train + shared AC Traveller on winding paths',
        meals: 'Mountain satvik vegetarian foods, hot soups',
        pujaIncluded: 'Tapt Kund holy bath coordination and group sankalpa',
        inclusions: ['General queue VIP coordination support', 'Dham registration passes']
      },
      premium: {
        price: 27900,
        stay: 'Sarovar Portico / 3-star high quality cozy mountain rooms',
        transport: 'Dehradun flight + private SUV Crysta sharing up the mountains',
        meals: 'Delicious organic multi-cuisine satvik buffering',
        pujaIncluded: 'Dedicated Vishnu Sahasranama Archana custom gotra chanting',
        inclusions: ['VIP Fast Entrance line pass', 'Visit to Mana Village (Last Indian Village)', 'Sandalwood paste box and blessing shawl']
      },
      luxury: {
        price: 74990,
        stay: 'Badrinath Luxury Cottage Suites / Premium luxury mountain resorts',
        transport: 'Direct Private Helicopter Charter (Phata/Dehradun to Badrinath heliport)',
        meals: 'Fabulous full-board 5-star Satvik delicacies under heated panels',
        pujaIncluded: 'Highly auspicious early morning "Swarna Aarti" and Shringar Darshan inside primary altar',
        inclusions: ['Special state guest protocol and helicopter queue bypass', 'Fully luxury land SUV transfers', 'Mana Village tea in private camp with Shastri', 'Prasad containing premium saffron & dry fruits box', 'Home pick-up in Patna included']
      }
    }
  },
  {
    id: 'puri',
    name: 'Sri Jagannath Temple (Puri)',
    location: 'Puri, Odisha',
    category: 'chardham',
    description: 'The incredible coastal fortress temple housing Lord Jagannath, Balabhadra, and Goddess Subhadra. Renowned for its mysterious wind-defying temple flags and massive Chappan Bhog kitchen.',
    significance: 'Eastern Dham of India. Famously hosts the global Ratha Yatra Chariot Festival along Bay of Bengal beaches.',
    image: 'https://images.unsplash.com/photo-1616036740257-9449ea1f6605?q=80&w=600&auto=format&fit=crop', // Coastal temple style
    packages: {
      budget: {
        price: 5200,
        stay: 'Nice AC ocean-view guest house rooms close to Golden Beach',
        transport: 'Direct Sleeper train up to Puri railway station from Patna Junction',
        meals: 'Authentic Mahaprasad dining inside temple outer courtyard',
        pujaIncluded: 'Satyabadi Gopinath or ocean sankalpa group puja',
        inclusions: ['Beach sunset walking group', 'Seaside guide help']
      },
      premium: {
        price: 11990,
        stay: 'Hans Coco Palms / 3-star coastal deluxe beach resort',
        transport: 'Patna flight to Bhubaneswar + private AC sedan transfer to Puri beach',
        meals: 'Hygienic, organic multi-cuisine satvik meals',
        pujaIncluded: 'Traditional gotra sankalpa inside temple and direct Mahaprasad thali delivery',
        inclusions: ['VIP Entry with registered temple panda guide helper', 'Sightseeing to Konark Sun Temple & Lake Chilika', 'Jagannath wooden handcrafted mini-chariot souvenir']
      },
      luxury: {
        price: 28900,
        stay: 'Mayfair Waves Puri / Finest 5-star premium beach luxury resort',
        transport: 'Bhubaneswar Airport Private Luxury SUV pickup (Crysta or Luxury Sedan)',
        meals: 'Premium Satvik delicacies, coconut water cocktails, fresh beachfront dining',
        pujaIncluded: 'Exclusive Flag-Offering ceremony (Dhaja Bandha) with special customized gotra pujas by chief temple pandas',
        inclusions: ['State VIP protocol queue access to inner sanctum', 'Pristine clay-pot absolute Chappan Bhog prasad pack', 'Private Konark VIP temple tour', 'Sanskrit speaking historical host companion', 'All Patna airport transfer costs included']
      }
    }
  },
  {
    id: 'dwarkadham',
    name: 'Dwarkadhish Mandir (Dwarka)',
    location: 'Dwarka, Gujarat',
    category: 'chardham',
    description: 'The spectacular five-storied limestone fortress temple of Dwarkadhish, representing "Jagat Mandir" constructed over the sunken golden city of Lord Krishna.',
    significance: 'Western Dham of India, bordering the Arabian Sea crests.',
    image: 'https://images.unsplash.com/photo-1609137144814-633cf46ceef8?q=80&w=600&auto=format&fit=crop', // Ocean temple view
    packages: {
      budget: {
        price: 8900,
        stay: 'Well-maintained Dwarka Trust AC rooms near temple',
        transport: 'Sleeper direct train connections from Patna',
        meals: 'Gujarati Satvik clean foods, sweet khichdi',
        pujaIncluded: 'Gomti River bath chanting group gotra',
        inclusions: ['Bet Dwarka ferry group assistance', 'Temple entrance guidelines']
      },
      premium: {
        price: 18900,
        stay: 'Gokul Ocean View / 3-star high standard resort rooms',
        transport: 'Patna flight to Jamnagar + AC Sedan pick-up up to Dwarka',
        meals: 'Organic multi-style satvik buffet dinners',
        pujaIncluded: 'Special Dwarka Shringar Aarti reserved entry pass & gotra chanting',
        inclusions: ['VIP Shubh Entry Pass card', 'Private ferry ticket to Beyt Dwarka island', 'Krishna golden flute souvenir']
      },
      luxury: {
        price: 43500,
        stay: 'The Fern Sattva Resort Dwarka / Private Luxury Beach Villa',
        transport: 'Jamnagar Airport Premium SUV Crysta direct executive escort',
        meals: 'Extravagant Royal Gujarati thalis and premium satvik dining',
        pujaIncluded: 'Grand Sparsha Puja at Nageshwar and custom Chhappan Bhog offering to Dwarkadhish by chief priest families',
        inclusions: ['High VIP Protocol and executive guide accompanying paths', 'Private chartered yacht ferry to Bet Dwarka', 'Blessed solid silver Dwarka currency token', 'Sanskrit scholar dedicated companion']
      }
    }
  },

  // Other Sacred Heritage Sites
  {
    id: 'tirupati',
    name: 'Tirupati Balaji Swamy (Venkateswara)',
    location: 'Tirumala Hills, Andhra Pradesh',
    category: 'sacred',
    description: 'The monumental temple of Tirumala Hills, the richest and most organized temple system globally. Lord Venkateswara resides in self-manifested golden dome splendor.',
    significance: 'Kali Yuga Vaikuntha. Offers legendary "Tirupati Laddu" prasadam made of pure organic ingredients.',
    image: 'https://images.unsplash.com/photo-1518156677180-95a2893f3e9f?q=80&w=600&auto=format&fit=crop', // Traditional holy gold details
    packages: {
      budget: {
        price: 9500,
        stay: 'Tirumala Devasthanam clean hill rooms/cottages',
        transport: 'Patna to Tirupati Railway sleeper train coach',
        meals: 'Excellent Satvik South Indian Thali food',
        pujaIncluded: 'Group gotra archana inside main complex',
        inclusions: ['2 Blessed Tirupati Laddu pieces', 'Srivari hill transit shared coach']
      },
      premium: {
        price: 19900,
        stay: 'Marasa Sarovar Premier / Fortune Select Grand Ridge Tirupati',
        transport: 'Patna flight to Chennai / Tirupati Airport + Private AC Sedan',
        meals: 'Sublime multi-cuisine organic Satvik catering',
        pujaIncluded: 'VIP Seeghra Darshan (Rs 300 ticket pre-booked) & custom gotra sankalpa',
        inclusions: ['4 Premium Tirupati Laddus guaranteed', 'Visit to Padmavati Ammavari temple', 'Blessed sacred thread and gold silk dupatta']
      },
      luxury: {
        price: 48900,
        stay: 'Taj Tirupati / 5-star mountain view premium suites',
        transport: 'Tirupati Airport Executive Luxury Car pick-up (Crysta/Mercedes)',
        meals: 'Exquisite Royal Satvik South Indian Feast served over heavy banana leaves',
        pujaIncluded: 'Special Suprabhata Seva or Kalyanotsavam booking assistance by institutional coordinators',
        inclusions: ['Direct Protocol state guest VIP lane authorization', 'Custom basket of 10 Laddus and pure silver card', 'Private Srivari hill VIP escorts', 'Dedicated high-level local Shastri guide']
      }
    }
  },
  {
    id: 'sarnath',
    name: 'Sarnath Sacred Buddhist Corridor',
    location: 'Sarnath, Uttar Pradesh (Near Varanasi)',
    category: 'sacred',
    description: 'The legendary deer park where Lord Buddha delivered his first sermon (Dharmachakra Pravartana) after obtaining illumination. Embellished with Ashoka Pillars.',
    significance: 'High place of world heritage, peace, meditation, and ancient stone stupas.',
    image: 'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?q=80&w=600&auto=format&fit=crop', // Ancient dome/structure looks
    packages: {
      budget: {
        price: 3900,
        stay: 'Peaceful Buddhist ashram / guesthouse room',
        transport: 'AC Chair Car weekly trains from Patna to Kashi/Sarnath',
        meals: 'Healthy simple Satvik vegetarian foods',
        pujaIncluded: 'Guided group meditation and peace chants under Bodhi Tree sapling',
        inclusions: ['Sarnath Archaeological Museum ticket', 'Shared local transport']
      },
      premium: {
        price: 8500,
        stay: 'Hotel Somnath / 3-star high review peaceful hotel',
        transport: 'Private AC Sedan up to Sarnath parks (Patna Door-to-door)',
        meals: 'Organic Satvik North Indian and exotic vegetarian lines',
        pujaIncluded: 'Dedicated peace invocation puja and lighting of 108 oil lamps',
        inclusions: ['VIP entrance cards to Dhamekh Stupa complex', 'Bilingual historical monument host', 'Brass Buddha statuette gift']
      },
      luxury: {
        price: 19500,
        stay: 'The Gateway Ganges Hotel Taj / Luxury meditation resort',
        transport: 'Chauffeur-driven Luxury SUV (Innova Crysta, Door-to-Door Patna)',
        meals: 'Exquisite 100% Satvik nutritious organic cuisine',
        pujaIncluded: 'Sanskrit chants and wellness meditation camp hosted by leading meditation Acharyas',
        inclusions: ['State guest priority monument access', 'Authentic brass singing bowl healing souvenir', 'Private Varanasi airport direct transfer if chosen', 'Traditional local historian host companion']
      }
    }
  },
  {
    id: 'vaishnodevi',
    name: 'Mata Vaishno Devi Shrine',
    location: 'Katra, Jammu & Kashmir',
    category: 'sacred',
    description: 'The mystical holy cave temple located at 5,200 ft inside Trikuta Mountains, where Mother Goddess Vaishno Devi resides in natural rocky Pindi form.',
    significance: 'One of the ultimate Shakti Peeths representing high protective power.',
    image: 'https://images.unsplash.com/photo-1626621422470-ee6f2b7b5f54?q=80&w=600&auto=format&fit=crop', // Mountain pathways
    packages: {
      budget: {
        price: 9900,
        stay: 'Well-maintained Katra shrine trust AC rooms',
        transport: 'Patna to Jammu Sleeper weekly direct express lines',
        meals: 'Traditional Satvik North Indian meals (Vaishno dhabas)',
        pujaIncluded: 'Group gotra sankalpa at the Katra base, holy bath guidance',
        inclusions: ['Yatra registration slip', 'Local trekking helpers map']
      },
      premium: {
        price: 19500,
        stay: 'Hotel Hari Niwas / Fortune Park Katra room with peak view',
        transport: 'Flight to Jammu + Private AC Sedan transport to Katra hotel',
        meals: 'Healthy organic delicious satvik buffet lines (No onion/garlic)',
        pujaIncluded: 'Dedicated dry-fruit prasad packet and gotra chanting inside temple complex',
        inclusions: ['Pony or Battery Car booking assistance up the track', 'VIP Darshan card queue bypass', 'Red devotional Chunri and coin gift']
      },
      luxury: {
        price: 49500,
        stay: 'The White Hotels Katra / Finest Heritage Katra Suite',
        transport: 'Jammu Airport Premium SUV crysta pick-up + private helicopter transit up to Sanjichhat',
        meals: 'Royal Satvik Kashmiri dry fruit cuisines and energy soups full-board',
        pujaIncluded: 'Auspicious VIP "Atka Aarti" confirmed slot inside Mata Guha (Cave) during morning slots',
        inclusions: ['VIP helicopter tickets fully pre-arranged', 'Private SUV wait times at Jammu', 'Pristine coin and dry-fruits prasad box', 'Sanskrit speaking guide escort helper']
      }
    }
  },
  {
    id: 'ayodhya',
    name: 'Shree Ram Janmabhoomi (Ayodhya)',
    location: 'Ayodhya, Uttar Pradesh',
    category: 'sacred',
    description: 'The grand new Ram Temple situated on the holy banks of Saryu River, honoring Lord Ram Lalla in his innocent childhood form.',
    significance: 'Historical kingdom of Raghu Dynasty. Holy light and sound show, Saryu river morning Dip.',
    image: 'https://images.unsplash.com/photo-1616036740257-9449ea1f6605?q=80&w=600&auto=format&fit=crop', // Temple sunset styles
    packages: {
      budget: {
        price: 4200,
        stay: 'AC guest room at Ram Trust Ashram close to saryu river',
        transport: 'Patna train direct sleeper to Ayodhya Cantt Station',
        meals: 'Ayodhya traditional sweet pedas, simple satvik meals',
        pujaIncluded: 'Saryu River dip sankalpa group puja with priest',
        inclusions: ['Hanuman Garhi fast queue coordinate', 'Temple guide list']
      },
      premium: {
        price: 9500,
        stay: 'Hotel Rama Palace / Premium AC properties in central Katra road',
        transport: 'Private Hatchback / Sedan car travel (Patna to Ayodhya)',
        meals: 'Amazing local organic satvik delicacies',
        pujaIncluded: 'Exclusive Ram Lalla Darshan priority tickets and gotra flower offering',
        inclusions: ['VIP Entry pass card (Direct)', 'Private guide showing Dashrath Mahal & Kanak Bhawan', 'Shree Ram saffron scarf gift']
      },
      luxury: {
        price: 24500,
        stay: 'Royal Heritage Mansion Suites / Finest luxury Ayodhya resort',
        transport: 'Luxury Chauffeur SUV Crysta (Door-to-door Patna to Ayodhya)',
        meals: 'Elite Satvik Awadhi Thali dining setups',
        pujaIncluded: 'Beautiful "Kanak Abhishek" with holy water, key gotra sankalpas by high state temple Acharyas',
        inclusions: ['State VIP pass protocol with zero wait times', 'Special heavy cotton saffron scarf with Shree Ram signatures', 'Private boat on Saryu River during sunset Aarti', 'Blessed Shri Ram Lalla visual frame gift', '24/7 personal guide helper']
      }
    }
  }
];

export const TRAVEL_DESTINATIONS_DATA: TravelDestination[] = RAW_TRAVEL_DESTINATIONS_DATA.map(dest => {
  const luxuryPrice = dest.packages.luxury.price;
  const royalPrice = Math.round((luxuryPrice * 1.65) / 500) * 500 - 1;
  const royalLuxuryPackage = {
    price: royalPrice,
    stay: getHotelStayByPrice(royalPrice),
    transport: dest.id === 'kedarnath' || dest.id === 'badrinath'
      ? 'Chartered VIP Helicopter (To / From) with Mercedes S-Class Airport Transfers'
      : 'Premium Sovereign Mercedes-Benz S-Class / BMW 7-Series Chauffeur (Door-to-Door)',
    meals: 'Royal Maharaja Golden-Plated Dine-in Experience & 100% Organic Satvik Chappan Bhog with Private Chef Service',
    pujaIncluded: 'Exclusive Royal Maha-Abhishek & Complete Yajna overseen by Chief Temple Acharya with recorded family sankalpa',
    inclusions: [
      'Elite Royal Protocol Darshan (Zero-waiting block, direct inner sanctum entry)',
      'Sovereign Elite Lounge access at all temple complex gates',
      'Exclusive Solid Silver/Gold-Plated Dev/Pitri Yantra & Sacred Gangajal Copper Pot',
      '24/7 Dedicated Sanskrit Scholar Personal Tour Guide & Local Historian',
      'Premium custom Prasad hampers containing rare organic dry fruits, custom stole & premium rudraksha beads'
    ]
  };

  return {
    ...dest,
    packages: {
      budget: {
        ...dest.packages.budget,
        stay: getHotelStayByPrice(dest.packages.budget.price)
      },
      premium: {
        ...dest.packages.premium,
        stay: getHotelStayByPrice(dest.packages.premium.price)
      },
      luxury: {
        ...dest.packages.luxury,
        stay: getHotelStayByPrice(dest.packages.luxury.price)
      },
      royalLuxury: royalLuxuryPackage
    }
  };
});
