/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { SamagriKit } from '../types';

export const SAMAGRI_DATA: SamagriKit[] = [
  {
    id: 'satyanarayan_box',
    title: 'Sri Satyanarayan Complete Katha Box',
    category: 'katha-puja',
    price: 1899,
    standardPrice: 1899,
    premiumPrice: 2899, // Includes brass vishnu idol and copper panchpatra
    description: 'Pristinely packed, handpicked components for Sri Satyanarayan Puja. Handled hygienically by pure Satvik staff in Patna.',
    checklist: [
      'Pure Haridwar Ganga Jal (250ml)',
      'Certified organic Panchamrit items (Honey, Mishri, Cow Ghee)',
      'Yellow altar cloth (Kapda) & Janeu pairs',
      'Unbroken organic basmati Akshat rice (500g)',
      'Aromatic dhoop stick tubes & pure Camphor tablet blocks',
      'Roli, Sindoor, Kumkum, Peela Chandan paste powder',
      'Best quality Supari (31 pieces), clove (laung) & cardamom (elaichi)',
      'Cotton wicks (Ghee bati) & raw matchbox'
    ],
    image: 'https://images.unsplash.com/photo-1590076212133-cbe24e10df3a?q=80&w=600&auto=format&fit=crop' // Incense sticks, herbs
  },
  {
    id: 'grihapravesh_box',
    title: 'Griha Pravesh Complete Shubh Box',
    category: 'katha-puja',
    price: 3499,
    standardPrice: 3499,
    premiumPrice: 4999, // Includes premium copper kalash and pure silver coin
    description: 'A comprehensive, ritualistic starter box designed explicitly for housewarming. Cleanses directions and fills your new Patna home with auspicious aura.',
    checklist: [
      'Handcrafted Copper Kalash (heavyweight)',
      'Terracotta Chirags (deepaks, 11 pieces)',
      'Natural Panch-dhatu (5 metals: Copper, Brass, Iron, Zinc, Silver grain)',
      'Raw Sarso (Yellow mustard seeds for protection chanting)',
      'Vedic Rangoli custom stencils and multi-color powders',
      'Toran of fresh local mango trees (Patna farm-direct)',
      'Pure Gau-mutra (cow urine disinfectant)',
      'Mauli thread roll (Rakshasutra)',
      'Agarbatti package, lobby incense'
    ],
    image: 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?q=80&w=600&auto=format&fit=crop' // Saffron spice and organic roots in cups
  },
  {
    id: 'rudrabhishek_box',
    title: 'Maha Rudrabhishek Shiv Shanti Box',
    category: 'havan-special',
    price: 2499,
    standardPrice: 2499,
    premiumPrice: 3999, // Includes stone Narmadeshwar Shivling with brass tripund mount
    description: 'Specially packed liquid and dry samagri combination required for bathing Lord Shiva. Contains authentic Himalayan Herbs.',
    checklist: [
      'Ganges Holy Water (fresh from Devprayag flow)',
      'Finely powdered Sandalwood (Chandan powder, 100g)',
      'Organic black sesame seeds (Kaale Til)',
      'Whole dried Bael fruit & Bhasma (consecrated ash from Kashi fields)',
      'Janeyu threads & white altar cloth pieces',
      'Akshat unbroken grains & barley flakes',
      'Saffron (Kesar, 1g container)',
      'Attar (Sacred fragrant oil compound)',
      'Cotton wool rolls and camphor bricks'
    ],
    image: 'https://images.unsplash.com/photo-1601049541289-9b1b7bbbfe19?q=80&w=600&auto=format&fit=crop' // Traditional spices, powders on plate
  },
  {
    id: 'havan_special_box',
    title: 'Universal Shubh Vastu Havan Wood Kit',
    category: 'havan-special',
    price: 1599,
    standardPrice: 1599,
    premiumPrice: 2599, // Includes heavy iron Havan Kund and fire spatula
    description: 'Premium quality fuel wood and herb mixtures for powerful purifying smoke. Brings intense spiritual vibes and kills aerial pathogens.',
    checklist: [
      'Auspicious Mango Wood logs (Samidha, 2.5 kg)',
      'Vedic Havan Samagri Mixture (Aindri, Agar, Tagar, Jatamansi, Guggal, Loban)',
      'Pure Patna Desi Cow Ghee (500ml container)',
      'Lotus seeds (Kamalgatta, 108 pieces) & Black Til',
      'Camphor (Kapur) tablet pieces for continuous fire',
      'Cardamom, Cloves, dry whole coconut halves',
      'Bael wood strips & Sandal wood shavings',
      'Long-handled wooden ghee spoon (Sruva)'
    ],
    image: 'https://images.unsplash.com/photo-1543007630-9710e4a00a20?q=80&w=600&auto=format&fit=crop' // Wooden items, charcoal, incenses
  },
  {
    id: 'daily_mandir_box',
    title: 'Poonam Daily Mandir Pure Devotion Box',
    category: 'daily-essentials',
    price: 899,
    standardPrice: 899,
    premiumPrice: 1499, // Super-saver pack of 3 continuous months
    description: 'Perfect for every home in Patna. Keep your home temple fresh, pure, and Vedic without missing any essential item.',
    checklist: [
      'Unrefined Sindoor (traditional Bihari orange-color)',
      'Premium Rose Agarbatti (60 sticks container)',
      'Pure cow ghee pre-poured cotton wicks (60 wicks box)',
      'Sandalwood block with stone rubbing mortar',
      'Holy Ganga Jal sprayer bottle',
      'Akshat rice (consecrated, 250g)',
      'Itra bottle with dabber',
      'Brass Ghanti (bell) for morning arati'
    ],
    image: 'https://images.unsplash.com/photo-1512428559087-560fa5ceab42?q=80&w=600&auto=format&fit=crop' // Small brass lamp, flowers, and powders
  }
];
