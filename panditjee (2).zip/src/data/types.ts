/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Puja {
  id: string;
  title: string;
  sanskritName: string;
  description: string;
  benefits: string[];
  duration: string;
  standardPrice: number; // Priest only
  premiumPrice: number;  // Priest + Samagri Box
  ePujaPrice: number;     // Online/Zoom Puja + Prasad Courier
  image: string;
  samagriChecklist: string[];
  category?: 'consultation' | 'puja-archana' | 'jap-path' | 'ancestor-rites';
}

export interface SamagriKit {
  id: string;
  title: string;
  category: 'katha-puja' | 'havan-special' | 'daily-essentials';
  price: number;
  standardPrice: number;
  premiumPrice: number;
  description: string;
  checklist: string[];
  image: string;
}

export interface TravelDestination {
  id: string;
  name: string;
  location: string;
  category: 'jyotirlinga' | 'chardham' | 'sacred';
  description: string;
  significance: string;
  image: string;
  packages: {
    budget: TravelPackage;
    premium: TravelPackage;
    luxury: TravelPackage;
    royalLuxury: TravelPackage;
  };
}

export interface TravelPackage {
  price: number;
  stay: string;
  transport: string;
  meals: string;
  pujaIncluded: string;
  inclusions: string[];
}

export interface CalendarEvent {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  tithi: string;
  description: string;
  recommendedPuja: string;
  recommendedPujaId: string;
}

export interface Booking {
  id: string;
  pujaId: string;
  pujaTitle: string;
  packageType: 'standard' | 'premium' | 'epuja';
  price: number;
  devoteeName: string;
  contactPhone: string;
  email: string;
  date: string;
  timeSlot: string;
  gotra: string;
  nakshatra: string;
  rashi: string;
  bookingDate: string;
  status: 'confirmed' | 'pending_payment';
}

export interface Order {
  id: string;
  kitId: string;
  kitTitle: string;
  packageType: 'standard' | 'premium';
  price: number;
  customerName: string;
  contactPhone: string;
  deliveryAddress: string;
  orderDate: string;
  status: 'processing' | 'out_for_delivery';
}

export interface TravelInquiry {
  id: string;
  destinationId: string;
  destinationName: string;
  packageTier: 'budget' | 'premium' | 'luxury' | 'royalLuxury';
  price: number;
  customerName: string;
  contactPhone: string;
  preferredDate: string;
  pilgrimsCount: number;
  gotra: string;
  inquiryDate: string;
  status: 'submitted';
}
