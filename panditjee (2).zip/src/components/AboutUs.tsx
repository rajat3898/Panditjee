/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Shield, Sparkles, MapPin, Heart, HelpCircle, Check, Gift } from 'lucide-react';

export const AboutUs: React.FC = () => {
  return (
    <section className="py-12 bg-white" id="about-us-section">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 md:px-8 space-y-12">
        {/* Intro Section */}
        <div className="space-y-4 text-center">
          <span className="text-xs font-sans font-bold tracking-widest text-saffron-600 bg-saffron-50 border border-saffron-100 py-1 px-3.5 rounded-full uppercase inline-block">
            Our Legacy
          </span>
          <h2 className="text-3xl md:text-4xl font-cinzel font-bold text-stone-800 tracking-tight">
            About US — PanditJee.in
          </h2>
          <p className="text-sm md:text-base text-stone-600 font-sans leading-relaxed max-w-2xl mx-auto italic">
            "Welcome to panditjee.in—Patna’s premier digital platform dedicated to bringing authentic Vedic rituals, experienced Pandits, and premium Pooja Samagri right to your doorstep."
          </p>
        </div>

        {/* Our Story (Warm colored card) */}
        <div className="bg-linear-to-r from-saffron-50 to-saffron-100/30 p-6 md:p-8 rounded-2xl border border-saffron-100 space-y-4 shadow-3xs text-left">
          <h3 className="font-serif font-bold text-xl text-saffron-700 flex items-center gap-2">
            <span>✨</span> Our Story
          </h3>
          <div className="text-xs sm:text-sm text-stone-600 font-sans leading-relaxed space-y-4">
            <p>
              In a fast-paced world, staying connected to our deep-rooted traditions can sometimes feel overwhelming. Whether it is finding a learned Pandit who understands the precise Vedic rituals or running from market to market in Patna's bustling lanes to find every single item on a complex Pooja Samagri list, the logistics shouldn't get in the way of your devotion.
            </p>
            <p>
              Born out of the cultural heart of Bihar, <strong>panditjee.in</strong> was founded to bridge this exact gap. We realized that while times are changing, our reverence for sacred rituals remains timeless. We set out to create a seamless, reliable, and respectful bridge between age-old traditions and modern convenience.
            </p>
          </div>
        </div>

        {/* What We Do (3 Column Grid) */}
        <div className="space-y-6">
          <h3 className="font-serif font-extrabold text-2xl text-stone-800 text-center uppercase tracking-wide">
            What We Do
          </h3>
          <p className="text-xs text-stone-500 font-sans text-center max-w-xl mx-auto -mt-4">
            We are a full-service spiritual e-commerce and booking platform. We take the stress out of religious ceremonies so you can focus entirely on the devotion and joy of the occasion.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left pt-2">
            <div className="p-5 rounded-xl bg-stone-50 border border-stone-150 shadow-3xs space-y-3">
              <div className="w-9 h-9 rounded-full bg-saffron-100/80 flex items-center justify-center text-saffron-600 font-bold text-sm">
                👤
              </div>
              <h4 className="font-serif font-bold text-stone-800 text-base leading-tight">Verified & Experienced Pandits</h4>
              <p className="text-xs text-stone-500 font-sans leading-relaxed">
                We connect you with highly learned, verified, and specialized Pandits in Patna for all occasions—from intimate Satyanarayan Pujas and Griha Praveshs to grand Weddings, Upanayan Sanskars, and festive celebrations like Chhath Puja.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-stone-50 border border-stone-150 shadow-3xs space-y-3">
              <div className="w-9 h-9 rounded-full bg-saffron-100/80 flex items-center justify-center text-saffron-600 font-bold text-sm">
                📦
              </div>
              <h4 className="font-serif font-bold text-stone-800 text-base leading-tight">Curated Pooja Samagri Kits</h4>
              <p className="text-xs text-stone-500 font-sans leading-relaxed">
                No more missing ingredients. We curate premium-quality, pristine, and complete Pooja boxes tailored specifically to the ceremony you book, delivered straight to your home.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-stone-50 border border-stone-150 shadow-3xs space-y-3">
              <div className="w-9 h-9 rounded-full bg-saffron-100/80 flex items-center justify-center text-saffron-600 font-bold text-sm">
                🌸
              </div>
              <h4 className="font-serif font-bold text-stone-800 text-base leading-tight">Devotional Journey for Everyone</h4>
              <p className="text-xs text-stone-500 font-sans leading-relaxed">
                From tech-savvy individuals organizing rituals for their families to the Bihari diaspora wishing to connect back to their roots through virtual e-Puja services, we cater to all generations.
              </p>
            </div>
          </div>
        </div>

        {/* Why Choose Us */}
        <div className="space-y-6 pt-4 border-t border-stone-100 text-left">
          <h3 className="font-serif font-bold text-2xl text-stone-800 text-center uppercase tracking-wide">
            Why Choose panditjee.in?
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            {[
              {
                title: 'Authenticity at the Core',
                desc: 'Every ritual is conducted strictly according to Vedic traditions and regional customs unique to Bihar.'
              },
              {
                title: 'Purity & Hygiene Guaranteed',
                desc: 'We source our Samagri with the utmost care, ensuring everything from the Ganga Jal to the sacred herbs is pure, unadulterated, and handled hygienically.'
              },
              {
                title: 'Transparent & Reliable',
                desc: 'No last-minute negotiations or hidden costs. Enjoy upfront pricing, timely arrivals, and hassle-free booking.'
              },
              {
                title: 'Rooted in Patna',
                desc: 'Being local allows us to understand the heart, language, and specific traditional nuances of our community perfectly.'
              }
            ].map((item, idx) => (
              <div key={idx} className="flex gap-3">
                <div className="w-5 h-5 bg-saffron-50 border border-saffron-200 rounded-full flex items-center justify-center text-saffron-600 text-xs shrink-0 mt-0.5">
                  ✓
                </div>
                <div>
                  <h4 className="font-sans font-bold text-sm text-stone-800">{item.title}</h4>
                  <p className="text-xs text-stone-500 font-sans leading-relaxed mt-0.5">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Vision & Call out (Gold border card) */}
        <div className="bg-white border-2 border-dashed border-marigold-500/40 p-6 rounded-2xl flex flex-col justify-center items-center text-center max-w-2xl mx-auto space-y-4">
          <div className="w-10 h-10 bg-marigold-100/50 rounded-full flex items-center justify-center text-marigold-600 font-bold shadow-3xs animate-vedic-float">
            ॐ
          </div>
          <div className="space-y-1.5">
            <h4 className="font-cinzel text-lg text-saffron-700 font-bold uppercase tracking-wider">Our Vision</h4>
            <p className="text-xs text-stone-500 font-sans max-w-md mx-auto leading-relaxed">
              To preserve and nurture our sacred Vedic heritage by making religious rituals accessible, structured, and joyful for every household in Patna and beyond.
            </p>
          </div>
          <p className="text-sm md:text-base text-saffron-600 font-serif italic font-bold">
            "Let us handle the preparation, while you immerse yourself in the prayers."
          </p>
        </div>
      </div>
    </section>
  );
};
