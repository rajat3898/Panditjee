/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Calendar, ShoppingBag, Compass, Trash2, ShieldAlert, CheckCircle } from 'lucide-react';
import { Booking, Order, TravelInquiry } from '../types';

interface HistoryPanelProps {
  isOpen: boolean;
  onClose: () => void;
  bookings: Booking[];
  orders: Order[];
  travelInquiries: TravelInquiry[];
  onCancelBooking: (id: string) => void;
  onCancelOrder: (id: string) => void;
  onCancelTravel: (id: string) => void;
}

export const HistoryPanel: React.FC<HistoryPanelProps> = ({
  isOpen,
  onClose,
  bookings,
  orders,
  travelInquiries,
  onCancelBooking,
  onCancelOrder,
  onCancelTravel,
}) => {
  if (!isOpen) return null;

  const totalItems = bookings.length + orders.length + travelInquiries.length;

  const handleWhatsAppFollowUp = (type: string, details: string) => {
    const text = encodeURIComponent(`Pranam Pandit Jee! I want to confirm my booking on panditjee.in.\nDetail Summary:\n${details}`);
    window.open(`https://wa.me/917549425216?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden" id="history-backdrop">
      {/* Backdrop overlay */}
      <div 
        className="absolute inset-0 bg-stone-900/60 backdrop-blur-xs transition-opacity duration-300"
        onClick={onClose}
      />

      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white border-l border-saffron-100 flex flex-col shadow-2xl">
          {/* Drawer Header */}
          <div className="p-6 bg-linear-to-b from-saffron-50 to-white border-b border-saffron-100 flex items-center justify-between">
            <div>
              <h2 className="text-xl font-cinzel font-bold text-saffron-700">My Devotion Ledger</h2>
              <p className="text-xs text-stone-500 font-sans mt-0.5">Tracking your active ritual services in Patna</p>
            </div>
            <button 
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-saffron-100/50 text-stone-500 hover:text-saffron-600 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Drawer Body Scroll */}
          <div className="flex-1 overflow-y-auto p-6 space-y-8 bg-stone-50/30">
            {totalItems === 0 ? (
              <div className="h-full flex flex-col justify-center items-center text-center py-20">
                <div className="w-16 h-16 bg-saffron-50 border border-saffron-150 rounded-full flex items-center justify-center text-saffron-300 mb-4 animate-pulse">
                  <span className="text-3xl font-cinzel">ॐ</span>
                </div>
                <h3 className="text-base font-serif font-medium text-stone-700">No Active Devotions</h3>
                <p className="text-sm text-stone-400 font-sans max-w-xs mt-2 leading-relaxed">
                  You have not scheduled any Vedic Pujas, ordered Samagri boxes, or planned any Sacred Yatras yet.
                </p>
              </div>
            ) : (
              <>
                {/* 1. SECURED PUJAS LIST */}
                {bookings.length > 0 && (
                  <div className="space-y-4">
                    <h3 className="text-xs font-sans font-bold tracking-widest text-saffron-700 uppercase flex items-center gap-1.5 pb-2 border-b border-stone-100">
                      <Calendar className="w-4 h-4 text-saffron-500" />
                      <span>Priest Ritual Bookings ({bookings.length})</span>
                    </h3>
                    <div className="space-y-3">
                      {bookings.map((b) => (
                        <div key={b.id} className="bg-white p-4 rounded-xl border border-saffron-100/70 shadow-xs space-y-3">
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-serif font-semibold text-stone-800 leading-tight">{b.pujaTitle}</h4>
                              <p className="text-[10px] font-sans text-saffron-600 font-medium">Gotra: {b.gotra || 'N/A'} | Rashi: {b.rashi || 'N/A'}</p>
                            </div>
                            <span className="text-xs font-mono font-bold text-saffron-600 bg-saffron-50 px-2 py-0.5 rounded-full">
                              ₹{b.price}
                            </span>
                          </div>

                          <div className="grid grid-cols-2 gap-2 text-xs text-stone-500 font-sans border-t border-b border-stone-50 py-2">
                            <div>
                              <span className="text-[10px] text-stone-400 block">Devotee Name</span>
                              <span className="font-medium text-stone-700">{b.devoteeName}</span>
                            </div>
                            <div>
                              <span className="text-[10px] text-stone-400 block">Package Setup</span>
                              <span className="font-medium text-stone-700 capitalize">{b.packageType === 'epuja' ? 'E-Puja Zoom' : b.packageType}</span>
                            </div>
                            <div>
                              <span className="text-[10px] text-stone-400 block">Ritual Date</span>
                              <span className="font-medium text-stone-700">{b.date}</span>
                            </div>
                            <div>
                              <span className="text-[10px] text-stone-400 block">Time Slot</span>
                              <span className="font-medium text-stone-700">{b.timeSlot}</span>
                            </div>
                          </div>

                          <div className="flex gap-2 text-xs pt-1">
                            <button
                              onClick={() => handleWhatsAppFollowUp(
                                'puja',
                                `ID: ${b.id}\nPuja: ${b.pujaTitle}\nDevotee: ${b.devoteeName}\nGotra: ${b.gotra}\nDate: ${b.date}\nTime: ${b.timeSlot}\nPackage: ${b.packageType}`
                              )}
                              className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white font-medium py-1.5 px-3 rounded-lg flex items-center justify-center gap-1.5 transition-colors"
                            >
                              <span>Confirm via WA</span>
                            </button>
                            <button
                              onClick={() => onCancelBooking(b.id)}
                              className="p-1.5 text-stone-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors border border-stone-200"
                              title="Cancel Booking"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 2. SAMAGRI DELIVERIES */}
                {orders.length > 0 && (
                  <div className="space-y-4">
                    <h3 className="text-xs font-sans font-bold tracking-widest text-saffron-700 uppercase flex items-center gap-1.5 pb-2 border-b border-stone-100">
                      <ShoppingBag className="w-4 h-4 text-saffron-500" />
                      <span>Pooja Samagri Deliveries ({orders.length})</span>
                    </h3>
                    <div className="space-y-3">
                      {orders.map((o) => (
                        <div key={o.id} className="bg-white p-4 rounded-xl border border-saffron-100/70 shadow-xs space-y-3">
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-serif font-semibold text-stone-800 leading-tight">{o.kitTitle}</h4>
                              <p className="text-[10px] font-sans text-marigold-600 font-medium capitalize">Tier: {o.packageType} Packing Box</p>
                            </div>
                            <span className="text-xs font-mono font-bold text-marigold-600 bg-marigold-50 px-2 py-0.5 rounded-full">
                              ₹{o.price}
                            </span>
                          </div>

                          <div className="text-xs text-stone-500 font-sans border-t border-b border-stone-50 py-2 space-y-1">
                            <div className="flex justify-between">
                              <span className="text-stone-400 text-[10px]">Client Name:</span>
                              <span className="font-semibold text-stone-700">{o.customerName}</span>
                            </div>
                            <div className="flex flex-col">
                              <span className="text-stone-400 text-[10px]">Patna Delivery Address:</span>
                              <span className="font-normal text-stone-600 text-[11px] leading-snug">{o.deliveryAddress}</span>
                            </div>
                            <div className="flex justify-between pt-1">
                              <span className="text-stone-400 text-[10px]">Payment Type:</span>
                              <span className="font-semibold text-emerald-600 text-[10px] uppercase bg-emerald-50 px-1.5 py-0.5 rounded-sm">Cash On Delivery (COD)</span>
                            </div>
                          </div>

                          <div className="flex gap-2 text-xs pt-1">
                            <button
                              onClick={() => handleWhatsAppFollowUp(
                                'samagri',
                                `ID: ${o.id}\nSamagri Packet: ${o.kitTitle}\nCustomer: ${o.customerName}\nDelivering Address: ${o.deliveryAddress}\nPrice: ₹${o.price} COD`
                              )}
                              className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white font-medium py-1.5 px-3 rounded-lg flex items-center justify-center gap-1.5 transition-colors"
                            >
                              <span>Confirm Shipping</span>
                            </button>
                            <button
                              onClick={() => onCancelOrder(o.id)}
                              className="p-1.5 text-stone-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors border border-stone-200"
                              title="Cancel Order"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 3. SACRED YATRAS INQUIRIES */}
                {travelInquiries.length > 0 && (
                  <div className="space-y-4">
                    <h3 className="text-xs font-sans font-bold tracking-widest text-saffron-700 uppercase flex items-center gap-1.5 pb-2 border-b border-stone-100">
                      <Compass className="w-4 h-4 text-saffron-500" />
                      <span>Shubh Yatra Inquiries ({travelInquiries.length})</span>
                    </h3>
                    <div className="space-y-3">
                      {travelInquiries.map((t) => (
                        <div key={t.id} className="bg-white p-4 rounded-xl border border-saffron-100/70 shadow-xs space-y-3">
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-serif font-semibold text-stone-800 leading-tight">{t.destinationName}</h4>
                              <p className="text-[10px] font-sans text-emerald-600 font-bold uppercase tracking-wider">{t.packageTier} Package Setup</p>
                            </div>
                            <span className="text-xs font-mono font-bold text-saffron-600 bg-saffron-50 px-2 py-0.5 rounded-full">
                              ₹{t.price} / Pilgrim
                            </span>
                          </div>

                          <div className="grid grid-cols-2 gap-2 text-xs text-stone-500 font-sans border-t border-b border-stone-50 py-2">
                            <div>
                              <span className="text-[10px] text-stone-400 block">Lead Pilgrim</span>
                              <span className="font-medium text-stone-700">{t.customerName}</span>
                            </div>
                            <div>
                              <span className="text-[10px] text-stone-400 block">Pilgrims count</span>
                              <span className="font-medium text-stone-700">{t.pilgrimsCount} Devotee(s)</span>
                            </div>
                            <div>
                              <span className="text-[10px] text-stone-400 block">Preferred Date</span>
                              <span className="font-medium text-stone-700">{t.preferredDate}</span>
                            </div>
                            <div>
                              <span className="text-[10px] text-stone-400 block">Family Gotra</span>
                              <span className="font-medium text-stone-700">{t.gotra || 'N/A'}</span>
                            </div>
                          </div>

                          <div className="flex gap-2 text-xs pt-1">
                            <button
                              onClick={() => handleWhatsAppFollowUp(
                                'travel',
                                `YATRA ENQUIRY\nDestination: ${t.destinationName}\nPackage: ${t.packageTier}\nLead Pilgrim: ${t.customerName}\nContact: ${t.contactPhone}\nDate: ${t.preferredDate}\nPilgrims: ${t.pilgrimsCount}\nGotra: ${t.gotra}`
                              )}
                              className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white font-medium py-1.5 px-3 rounded-lg flex items-center justify-center gap-1.5 transition-colors"
                            >
                              <span>Send Inquires via WA</span>
                            </button>
                            <button
                              onClick={() => onCancelTravel(t.id)}
                              className="p-1.5 text-stone-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors border border-stone-200"
                              title="Cancel Inquiry"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Drawer Footer info line */}
          {totalItems > 0 && (
            <div className="p-4 bg-stone-50 border-t border-stone-150 text-center font-sans">
              <p className="text-[10px] text-stone-400">All prices calculated in Indian Rupees (INR).</p>
              <p className="text-[10px] text-saffron-600 font-medium mt-0.5">Please press the green WhatsApp button to confirm scheduling with the Patna Bailey Road desk!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
