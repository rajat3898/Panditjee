/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Heart, Check, Clock, User, ArrowRight, X, Sparkles, CheckSquare, Calendar, Gift, Flame, BookOpen, Layers } from 'lucide-react';
import { Puja, Booking } from '../types';

interface PujaCatalogueProps {
  pujas: Puja[];
  onAddBooking: (booking: Booking) => void;
  // If the chat redirects to open a specific booking modal immediately
  preSelectedPuja: Puja | null;
  onClearPreSelected: () => void;
}

export const PujaCatalogue: React.FC<PujaCatalogueProps> = ({
  pujas,
  onAddBooking,
  preSelectedPuja,
  onClearPreSelected,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'consultation' | 'puja-archana' | 'jap-path' | 'ancestor-rites'>('all');
  const [expandedPujaId, setExpandedPujaId] = useState<string | null>(pujas[0]?.id || null);

  // Core Booking Modal state
  const [bookingPuja, setBookingPuja] = useState<Puja | null>(null);
  const [packageType, setPackageType] = useState<'standard' | 'premium' | 'epuja'>('premium');
  const [devoteeName, setDevoteeName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [email, setEmail] = useState('');
  const [date, setDate] = useState('');
  const [timeSlot, setTimeSlot] = useState('08:00 AM - 11:00 AM');
  const [gotra, setGotra] = useState('');
  const [nakshatra, setNakshatra] = useState('');
  const [rashi, setRashi] = useState('');
  const [successReceipt, setSuccessReceipt] = useState<Booking | null>(null);

  // Interactive Checklist State (keeps track of what materials they checked off at home)
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});

  // Trigger when chat redirects
  React.useEffect(() => {
    if (preSelectedPuja) {
      setBookingPuja(preSelectedPuja);
      onClearPreSelected();
    }
  }, [preSelectedPuja]);

  const toggleChecklist = (pujaId: string, item: string) => {
    const key = `${pujaId}-${item}`;
    setCheckedItems(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingPuja || !devoteeName || !contactPhone || !date) return;

    let price = bookingPuja.premiumPrice;
    if (packageType === 'standard') price = bookingPuja.standardPrice;
    if (packageType === 'epuja') price = bookingPuja.ePujaPrice;

    const newBooking: Booking = {
      id: 'puj-' + Math.random().toString(36).substr(2, 9),
      pujaId: bookingPuja.id,
      pujaTitle: bookingPuja.title,
      packageType,
      price,
      devoteeName,
      contactPhone,
      email,
      date,
      timeSlot,
      gotra,
      nakshatra,
      rashi,
      bookingDate: new Date().toLocaleDateString(),
      status: 'confirmed'
    };

    onAddBooking(newBooking);
    setSuccessReceipt(newBooking);
  };

  const handleWhatsAppForward = (b: Booking) => {
    const message = `Pranam Pandit Jee! I want to confirm my Vedic Priest Ritual Booking on panditjee.in.
------------------------------------
Ritual: *${b.pujaTitle}*
Sanskrit Name: _${pujas.find(p => p.id === b.pujaId)?.sanskritName}_
Assigned Order ID: *${b.id}*
------------------------------------
DEVOTEE RECORD:
Lead Devotee Name: _${b.devoteeName}_
Contact Phone: _${b.contactPhone}_
Scheduled Date: *${b.date}*
Auspicious Time: *${b.timeSlot}*
Family GOTRA (गोत्र): *${b.gotra || 'N/A'}*
Birth NAKSHATRA (नक्षत्र): *${b.nakshatra || 'N/A'}*
Moon Sign RASHI (राशि): *${b.rashi || 'N/A'}*
------------------------------------
PACKAGE SETUP:
Type Chosen: *${b.packageType.toUpperCase()}*
Standard Priest Only? ${b.packageType === 'standard' ? 'Yes' : 'No'}
Includes full organic materials? ${b.packageType === 'premium' ? 'Yes (Divine setup)' : 'No'}
Total Settlement: *₹${b.price}*

Please assign a highly learned Patna Shastri aligned with our Gotra and schedule the customized Sankalpa.`;

    window.open(`https://wa.me/917549425216?text=${encodeURIComponent(message)}`, '_blank');
  };

  const resetForm = () => {
    setBookingPuja(null);
    setPackageType('premium');
    setDevoteeName('');
    setContactPhone('');
    setEmail('');
    setDate('');
    setGotra('');
    setNakshatra('');
    setRashi('');
    setSuccessReceipt(null);
  };

  const handleCategoryChange = (category: 'all' | 'consultation' | 'puja-archana' | 'jap-path' | 'ancestor-rites') => {
    setSelectedCategory(category);
    // Auto-select the first puja of the selected category
    const matching = pujas.filter(p => {
      const matchesSearch = 
        p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.sanskritName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesCategory = category === 'all' || p.category === category;
      return matchesSearch && matchesCategory;
    });
    if (matching.length > 0) {
      setExpandedPujaId(matching[0].id);
    } else {
      setExpandedPujaId(null);
    }
  };

  const filteredPujas = pujas.filter(p => {
    const matchesSearch = 
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.sanskritName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <section className="py-12 bg-white" id="puja-catalogue-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 space-y-10">
        
        {/* Header Block */}
        <div className="text-center space-y-3">
          <span className="text-xs font-sans font-bold tracking-widest text-saffron-600 bg-saffron-50 border border-saffron-100 py-1 px-3.5 rounded-full uppercase inline-block">
            Divine Liturgies
          </span>
          <h2 className="text-3xl md:text-4xl font-cinzel font-bold text-stone-800 tracking-tight">
            Auspicious Vedic Puja Catalog
          </h2>
          <p className="text-sm md:text-base text-stone-500 font-sans max-w-2xl mx-auto leading-relaxed">
            Select from our ancient spiritual ceremonies, organized by highly certified Pandits. Take advantage of our interactive checklist tools to prepare your home altar before the priests arrive.
          </p>
        </div>

        {/* Searching & Listings Filter */}
        <div className="max-w-md mx-auto relative flex" id="puja-search-bar">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by ritual name, sanskrit keywords..."
            className="w-full bg-stone-50 border border-stone-200 focus:border-saffron-500 focus:outline-hidden py-3 px-5 text-sm rounded-xl pr-10 placeholder:text-stone-400"
          />
          <span className="absolute right-3.5 top-3.5 text-stone-400">🔍</span>
        </div>

        {/* Category Tabs Switcher */}
        <div className="flex flex-wrap justify-center gap-2 max-w-4xl mx-auto" id="puja-category-tabs">
          {[
            { id: 'all', label: 'All Rituals', hindi: 'सभी अनुष्ठान', icon: Layers },
            { id: 'consultation', label: 'Horoscope & Astro', hindi: 'कुण्डली एवं ज्योतिष', icon: Calendar },
            { id: 'puja-archana', label: 'Puja - Archana', hindi: 'पूजा - अर्चना', icon: Flame },
            { id: 'jap-path', label: 'Jap & Path', hindi: 'जप एवं पाठ', icon: BookOpen },
            { id: 'ancestor-rites', label: 'Shradh & Pind Daan', hindi: 'श्राद्ध एवं पिंडदान', icon: Heart },
          ].map((tab) => {
            const IconComponent = tab.icon;
            const count = pujas.filter(p => tab.id === 'all' || p.category === tab.id).length;
            const isActive = selectedCategory === tab.id;
            
            return (
              <button
                key={tab.id}
                onClick={() => handleCategoryChange(tab.id as any)}
                className={`py-2 px-4 rounded-xl border transition-all flex items-center gap-2.5 text-left text-xs min-w-[140px] md:min-w-[160px] cursor-pointer ${
                  isActive
                    ? 'bg-linear-to-b from-saffron-500 to-saffron-600 text-white border-saffron-600 shadow-md transform -translate-y-0.5'
                    : 'bg-stone-50 hover:bg-stone-100 text-stone-600 border-stone-200'
                }`}
              >
                <div className={`p-1.5 rounded-lg shrink-0 ${isActive ? 'bg-saffron-400/20 text-white' : 'bg-stone-200 text-stone-500'}`}>
                  <IconComponent className="w-4 h-4" />
                </div>
                <div className="flex-1 font-serif">
                  <span className="block font-bold leading-tight">{tab.label}</span>
                  <span className={`block text-[9px] ${isActive ? 'text-saffron-100' : 'text-stone-400'} mt-0.5`}>{tab.hindi}</span>
                </div>
                <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded-full ${
                  isActive ? 'bg-white/20 text-white' : 'bg-stone-200 text-stone-600'
                }`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Catalog Main Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* LEFT COLUMN: Grid elements list */}
          <div className="lg:col-span-4 space-y-3 max-h-[600px] overflow-y-auto pr-1" id="pujas-grid-list">
            {filteredPujas.map((puja) => {
              const isSelected = expandedPujaId === puja.id;
              return (
                <div
                  key={puja.id}
                  onClick={() => setExpandedPujaId(puja.id)}
                  className={`p-4 rounded-xl border transition-all duration-200 cursor-pointer text-left ${
                    isSelected
                      ? 'bg-linear-to-b from-saffron-50 to-saffron-100/50 border-saffron-400 shadow-xs'
                      : 'bg-white hover:bg-stone-50 border-stone-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2.5">
                    <div>
                      <h3 className="font-serif font-bold text-stone-800 text-sm md:text-base leading-snug">
                        {puja.title}
                      </h3>
                      <p className="text-[10px] font-sans font-bold text-saffron-600 mt-0.5">{puja.sanskritName}</p>
                    </div>
                    <span className="text-[10px] font-mono font-bold text-stone-400 whitespace-nowrap">{puja.duration}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* RIGHT COLUMN: Fully detailed visual card */}
          {expandedPujaId && (
            <div className="lg:col-span-8 bg-stone-50/50 rounded-2xl border border-saffron-100 p-6 md:p-8 space-y-8" id="puja-details-hub">
              {(() => {
                const p = pujas.find(item => item.id === expandedPujaId);
                if (!p) return null;
                return (
                  <div className="space-y-6">
                    {/* Visual header */}
                    <div className="flex flex-col sm:flex-row gap-6 items-start">
                      <img
                        src={p.image}
                        alt={p.title}
                        referrerPolicy="no-referrer"
                        className="w-full sm:w-44 h-28 sm:h-36 rounded-xl object-cover shadow-2xs border border-saffron-100"
                      />
                      <div className="space-y-2 flex-1">
                        <span className="text-[10px] text-marigold-500 font-cinzel font-bold tracking-widest uppercase">
                          SCRIPTURAL CEREMONY
                        </span>
                        <h3 className="text-2xl font-serif font-extrabold text-stone-800 leading-tight">
                          {p.title}
                        </h3>
                        <p className="text-xs text-saffron-700 font-cinzel font-bold">{p.sanskritName}</p>
                        <p className="text-xs text-stone-500 font-sans leading-relaxed">{p.description}</p>
                      </div>
                    </div>

                    {/* Planetary Benefits benefits list */}
                    <div className="space-y-3 pt-4 border-t border-stone-150">
                      <h4 className="text-xs font-sans font-bold tracking-wider uppercase text-saffron-700 flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-marigold-500" />
                        <span>Sacred Astrological Benefits</span>
                      </h4>
                      <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-stone-600 font-sans">
                        {p.benefits.map((b, idx) => (
                          <li key={idx} className="flex items-start gap-2 bg-white p-2.5 rounded-lg border border-stone-100 shadow-3xs">
                            <span className="text-emerald-500 shrink-0 font-bold">✓</span>
                            <span>{b}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Interactive Samagri Checklist tool */}
                    <div className="space-y-3 pt-4 border-t border-stone-150 rounded-xl bg-white p-5 border border-stone-150/50">
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                        <div>
                          <h4 className="text-xs font-sans font-bold tracking-wider uppercase text-saffron-700 flex items-center gap-1.5">
                            <CheckSquare className="w-4 h-4 text-marigold-500" />
                            <span>Prepare At Home: Active Samagri Checklist</span>
                          </h4>
                          <p className="text-[10px] text-stone-400 font-sans mt-0.5">Toggle what you already have at home to plan with the Pandit Jee.</p>
                        </div>
                        <span className="text-[10px] font-mono font-bold text-stone-500 bg-stone-100 py-1 px-2 rounded-sm shrink-0">
                          {p.samagriChecklist.filter(item => checkedItems[`${p.id}-${item}`]).length} / {p.samagriChecklist.length} Checked
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-stone-600 font-sans pt-2">
                        {p.samagriChecklist.map((item, idx) => {
                          const isChecked = checkedItems[`${p.id}-${item}`];
                          return (
                            <label
                              key={idx}
                              onClick={() => toggleChecklist(p.id, item)}
                              className={`flex items-center gap-2.5 p-2 rounded-lg border cursor-pointer select-none transition-all ${
                                isChecked
                                  ? 'bg-saffron-50/50 border-saffron-200 text-stone-800'
                                  : 'bg-stone-50/20 border-transparent hover:bg-stone-50 text-stone-500 hover:text-stone-800'
                              }`}
                            >
                              <input
                                type="checkbox"
                                checked={!!isChecked}
                                readOnly
                                className="w-3.5 h-3.5 accent-saffron-600"
                              />
                              <span className={isChecked ? 'line-through text-stone-400' : ''}>{item}</span>
                            </label>
                          );
                        })}
                      </div>
                    </div>

                    {/* Tier Packages & Booking Button */}
                    <div className="space-y-4 pt-4 border-t border-stone-150">
                      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-linear-to-r from-saffron-50 to-saffron-100/30 p-4 border border-saffron-100 rounded-xl">
                        <div className="space-y-1">
                          <span className="text-[10px] text-stone-500 font-sans block">Pricing Configurations</span>
                          <div className="flex flex-wrap gap-4 text-xs font-sans text-stone-700">
                            <div>
                              <strong className="block text-stone-800">Priest Only</strong>
                              <span className="font-serif font-bold text-saffron-700">₹{p.standardPrice}</span>
                            </div>
                            <div className="border-l border-stone-200 pl-4">
                              <strong className="block text-stone-800">Complete Divine Setup</strong>
                              <span className="font-serif font-bold text-saffron-700">₹{p.premiumPrice}</span>
                            </div>
                            <div className="border-l border-stone-200 pl-4">
                              <strong className="block text-stone-800">E-Puja Zoom</strong>
                              <span className="font-serif font-bold text-saffron-700">₹{p.ePujaPrice}</span>
                            </div>
                          </div>
                        </div>

                        <button
                          onClick={() => setBookingPuja(p)}
                          className="w-full md:w-auto bg-saffron-600 hover:bg-saffron-700 text-white font-serif font-bold py-2.5 px-6 rounded-lg transition-all flex items-center justify-center gap-1.5 text-sm md:text-base cursor-pointer shadow-2xs"
                        >
                          <span>Reserve Puja Dates</span>
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}
        </div>
      </div>

      {/* RITUAL RESERVATION INTAKE INTAKE FORM */}
      {bookingPuja && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 shadow-xl" id="puja-booking-window">
          <div className="absolute inset-0 bg-stone-900/60 backdrop-blur-xs" onClick={resetForm} />
          
          <div className="relative bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto border border-saffron-100 shadow-2xl z-10 p-6 md:p-8">
            <button 
              onClick={resetForm}
              className="absolute top-4 right-4 text-stone-400 hover:text-stone-600 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {!successReceipt ? (
              <form onSubmit={handleBookingSubmit} className="space-y-5" id="ritual-booking-form">
                <div className="text-center space-y-1">
                  <span className="text-[10px] font-sans font-bold uppercase text-saffron-600 block">Vedic Allocation</span>
                  <h3 className="text-2xl font-cinzel font-bold text-stone-800 tracking-wide uppercase leading-tight">{bookingPuja.title}</h3>
                  <p className="text-stone-400 text-xs font-sans">
                    Register family gotra and select your ritual date in Patna, Bihar
                  </p>
                </div>

                {/* Package Type switcher */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-sans font-bold text-stone-500 block">Select Package Tier</label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { type: 'standard', label: 'Priest Only', desc: '₹' + bookingPuja.standardPrice },
                      { type: 'premium', label: 'Divine Setup', desc: '₹' + bookingPuja.premiumPrice },
                      { type: 'epuja', label: 'Zoom/E-Puja', desc: '₹' + bookingPuja.ePujaPrice }
                    ].map((item) => (
                      <button
                        key={item.type}
                        type="button"
                        onClick={() => setPackageType(item.type as any)}
                        className={`py-2 px-1 text-xs font-sans rounded-lg border text-center transition-all flex flex-col items-center justify-center ${
                          packageType === item.type
                            ? 'bg-saffron-600 text-white border-saffron-600 shadow-3xs'
                            : 'bg-stone-50 text-stone-600 border-stone-200 hover:bg-stone-100'
                        }`}
                      >
                        <span className="font-bold text-[11px]">{item.label}</span>
                        <span className="opacity-80 text-[10px] block font-mono mt-0.5">{item.desc}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name field */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-sans font-bold text-stone-500 block">Devotee Full Name</label>
                    <input
                      type="text"
                      required
                      value={devoteeName}
                      onChange={(e) => setDevoteeName(e.target.value)}
                      placeholder="e.g. Anand Sharma"
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs md:text-sm focus:outline-hidden focus:border-saffron-500"
                    />
                  </div>

                  {/* Phone field */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-sans font-bold text-stone-500 block">Mobile No. (WhatsApp)</label>
                    <input
                      type="tel"
                      required
                      value={contactPhone}
                      onChange={(e) => setContactPhone(e.target.value)}
                      placeholder="e.g. 75494 25216"
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs md:text-sm focus:outline-hidden focus:border-saffron-500"
                    />
                  </div>

                  {/* Email field */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-sans font-bold text-stone-500 block">Email Address (Optional)</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. anand@gmail.com"
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs md:text-sm focus:outline-hidden focus:border-saffron-500"
                    />
                  </div>

                  {/* Date field */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-sans font-bold text-stone-500 block">Preferred Ritual Date</label>
                    <input
                      type="date"
                      required
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs md:text-sm focus:outline-hidden focus:border-saffron-500"
                    />
                  </div>

                  {/* Time slots */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-sans font-bold text-stone-500 block">Preferred Time Slot</label>
                    <select
                      value={timeSlot}
                      onChange={(e) => setTimeSlot(e.target.value)}
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs md:text-sm focus:outline-hidden focus:border-saffron-500"
                    >
                      <option>05:00 AM - 08:00 AM (Brahma Muhurta)</option>
                      <option>08:00 AM - 11:00 AM (Auspicious Pratah)</option>
                      <option>11:00 AM - 02:00 PM (Madhyahna)</option>
                      <option>02:00 PM - 05:00 PM (Aparahna)</option>
                      <option>05:00 PM - 08:00 PM (Pradosh Altar)</option>
                    </select>
                  </div>

                  {/* Gotra */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-sans font-bold text-stone-500 block">Family Gotra (गोत्र - Optional)</label>
                    <input
                      type="text"
                      value={gotra}
                      onChange={(e) => setGotra(e.target.value)}
                      placeholder="e.g. Kashyap"
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs md:text-sm focus:outline-hidden focus:border-saffron-500"
                    />
                  </div>

                  {/* Nakshatra & Rashi */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-sans font-bold text-stone-500 block">Birth Nakshatra (नक्षत्र - Optional)</label>
                    <input
                      type="text"
                      value={nakshatra}
                      onChange={(e) => setNakshatra(e.target.value)}
                      placeholder="e.g. Rohini"
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs md:text-sm focus:outline-hidden focus:border-saffron-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-sans font-bold text-stone-500 block">Moon Sign (राशि - Optional)</label>
                    <input
                      type="text"
                      value={rashi}
                      onChange={(e) => setRashi(e.target.value)}
                      placeholder="e.g. Vrishabha"
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs md:text-sm focus:outline-hidden focus:border-saffron-500"
                    />
                  </div>
                </div>

                <div className="space-y-1 text-center bg-stone-100/50 p-2.5 rounded-lg">
                  <span className="text-[10px] font-sans text-stone-400 block">Secure Reservation Settlement</span>
                  <span className="font-serif font-extrabold text-saffron-600 text-lg">
                    ₹{packageType === 'standard' ? bookingPuja.standardPrice : packageType === 'premium' ? bookingPuja.premiumPrice : bookingPuja.ePujaPrice}
                  </span>
                </div>

                <button
                  type="submit"
                  className="w-full bg-saffron-600 hover:bg-saffron-700 text-white font-serif font-bold py-3 px-6 rounded-lg transition-colors flex items-center justify-center gap-2 shadow-xs text-sm cursor-pointer"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Generate Priest Blessing Invoice</span>
                </button>
              </form>
            ) : (
              // Success receipts block
              <div className="space-y-6 text-center" id="booking-success-receipt">
                <div className="w-14 h-14 bg-emerald-50 border border-emerald-200 rounded-full flex items-center justify-center text-emerald-600 mx-auto animate-bounce">
                  <Check className="w-8 h-8" />
                </div>
                
                <div className="space-y-1">
                  <h4 className="text-xl font-cinzel font-bold text-stone-800 uppercase">Blessings Reserved!</h4>
                  <p className="text-xs text-stone-500 font-sans">Your reservation is saved secure in local browser ledger storage.</p>
                </div>

                {/* Simulated Invoice Card */}
                <div className="bg-stone-50 border border-dashed border-stone-200 rounded-xl p-5 text-left font-mono text-xs text-stone-600 space-y-3 shadow-inner">
                  <div className="flex justify-between">
                    <span>BOOKING ID:</span>
                    <span className="font-bold text-stone-800">{successReceipt.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>RITUAL CONDUIT:</span>
                    <span className="font-bold text-stone-800 uppercase">{successReceipt.pujaTitle}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>LEAD DEVOTEE:</span>
                    <span className="font-bold text-stone-800">{successReceipt.devoteeName}</span>
                  </div>
                  <div className="flex justify-between font-bold text-saffron-600">
                    <span>GOTRA / NAKSHATRA:</span>
                    <span>{successReceipt.gotra || 'N/A'} / {successReceipt.nakshatra || 'N/A'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>SCHEDULED DATE:</span>
                    <span className="font-bold text-stone-800">{successReceipt.date}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>TIME SLOT:</span>
                    <span className="font-bold text-stone-800">{successReceipt.timeSlot}</span>
                  </div>
                  <div className="flex justify-between border-t border-stone-200 pt-2 text-stone-800 font-bold">
                    <span>TOTAL SETTLEMENT:</span>
                    <span className="text-saffron-600 text-sm">₹{successReceipt.price}</span>
                  </div>
                </div>

                <div className="bg-saffron-50 rounded-lg p-2.5 text-left flex gap-2 border border-saffron-100">
                  <Gift className="w-5 h-5 text-saffron-600 shrink-0 mt-0.5" />
                  <p className="text-[10px] font-sans text-saffron-700 leading-normal">
                    <strong>Prasadi Package:</strong> A certified pure box of coconut prasad and Haridwar Ganga Jal will be handed over directly to the family upon completion.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
                  <button
                    onClick={() => handleWhatsAppForward(successReceipt)}
                    className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white font-sans font-bold py-2.5 px-4 rounded-lg flex items-center justify-center gap-1.5 transition-colors shadow-2xs text-sm cursor-pointer"
                  >
                    <span>Forward to WhatsApp</span>
                  </button>
                  <button
                    onClick={resetForm}
                    className="flex-1 bg-stone-100 hover:bg-stone-200 text-stone-600 py-2.5 px-4 rounded-lg transition-colors text-sm font-semibold cursor-pointer"
                  >
                    <span>Close Ledger</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
