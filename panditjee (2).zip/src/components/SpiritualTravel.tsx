/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Compass, Calendar, ArrowRight, Check, Heart, HelpCircle, Phone, Star, MapPin, X } from 'lucide-react';
import { TravelDestination, TravelPackage, TravelInquiry } from '../types';

interface SpiritualTravelProps {
  destinations: TravelDestination[];
  onAddTravelInquiry: (inquiry: TravelInquiry) => void;
}

const getStarsFromPrice = (price: number): number => {
  if (price < 6000) return 2;
  if (price < 15000) return 3;
  if (price < 30000) return 4;
  return 5;
};

export const SpiritualTravel: React.FC<SpiritualTravelProps> = ({
  destinations,
  onAddTravelInquiry,
}) => {
  const [filter, setFilter] = useState<'all' | 'jyotirlinga' | 'chardham' | 'sacred'>('all');
  const [selectedDestId, setSelectedDestId] = useState(destinations[0]?.id || '');
  const [activeTier, setActiveTier] = useState<'budget' | 'premium' | 'luxury' | 'royalLuxury'>('premium');

  // Booking Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [date, setDate] = useState('');
  const [pilgrims, setPilgrims] = useState(1);
  const [gotra, setGotra] = useState('');
  const [successReceipt, setSuccessReceipt] = useState<TravelInquiry | null>(null);

  const activeDest = destinations.find(d => d.id === selectedDestId) || destinations[0];
  const activePkg = activeDest ? activeDest.packages[activeTier] : null;

  const filteredDests = destinations.filter(d => {
    if (filter === 'all') return true;
    return d.category === filter;
  });

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !date) return;

    const basePrice = activePkg?.price || 0;
    const totalPrice = basePrice * pilgrims;

    const newInquiry: TravelInquiry = {
      id: 'yatra-' + Math.random().toString(36).substr(2, 9),
      destinationId: activeDest.id,
      destinationName: activeDest.name,
      packageTier: activeTier,
      price: totalPrice,
      customerName: name,
      contactPhone: phone,
      preferredDate: date,
      pilgrimsCount: pilgrims,
      gotra: gotra,
      inquiryDate: new Date().toLocaleDateString(),
      status: 'submitted'
    };

    onAddTravelInquiry(newInquiry);
    setSuccessReceipt(newInquiry);
  };

  const handleWhatsAppForward = (inq: TravelInquiry) => {
    const pkgDetails = activeDest.packages[inq.packageTier];
    const message = `Pranam Pandit Jee! I want to submit a Sacred Yatra Tour Inquiry on panditjee.in.
------------------------------------
Yatra ID: ${inq.id}
Destination: *${inq.destinationName}*
Package Selected: *${inq.packageTier.toUpperCase()}*
Lead Pilgrim: _${inq.customerName}_
Contact Phone: _${inq.contactPhone}_
Travel Date: *${inq.preferredDate}*
Pilgrims Count: *${inq.pilgrimsCount} Devotee(s)*
Devotee Family Gotra: _${inq.gotra || 'N/A'}_
Estimated Package Price: *₹${inq.price}* (₹${pkgDetails.price} / pilgrim)
------------------------------------
Inclusions:
- Stay: ${pkgDetails.stay}
- Transport: ${pkgDetails.transport}
- Meals: ${pkgDetails.meals}
- Abhishek/Puja: ${pkgDetails.pujaIncluded}

Please verify the availability and let me know the booking procedures at Bailey Road, Patna.`;

    window.open(`https://wa.me/917549425216?text=${encodeURIComponent(message)}`, '_blank');
  };

  const resetForm = () => {
    setName('');
    setPhone('');
    setDate('');
    setPilgrims(1);
    setGotra('');
    setSuccessReceipt(null);
    setIsModalOpen(false);
  };

  return (
    <section className="py-12 bg-stone-50/50" id="spiritual-yatras-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 space-y-10">
        {/* Section Header */}
        <div className="text-center space-y-3">
          <span className="text-xs font-sans font-bold tracking-widest text-saffron-600 bg-saffron-50 border border-saffron-100 py-1 px-3.5 rounded-full uppercase inline-block">
            Sacred Expeditions
          </span>
          <h2 className="text-3xl md:text-4xl font-cinzel font-bold text-stone-800 tracking-tight">
            Vedic Pilgrim Traveling Options
          </h2>
          <p className="text-sm md:text-base text-stone-500 font-sans max-w-2xl mx-auto leading-relaxed">
            Plan your complete spiritual journey across India. Enjoy certified satvik menus, luxury AC cabins/air charters, premium 4-star stays, and customized gotra-based abhishek rituals conducted by verified priests.
          </p>
        </div>

        {/* Filter Navigation */}
        <div className="flex flex-wrap justify-center gap-2 border-b border-stone-150 pb-6" id="yatra-filters">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 text-xs md:text-sm font-sans font-medium rounded-full transition-all ${
              filter === 'all'
                ? 'bg-saffron-600 text-white shadow-xs'
                : 'bg-white text-stone-600 hover:text-saffron-600 border border-stone-200'
            }`}
          >
            All Holy Places ({destinations.length})
          </button>
          <button
            onClick={() => setFilter('jyotirlinga')}
            className={`px-4 py-2 text-xs md:text-sm font-sans font-medium rounded-full transition-all ${
              filter === 'jyotirlinga'
                ? 'bg-saffron-600 text-white shadow-xs'
                : 'bg-white text-stone-600 hover:text-saffron-600 border border-stone-200'
            }`}
          >
            12 Sacred Jyotirlingas (श्री ज्योतिर्लिंग)
          </button>
          <button
            onClick={() => setFilter('chardham')}
            className={`px-4 py-2 text-xs md:text-sm font-sans font-medium rounded-full transition-all ${
              filter === 'chardham'
                ? 'bg-saffron-600 text-white shadow-xs'
                : 'bg-white text-stone-600 hover:text-saffron-600 border border-stone-200'
            }`}
          >
            Four Moksha Char Dhams (चार धाम)
          </button>
          <button
            onClick={() => setFilter('sacred')}
            className={`px-4 py-2 text-xs md:text-sm font-sans font-medium rounded-full transition-all ${
              filter === 'sacred'
                ? 'bg-saffron-600 text-white shadow-xs'
                : 'bg-white text-stone-600 hover:text-saffron-600 border border-stone-200'
            }`}
          >
            Famous Holy Corridors (पावन धाम/मन्दिर)
          </button>
        </div>

        {/* Dynamic Split Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* LEFT: Destination List Cards (lg:col-span-4) */}
          <div className="lg:col-span-5 space-y-3 max-h-[640px] overflow-y-auto pr-2" id="travel-destinations-sidebar">
            <span className="text-[10px] font-sans font-bold uppercase tracking-wider text-stone-400 block pb-1 border-b border-stone-100">
              Select Your Holy Destination ({filteredDests.length})
            </span>
            {filteredDests.map((dest) => {
              const isSelected = dest.id === selectedDestId;
              return (
                <div
                  key={dest.id}
                  onClick={() => setSelectedDestId(dest.id)}
                  className={`p-3.5 rounded-xl border transition-all duration-200 cursor-pointer flex items-center gap-4 ${
                    isSelected
                      ? 'bg-linear-to-r from-saffron-500 to-saffron-600 border-saffron-600 text-white shadow-md transform translate-x-1'
                      : 'bg-white hover:bg-stone-50 border-stone-200 text-stone-800'
                  }`}
                  id={`dest-card-${dest.id}`}
                >
                  <img
                    src={dest.image}
                    alt={dest.name}
                    referrerPolicy="no-referrer"
                    className="w-14 h-14 rounded-lg object-cover shadow-2xs shrink-0 border border-white/20"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-serif font-bold text-sm md:text-base leading-tight truncate">
                      {dest.name}
                    </h4>
                    <p className={`text-[11px] font-sans flex items-center gap-1 mt-1 ${isSelected ? 'text-saffron-100' : 'text-stone-400'}`}>
                      <MapPin className="w-3.5 h-3.5" />
                      <span className="truncate">{dest.location}</span>
                    </p>
                  </div>
                  <div className="shrink-0">
                    <span className={`text-[9px] font-sans font-bold uppercase tracking-wider px-2 py-0.5 rounded-sm ${
                      isSelected ? 'bg-white/20 text-white' : 'bg-stone-100 text-stone-500'
                    }`}>
                      {dest.category === 'jyotirlinga' ? 'Jyotirlinga' : dest.category === 'chardham' ? 'Char Dham' : 'Sacred'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* RIGHT: Selected Destination Detail view (lg:col-span-8) */}
          {activeDest && (
            <div className="lg:col-span-7 bg-white rounded-2xl border border-saffron-100 shadow-xs overflow-hidden" id="yatra-details-panel">
              {/* Image banner */}
              <div className="relative h-60 w-full overflow-hidden">
                <img
                  src={activeDest.image}
                  alt={activeDest.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-stone-900 via-stone-900/30 to-transparent flex flex-col justify-end p-6 md:p-8">
                  <span className="text-[10px] text-marigold-300 font-sans font-bold tracking-widest uppercase">
                    {activeDest.category === 'jyotirlinga' ? 'ॐ द्वादश ज्योतिर्लिंग' : activeDest.category === 'chardham' ? 'ॐ चार धाम मोक्ष यात्रा' : 'ॐ प्रसिद्ध पावन धाम'}
                  </span>
                  <h3 className="text-2xl md:text-3xl font-cinzel font-bold text-white tracking-wide mt-1">
                    {activeDest.name}
                  </h3>
                  <p className="text-xs text-stone-300 font-sans flex items-center gap-1.5 mt-1.5">
                    <MapPin className="w-4 h-4 text-marigold-500 shrink-0" />
                    <span>{activeDest.location}</span>
                  </p>
                </div>
              </div>

              {/* Text significance & history info */}
              <div className="p-6 md:p-8 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <span className="text-[10px] text-stone-400 font-sans font-bold tracking-wider uppercase block">Significance / History</span>
                    <p className="text-xs text-stone-600 font-sans leading-relaxed">{activeDest.description}</p>
                  </div>
                  <div className="space-y-1.5 border-t md:border-t-0 md:border-l border-stone-100 pt-3 md:pt-0 md:pl-4">
                    <span className="text-[10px] text-saffron-600 font-sans font-bold tracking-wider uppercase block">Holy Sankalpa Blessings</span>
                    <p className="text-xs text-stone-600 font-sans leading-relaxed">{activeDest.significance}</p>
                  </div>
                </div>

                {/* Package Tier switcher */}
                <div className="space-y-4 pt-4 border-t border-stone-100">
                  <div className="flex flex-wrap md:flex-nowrap justify-between items-center bg-stone-50 border border-stone-200/50 p-1.5 rounded-xl gap-1">
                    {(['budget', 'premium', 'luxury', 'royalLuxury'] as const).map((tier) => (
                      <button
                        key={tier}
                        onClick={() => setActiveTier(tier)}
                        className={`flex-1 min-w-[80px] py-1.5 text-xs font-sans font-bold rounded-lg transition-all capitalize select-none ${
                          activeTier === tier
                            ? 'bg-saffron-600 text-white shadow-xs'
                            : 'text-stone-500 hover:text-saffron-600'
                        }`}
                      >
                        {tier === 'budget' ? 'Budget' : tier === 'premium' ? 'Premium' : tier === 'luxury' ? 'Luxury' : 'Royal Luxury'}
                      </button>
                    ))}
                  </div>

                  {activePkg && (
                    <div className="bg-saffron-50/50 border border-saffron-100 p-5 rounded-xl space-y-4">
                      {/* Package details */}
                      <div className="flex justify-between items-center">
                        <div>
                          <span className="text-[11px] font-sans font-bold uppercase tracking-wider text-saffron-600 bg-saffron-100/80 px-2 py-0.5 rounded-sm">
                            {activeTier === 'budget' ? 'Comfort & Economy' : activeTier === 'premium' ? 'Boutique & VIP Fast-Track' : activeTier === 'luxury' ? 'Premium Luxury Haven' : 'Ultra-Luxury Royal Protocol'}
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-stone-400 text-[10px] block font-sans">Estimated Cost</span>
                          <span className="font-serif font-extrabold text-xl text-saffron-700">₹{activePkg.price}</span>
                          <span className="text-[10px] text-stone-500 font-sans block">per pilgrim/devotee</span>
                        </div>
                      </div>

                      {/* Bullet list of specs */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs text-stone-700 font-sans pt-1">
                        <div className="flex items-start gap-2">
                          <span className="text-saffron-600 shrink-0 font-bold">🏫</span>
                          <div>
                            <strong className="block text-stone-800">Stay</strong>
                            <div className="flex flex-col sm:flex-row sm:items-center gap-1.5">
                              <span className="text-stone-500 text-[11px] font-medium">{activePkg.stay}</span>
                              <div className="flex items-center gap-0.5 text-amber-500 shrink-0">
                                {Array.from({ length: getStarsFromPrice(activePkg.price) }).map((_, index) => (
                                  <Star key={index} className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <span className="text-saffron-600 shrink-0 font-bold">✈️</span>
                          <div>
                            <strong className="block text-stone-800">Transit Mode</strong>
                            <span className="text-stone-500 text-[11px]">{activePkg.transport}</span>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <span className="text-saffron-600 shrink-0 font-bold">🍉</span>
                          <div>
                            <strong className="block text-stone-800">Catering</strong>
                            <span className="text-stone-500 text-[11px]">{activePkg.meals}</span>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <span className="text-saffron-600 shrink-0 font-bold">🔱</span>
                          <div>
                            <strong className="block text-stone-800">Personalized Puja</strong>
                            <span className="text-stone-500 text-[11px]">{activePkg.pujaIncluded}</span>
                          </div>
                        </div>
                      </div>

                      {/* Exquisite inclusions checklist */}
                      <div className="pt-3 border-t border-saffron-100 space-y-2">
                        <span className="text-[10px] font-sans font-bold uppercase tracking-wider text-saffron-600">Included Privileges</span>
                        <div className="flex flex-wrap gap-2">
                          {activePkg.inclusions.map((inc, i) => (
                            <span key={i} className="bg-white border border-saffron-100 rounded-sm py-1 px-2 text-[10px] font-sans text-stone-600 flex items-center gap-1.5 shadow-3xs">
                              <Check className="w-3 h-3 text-emerald-500 shrink-0" />
                              <span>{inc}</span>
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Order Action Button */}
                      <div className="pt-2">
                        <button
                          onClick={() => {
                            setSuccessReceipt(null);
                            setIsModalOpen(true);
                          }}
                          className="w-full bg-linear-to-r from-saffron-600 to-saffron-700 hover:from-saffron-700 hover:to-saffron-800 text-white font-serif font-bold py-3 px-6 rounded-lg shadow-sm hover:shadow-md transition-all flex items-center justify-center gap-2 text-sm md:text-base cursor-pointer"
                        >
                          <span>Plan Holy Journey to {activeDest.name}</span>
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* YATRA INTAKE FORM MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" id="yatra-modal-overlay">
          <div className="absolute inset-0 bg-stone-900/60 backdrop-blur-xs" onClick={resetForm} />
          
          <div className="relative bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto border border-saffron-100 shadow-2xl z-10 p-6 md:p-8">
            <button 
              onClick={resetForm}
              className="absolute top-4 right-4 text-stone-400 hover:text-stone-600 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {!successReceipt ? (
              <form onSubmit={handleBookingSubmit} className="space-y-5" id="yatra-intake-form">
                <div className="text-center space-y-1">
                  <span className="text-[10px] font-sans font-bold uppercase text-saffron-600 block">Sankalpa Registration</span>
                  <h3 className="text-2xl font-cinzel font-bold text-stone-800 uppercase tracking-wide">Yatra Planning Desk</h3>
                  <p className="text-stone-400 text-xs font-sans">
                    Register lead pilgrim and gotra parameters for {activeDest?.name} ({activeTier.toUpperCase()})
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name field */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-sans font-bold text-stone-500 block">Lead Pilgrim Full Name</label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Abhinav Mishra"
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs md:text-sm focus:outline-hidden focus:border-saffron-500"
                    />
                  </div>

                  {/* Phone field */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-sans font-bold text-stone-500 block">Contact Mobile (WhatsApp Preferred)</label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="e.g. 75494 25216"
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs md:text-sm focus:outline-hidden focus:border-saffron-500"
                    />
                  </div>

                  {/* Date field */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-sans font-bold text-stone-500 block">Preferred Journey Date</label>
                    <input
                      type="date"
                      required
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs md:text-sm focus:outline-hidden focus:border-saffron-500"
                    />
                  </div>

                  {/* Pilgrim count field */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-sans font-bold text-stone-500 block">Devotees Count (No. of Pilgrims)</label>
                    <input
                      type="number"
                      min={1}
                      max={50}
                      required
                      value={pilgrims}
                      onChange={(e) => setPilgrims(parseInt(e.target.value))}
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs md:text-sm focus:outline-hidden focus:border-saffron-500"
                    />
                  </div>

                  {/* Gotra parameters (highly traditional!) */}
                  <div className="space-y-1 sm:col-span-2">
                    <label className="text-[11px] font-sans font-bold text-stone-500 block">Family Gotra / Sankalpa Star (गोत्र / नक्षत्र - Optional)</label>
                    <input
                      type="text"
                      value={gotra}
                      onChange={(e) => setGotra(e.target.value)}
                      placeholder="e.g. Shandilya / Ashwini Nakshatra"
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-xs md:text-sm focus:outline-hidden focus:border-saffron-500"
                    />
                  </div>
                </div>

                <div className="space-y-3 pt-2">
                  <div className="flex justify-between items-center text-xs border-t border-stone-100 pt-3">
                    <span className="text-stone-400 font-sans">Single Package price:</span>
                    <span className="font-semibold text-stone-700">₹{activePkg?.price}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-stone-500 font-sans font-semibold">Total Estimated Amount:</span>
                    <span className="font-serif font-extrabold text-saffron-600 text-lg">₹{(activePkg?.price || 0) * pilgrims}</span>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-saffron-600 hover:bg-saffron-700 text-white font-serif font-bold py-3 px-6 rounded-lg transition-colors flex items-center justify-center gap-2 shadow-sm text-sm"
                >
                  <Compass className="w-4 h-4" />
                  <span>Generate Travel Inquiry Receipt</span>
                </button>
              </form>
            ) : (
              // Success receipts block
              <div className="space-y-6 text-center" id="yatra-success-receipt">
                <div className="w-14 h-14 bg-emerald-50 border border-emerald-200 rounded-full flex items-center justify-center text-emerald-600 mx-auto animate-bounce">
                  <Check className="w-8 h-8" />
                </div>
                
                <div className="space-y-2">
                  <h4 className="text-xl font-cinzel font-bold text-stone-800">Shubh Yatra Inquired!</h4>
                  <p className="text-xs text-stone-500 font-sans">Your travel enquiry has been cataloged in local storage Devotion Ledger.</p>
                </div>

                {/* Simulated Invoice Card */}
                <div className="bg-stone-50 border border-dashed border-stone-200 rounded-xl p-5 text-left font-mono text-xs text-stone-600 space-y-3 shadow-inner">
                  <div className="flex justify-between">
                    <span>INQUIRY ID:</span>
                    <span className="font-bold text-stone-800">{successReceipt.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>DESTINATION:</span>
                    <span className="font-bold text-stone-800 uppercase">{successReceipt.destinationName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>PILGRIM LEADER:</span>
                    <span className="font-bold text-stone-800">{successReceipt.customerName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>GOTRA:</span>
                    <span className="font-bold text-stone-800">{successReceipt.gotra || 'NONE'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>PILGRIMS COUNT:</span>
                    <span className="font-bold text-stone-800">{successReceipt.pilgrimsCount} Devotee(s)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>PREFERRED DATE:</span>
                    <span className="font-bold text-stone-800">{successReceipt.preferredDate}</span>
                  </div>
                  <div className="flex justify-between border-t border-stone-200 pt-2 text-stone-800 font-bold">
                    <span>TOTAL INVOICE (INR):</span>
                    <span className="text-saffron-600 text-sm">₹{successReceipt.price}</span>
                  </div>
                </div>

                <p className="text-xs text-saffron-600 font-sans font-medium px-2 leading-relaxed">
                  ⚠️ To confirm scheduling and secure flight/helicopter slots or rooms, you must forward these details to our Bailey Road office.
                </p>

                <div className="flex flex-col sm:flex-row gap-2.5">
                  <button
                    onClick={() => handleWhatsAppForward(successReceipt)}
                    className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white font-sans font-bold py-2.5 px-4 rounded-lg flex items-center justify-center gap-1.5 transition-colors shadow-2xs text-sm cursor-pointer"
                  >
                    <span>Send to WhatsApp</span>
                  </button>
                  <button
                    onClick={resetForm}
                    className="flex-1 bg-stone-100 hover:bg-stone-200 text-stone-600 py-2.5 px-4 rounded-lg transition-colors text-sm font-semibold cursor-pointer"
                  >
                    <span>Close Window</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
