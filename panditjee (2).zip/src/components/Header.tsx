/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Compass, Calendar, ShoppingBag, BookOpen, Clock, Phone, Heart, FileText } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenHistory: () => void;
  historyCounts: {
    bookings: number;
    orders: number;
    travels: number;
  };
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenHistory,
  historyCounts,
}) => {
  const totalCount = historyCounts.bookings + historyCounts.orders + historyCounts.travels;

  const handleWhatsApp = () => {
    const text = encodeURIComponent(
      "Pranam Pandit Jee, I am visiting panditjee.in and wanted to inquire about standard puja and sacred travel services in Patna, Bihar."
    );
    window.open(`https://wa.me/917549425216?text=${text}`, '_blank');
  };

  const menuItems = [
    { id: 'home', label: 'Home', icon: Compass },
    { id: 'pujas', label: 'Book Pujas', icon: Heart },
    { id: 'samagri', label: 'Pooja Samagri', icon: ShoppingBag },
    { id: 'travel', label: 'Sacred Yatras', icon: Compass },
    { id: 'calendar', label: 'Vedic Calendar', icon: Calendar },
    { id: 'about', label: 'About Us', icon: BookOpen },
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-white border-b border-saffron-100 shadow-xs">
      {/* Top Auspicious Ticker Banner */}
      <div className="w-full bg-linear-to-r from-saffron-600 via-saffron-500 to-marigold-600 text-white py-1.5 px-4 text-xs font-sans text-center font-medium tracking-wide flex justify-between items-center sm:px-6">
        <div className="hidden md:flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
          <span>PanditJee.in — Bailey Road, Patna, Bihar, India</span>
        </div>
        <div className="mx-auto md:mx-0 font-medium">
          ॐ सर्वमंगल मांगल्ये शिवे सर्वार्थ साधिके | WhatsApp Support: +91 75494 25216
        </div>
        <div className="hidden md:flex items-center gap-4">
          <button 
            onClick={handleWhatsApp}
            className="text-white hover:text-saffron-100 transition-colors flex items-center gap-1 font-semibold"
          >
            <span>💬 Live Chat</span>
          </button>
        </div>
      </div>

      {/* Main Logo & Action Bar */}
      <div className="w-full max-w-7xl mx-auto px-4 md:px-8 py-4 flex flex-col sm:flex-row justify-between items-center gap-4">
        {/* Brand Logo */}
        <div 
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-3 cursor-pointer group"
          id="brand-logo"
        >
          <div className="w-11 h-11 bg-saffron-50 border border-saffron-200 rounded-full flex items-center justify-center text-saffron-600 group-hover:bg-saffron-100 transition-all duration-300 shadow-xs animate-vedic-float">
            <span className="text-2xl font-cinzel select-none font-bold">ॐ</span>
          </div>
          <div>
            <span className="text-2xl font-cinzel font-bold text-saffron-600 tracking-wide">
              Pandit<span className="text-marigold-500 font-serif">Jee</span>.in
            </span>
            <p className="text-[10px] font-sans text-stone-400 tracking-widest uppercase">Patna's Holy Vedic Portal</p>
          </div>
        </div>

        {/* Quick Contacts & Ledger Button */}
        <div className="flex items-center gap-3">
          <a 
            href="tel:+917549425216"
            className="hidden sm:flex items-center gap-2 text-stone-600 hover:text-saffron-600 bg-stone-50 border border-stone-200 py-1.5 px-3.5 rounded-full transition-all text-sm font-medium"
          >
            <Phone className="w-4 h-4 text-marigold-500" />
            <span>+91 75494 25216</span>
          </a>

          <button
            onClick={onOpenHistory}
            className="relative flex items-center gap-2 bg-saffron-50 text-saffron-700 border border-saffron-200 hover:bg-saffron-100 py-1.5 px-4 rounded-full transition-all text-sm font-medium"
            id="devotion-ledger-btn"
          >
            <FileText className="w-4 h-4 text-saffron-600" />
            <span>My Bookings</span>
            {totalCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-saffron-600 text-white font-mono text-[10px] w-5 h-5 rounded-full flex items-center justify-center font-bold shadow-xs">
                {totalCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Tabs Navigation Layout */}
      <div className="w-full border-t border-stone-100 bg-stone-50/50">
        <nav className="w-full max-w-7xl mx-auto px-2 md:px-6 overflow-x-auto flex justify-start sm:justify-center items-center scrollbar-none">
          <div className="flex py-1.5 md:py-2.5 gap-1 md:gap-2">
            {menuItems.map((item) => {
              const IconComp = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-1.5 font-sans px-3.5 py-1.5 rounded-lg text-sm transition-all duration-200 select-none ${
                    isActive
                      ? 'bg-saffron-600 text-white font-medium shadow-xs border-saffron-600'
                      : 'text-stone-600 hover:text-saffron-600 hover:bg-saffron-50/50 border border-transparent'
                  }`}
                  id={`nav-tab-${item.id}`}
                >
                  <IconComp className={`w-4 h-4 ${isActive ? 'text-white' : 'text-stone-400'}`} />
                  <span className="whitespace-nowrap">{item.label}</span>
                </button>
              );
            })}
          </div>
        </nav>
      </div>
    </header>
  );
};
