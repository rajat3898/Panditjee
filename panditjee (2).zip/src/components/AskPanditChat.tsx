/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, MessageSquare, AlertCircle, RefreshCw } from 'lucide-react';
import { Puja } from '../types';

interface AskPanditChatProps {
  pujas: Puja[];
  onOpenBookingModal: (puja: Puja) => void;
}

interface Message {
  id: string;
  sender: 'user' | 'pandit';
  text: string;
  recommendedPujaId?: string;
  timestamp: string;
}

export const AskPanditChat: React.FC<AskPanditChatProps> = ({ pujas, onOpenBookingModal }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'pandit',
      text: "Pranam! I am Acharya Vedant, your traditional Vedic consultant. Share with me your birth details, ongoing challenges (career blocks, marriages delays, Vastu errors, or family concerns), and I shall guide you on scriptural remedies, planetary mantras, and customized pujas.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [useFallback, setUseFallback] = useState(false);

  const endOfMessagesRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const findPujaByIdOrKeyword = (userInput: string): Puja | undefined => {
    const text = userInput.toLowerCase();
    if (text.includes('home') || text.includes('house') || text.includes('grah') || text.includes('grahpravesh') || text.includes('griha')) {
      return pujas.find(p => p.id === 'grihapravesh') || pujas[1];
    }
    if (text.includes('vastu') || text.includes('direction') || text.includes('map') || text.includes('office')) {
      return pujas.find(p => p.id === 'vastushanti') || pujas[3];
    }
    if (text.includes('career') || text.includes('job') || text.includes('business') || text.includes('study') || text.includes('exam') || text.includes('obstacle') || text.includes('fail')) {
      return pujas.find(p => p.id === 'ganeshahavan') || pujas[4];
    }
    if (text.includes('ill') || text.includes('health') || text.includes('disease') || text.includes('hospit') || text.includes('death') || text.includes('life')) {
      return pujas.find(p => p.id === 'mrityunjaya') || pujas[5];
    }
    if (text.includes('marriage') || text.includes('wedding') || text.includes('vivah') || text.includes('love') || text.includes('shadi')) {
      return pujas.find(p => p.id === 'vivah') || pujas[6];
    }
    if (text.includes('shiva') || text.includes('rudra') || text.includes('somnath') || text.includes('abhishek') || text.includes('debt') || text.includes('money')) {
      return pujas.find(p => p.id === 'rudrabhishek') || pujas[2];
    }
    if (text.includes('planet') || text.includes('graha') || text.includes('dasha') || text.includes('shani') || text.includes('rahu') || text.includes('ketu')) {
      return pujas.find(p => p.id === 'navgrahshanti') || pujas[7];
    }
    if (text.includes('snake') || text.includes('kaal') || text.includes('sarp') || text.includes('dream') || text.includes('scared')) {
      return pujas.find(p => p.id === 'kaalsarp') || pujas[8];
    }
    if (text.includes('chhath') || text.includes('sun') || text.includes('surya') || text.includes('patna') || text.includes('bihar')) {
      return pujas.find(p => p.id === 'chhathspecial') || pujas[9];
    }
    // Default
    return pujas.find(p => p.id === 'satyanarayan') || pujas[0];
  };

  const getLocalFallbackReply = (userInput: string) => {
    const text = userInput.toLowerCase();
    let reply = "";
    let recommendedPujaId: string | undefined;

    const recommendedPuja = findPujaByIdOrKeyword(userInput);

    if (text.includes('home') || text.includes('house') || text.includes('griha')) {
      reply = `According to the ancient Griha Parishistha, establishing a new residence requires purging previous elemental weights. I suggest scheduling the auspicious **Griha Pravesh Puja** inside your sweet Patna residence. I recommend purifying the entry lintel using sacred Ganga Jal.`;
      recommendedPujaId = recommendedPuja?.id;
    } else if (text.includes('vastu') || text.includes('direction')) {
      reply = `Directions dictate harmony. Any heavy elements on the Northern / Eastern walls cause Vastu frictions, which block career streams in Patna. I advice performing the **Vastu Shanti Ceremony & Havan** to balance your directional matrices.`;
      recommendedPujaId = recommendedPuja?.id;
    } else if (text.includes('career') || text.includes('job') || text.includes('business') || text.includes('study')) {
      reply = `To clear obstacles during your examinations or career elevations, invoke the Ganesha intelligence. I highly suggest dedicating a **Vighnaharta Ganesha Havan** with durva grass chanting to secure steady concentration and luck.`;
      recommendedPujaId = recommendedPuja?.id;
    } else if (text.includes('health') || text.includes('ill') || text.includes('disease')) {
      reply = `Srimad Bhagavad Mahatmya dictates that severe ailments are alleviated by Lord Tryambateshwar's nectar shield. Conduct the **Maha Mrityunjaya Havan & Jaap** with special giloy herbal sticks for active rejuvenation. Let us handle the scriptural chanting for your family.`;
      recommendedPujaId = recommendedPuja?.id;
    } else if (text.includes('marriage') || text.includes('wedding') || text.includes('vivah')) {
      reply = `Matrimony unites two ancestral lines creating cosmic balance. I recommend the **Vedic Vivah Sanskar** according to pure regional Bihar rituals. Alternately, perform **Sri Satyanarayan Puja** on Purnima for healthy union progress.`;
      recommendedPujaId = recommendedPuja?.id;
    } else if (text.includes('shiva') || text.includes('rudra') || text.includes('abhishek')) {
      reply = `Bathing Lord Shiva on standard Pradosh tithis washes financial debts and clears ongoing obstacles. I highly advise scheduling the **Maha Rudrabhishek Puja** using raw cow milk and pure Haridwar Ganga Jal on our dashboard.`;
      recommendedPujaId = recommendedPuja?.id;
    } else if (text.includes('planet') || text.includes('rahu') || text.includes('shani') || text.includes('dasha')) {
      reply = `Astrological celestial movements (especially Sade-Sati or Ketu transits) govern daily struggles. appeasing the planetary councils via the **Navgrah Shanti Puja** will bring immediate financial and health stability, clearing mental anxiety.`;
      recommendedPujaId = recommendedPuja?.id;
    } else if (text.includes('snake') || text.includes('kaal') || text.includes('sarp')) {
      reply = `The placement of all planets between Rahu and Ketu in your Kundli creates Kaal Sarp friction. The sacred remedy ceremony **Kaal Sarp Dosh Nivaran Puja** with silver serpent installations will release these specific blocks.`;
      recommendedPujaId = recommendedPuja?.id;
    } else {
      reply = `Om Namah Shivaya. Devotion brings steady illumination. For general family welfare and positive cosmic vibes inside your house, I suggest conducting a clean **Sri Satyanarayan Puja & Katha** on any upcoming Full Moon (Purnima) day.`;
      recommendedPujaId = recommendedPuja?.id;
    }

    return { text: reply, recommendedPujaId };
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMsg: Message = {
      id: Math.random().toString(),
      sender: 'user',
      text: input,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    // Call the server Gemini endpoint
    try {
      if (useFallback) {
        throw new Error("Local fallback mode forced");
      }

      const response = await fetch('/api/ask-pandit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ question: userMsg.text }),
      });

      if (!response.ok) {
        throw new Error("Server error, attempting offline response");
      }

      const data = await response.json();
      const recommendedPujaObj = findPujaByIdOrKeyword(userMsg.text);

      const panditMsg: Message = {
        id: Math.random().toString(),
        sender: 'pandit',
        text: data.answer || "I have received your inquiry. Let us conduct special prayers.",
        recommendedPujaId: recommendedPujaObj?.id,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, panditMsg]);
    } catch (err) {
      console.warn("Gemini API server route down, sliding back to traditional local Astrological rules.", err);
      // fallback
      const fallbackResult = getLocalFallbackReply(userMsg.text);
      const panditMsg: Message = {
        id: Math.random().toString(),
        sender: 'pandit',
        text: fallbackResult.text + " (Vedic traditional remedy suggested locally.)",
        recommendedPujaId: fallbackResult.recommendedPujaId,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, panditMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRecommenededPujaBtn = (pujaId: string) => {
    const p = pujas.find(item => item.id === pujaId);
    if (p) {
      onOpenBookingModal(p);
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-saffron-100 shadow-sm flex flex-col h-[520px]" id="pandit-chat-block">
      {/* Pandit Profile Header */}
      <div className="p-4 bg-linear-to-b from-saffron-50 to-white border-b border-saffron-100 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-full bg-saffron-100 border border-saffron-200 flex items-center justify-center font-cinzel text-lg font-bold text-saffron-700 shadow-inner">
              AV
            </div>
            <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white"></span>
          </div>
          <div>
            <h3 className="font-serif font-bold text-stone-800 text-sm md:text-base flex items-center gap-1">
              Acharya Vedant
              <Sparkles className="w-4 h-4 text-marigold-500 animate-pulse fill-marigold-500" />
            </h3>
            <p className="text-[10px] font-sans text-stone-400">Chief Vedic Priest & Astro Guide</p>
          </div>
        </div>

        <button 
          onClick={() => setUseFallback(prev => !prev)}
          className={`flex items-center gap-1.5 py-1 px-2 rounded-lg text-[10px] border transition-all ${
            useFallback 
              ? 'bg-saffron-50 text-saffron-700 border-saffron-200' 
              : 'bg-stone-50 text-stone-500 border-stone-200'
          }`}
          title="Toggle fallback traditional logic vs Gemini AI"
        >
          <RefreshCw className="w-3 h-3" />
          <span>{useFallback ? 'Offline Mode' : 'AI Active'}</span>
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-stone-50/50">
        {messages.map((m) => (
          <div 
            key={m.id} 
            className={`flex flex-col max-w-[85%] ${m.sender === 'user' ? 'ml-auto items-end' : 'mr-auto items-start'}`}
            id={`chat-msg-${m.id}`}
          >
            <div className={`p-3.5 rounded-2xl text-sm font-sans leading-relaxed shadow-3xs ${
              m.sender === 'user'
                ? 'bg-saffron-600 text-white rounded-tr-none'
                : 'bg-white text-stone-800 border border-saffron-100/70 rounded-tl-none'
            }`}>
              <p className="whitespace-pre-line">{m.text}</p>
              
              {/* Recommended Clickable Action Button */}
              {m.recommendedPujaId && (
                <div className="mt-3 pt-3 border-t border-saffron-50 flex flex-col gap-1.5" id="remedy-action-block">
                  <span className="text-[10px] text-saffron-500 font-bold uppercase tracking-wider block">Recommended Remedy Ritual</span>
                  <button
                    onClick={() => handleRecommenededPujaBtn(m.recommendedPujaId!)}
                    className="w-full text-center bg-saffron-50 hover:bg-saffron-100 text-saffron-700 font-serif font-bold text-xs py-2 px-3 rounded-lg border border-saffron-200 flex items-center justify-center gap-1.5 transition-all text-sm shadow-2xs"
                  >
                    <span>Book {pujas.find(x => x.id === m.recommendedPujaId)?.title || 'Remedy ceremony'}</span>
                  </button>
                </div>
              )}
            </div>
            <span className="text-[9px] text-stone-400 font-mono mt-1 px-1">{m.timestamp}</span>
          </div>
        ))}

        {isLoading && (
          <div className="flex flex-col items-start max-w-[80%]">
            <div className="p-4 bg-white rounded-2xl rounded-tl-none border border-saffron-100/50 flex items-center gap-2">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-saffron-500 rounded-full animate-bounce delay-100"></span>
                <span className="w-2 h-2 bg-marigold-500 rounded-full animate-bounce delay-200"></span>
                <span className="w-2 h-2 bg-saffron-600 rounded-full animate-bounce delay-300"></span>
              </div>
              <span className="text-xs text-stone-400 font-sans italic">Acharya is consulting Vedic charts...</span>
            </div>
          </div>
        )}
        <div ref={endOfMessagesRef} />
      </div>

      {/* Input Message Form */}
      <form onSubmit={handleSend} className="p-3 border-t border-stone-100 bg-white flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about Kundli obstacles, Vastu, Sade Sati..."
          disabled={isLoading}
          className="flex-1 bg-stone-50 border border-stone-200 rounded-xl px-4 py-2.5 text-sm focus:outline-hidden focus:border-saffron-500 transition-colors placeholder:text-stone-400"
          id="chat-input-field"
        />
        <button
          type="submit"
          disabled={!input.trim() || isLoading}
          className="bg-saffron-600 hover:bg-saffron-700 disabled:bg-stone-200 text-white p-2.5 rounded-xl transition-colors shrink-0 flex items-center justify-center shadow-xs"
          id="chat-send-btn"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
