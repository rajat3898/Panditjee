/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ShoppingBag, Search, Check, Gift, ArrowRight, X, Trash2 } from 'lucide-react';
import { SamagriKit, Order } from '../types';

interface PoojaSamagriStoreProps {
  samagriKits: SamagriKit[];
  onAddOrder: (order: Order) => void;
}

export const PoojaSamagriStore: React.FC<PoojaSamagriStoreProps> = ({
  samagriKits,
  onAddOrder,
}) => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'katha-puja' | 'havan-special' | 'daily-essentials'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [boxTiers, setBoxTiers] = useState<Record<string, 'standard' | 'premium'>>({});

  // Checkout modal states
  const [checkoutKit, setCheckoutKit] = useState<SamagriKit | null>(null);
  const [customerName, setCustomerName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [successReceipt, setSuccessReceipt] = useState<Order | null>(null);

  const handleTierToggle = (kitId: string, tier: 'standard' | 'premium') => {
    setBoxTiers(prev => ({
      ...prev,
      [kitId]: tier
    }));
  };

  const getKitPrice = (kit: SamagriKit) => {
    const tier = boxTiers[kit.id] || 'standard';
    return tier === 'premium' ? kit.premiumPrice : kit.standardPrice;
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!checkoutKit || !customerName || !contactPhone || !deliveryAddress) return;

    const chosenTier = boxTiers[checkoutKit.id] || 'standard';
    const finalPrice = getKitPrice(checkoutKit);

    const newOrder: Order = {
      id: 'cod-' + Math.random().toString(36).substr(2, 9),
      kitId: checkoutKit.id,
      kitTitle: checkoutKit.title,
      packageType: chosenTier,
      price: finalPrice,
      customerName,
      contactPhone,
      deliveryAddress,
      orderDate: new Date().toLocaleDateString(),
      status: 'processing'
    };

    onAddOrder(newOrder);
    setSuccessReceipt(newOrder);
  };

  const handleWhatsAppForward = (o: Order) => {
    const message = `Pranam Pandit Jee! I want to confirm my Cash-On-Delivery Order for Pooja Samagri.
------------------------------------
Order ID: *${o.id}*
Samagri Set: *${o.kitTitle}*
Selected Packing: *${o.packageType.toUpperCase()} Box*
------------------------------------
SHIPPING INFORMATION (PATNA):
Recipient Name: _${o.customerName}_
Contact Phone: _${o.contactPhone}_
Patna Delivery Address: _${o.deliveryAddress}_
------------------------------------
Bill Summary:
Delivery Fee: FREE SHIPPING
Settlement Amount: *₹${o.price}*
Payment Mode: *CASH ON DELIVERY (COD)*

Please dispatch this order from your Bailey Road center to my Patna location.`;

    window.open(`https://wa.me/917549425216?text=${encodeURIComponent(message)}`, '_blank');
  };

  const resetForm = () => {
    setCheckoutKit(null);
    setCustomerName('');
    setContactPhone('');
    setDeliveryAddress('');
    setSuccessReceipt(null);
  };

  const filteredKits = samagriKits.filter(kit => {
    const matchesCategory = activeCategory === 'all' || kit.category === activeCategory;
    const matchesSearch = kit.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          kit.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <section className="py-12 bg-stone-50/50" id="pooja-samagri-store">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 space-y-10">
        
        {/* Header Block */}
        <div className="text-center space-y-3">
          <span className="text-xs font-sans font-bold tracking-widest text-saffron-600 bg-saffron-50 border border-saffron-100 py-1 px-3.5 rounded-full uppercase inline-block font-sans">
            Spiritual Essentials
          </span>
          <h2 className="text-3xl md:text-4xl font-cinzel font-bold text-stone-800 tracking-tight">
            Curated Premium Pooja Samagri Boxes
          </h2>
          <p className="text-sm md:text-base text-stone-500 font-sans max-w-2xl mx-auto leading-relaxed">
            Order complete, pristine, and verified Pooja bundles. Avoid running around Patna's busy lanes — everything from gangajal to pure cow ghee is meticulously packed and delivered to your doorstep.
          </p>
        </div>

        {/* Filter Navigation & Search bar */}
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between border-b border-stone-200/55 pb-6">
          {/* Category Tabs */}
          <div className="flex flex-wrap gap-2" id="store-category-tabs">
            {(['all', 'katha-puja', 'havan-special', 'daily-essentials'] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`py-1.5 px-3.5 text-xs font-sans font-medium rounded-lg capitalize transition-all select-none ${
                  activeCategory === cat
                    ? 'bg-saffron-600 text-white shadow-3xs'
                    : 'bg-white text-stone-600 hover:text-saffron-600 border border-stone-200'
                }`}
              >
                {cat === 'all' ? 'All Packages' : cat === 'katha-puja' ? 'Katha & Pujas' : cat === 'havan-special' ? 'Havan Specials' : 'Daily Essentials'}
              </button>
            ))}
          </div>

          {/* Search bar */}
          <div className="w-full md:w-80 relative flex" id="samagri-search">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search samagri boxes..."
              className="w-full bg-white border border-stone-200 focus:border-saffron-500 focus:outline-hidden py-1.5 pl-4 pr-10 rounded-lg text-xs placeholder:text-stone-400"
            />
            <Search className="w-4 h-4 absolute right-3.5 top-2.5 text-stone-400" />
          </div>
        </div>

        {/* E-commerce grid showcase */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="samagri-products-grid">
          {filteredKits.map((kit) => {
            const chosenTier = boxTiers[kit.id] || 'standard';
            const price = getKitPrice(kit);
            return (
              <div 
                key={kit.id} 
                className="bg-white rounded-2xl border border-saffron-100/60 shadow-3xs overflow-hidden flex flex-col justify-between"
                id={`kit-card-${kit.id}`}
              >
                {/* Photo & badges */}
                <div className="relative h-48 overflow-hidden bg-stone-100">
                  <img
                    src={kit.image}
                    alt={kit.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                  />
                  <div className="absolute top-3 left-3 bg-saffron-600/90 text-white text-[10px] font-sans font-bold tracking-wider uppercase px-2 py-0.5 rounded-sm">
                    {kit.category === 'katha-puja' ? 'Katha Setup' : kit.category === 'havan-special' ? 'Havan Special' : 'Mandir Daily'}
                  </div>
                </div>

                {/* Card information detail */}
                <div className="p-5 flex-1 flex flex-col justify-between gap-5">
                  <div className="space-y-2">
                    <h3 className="font-serif font-bold text-stone-800 text-base leading-snug">
                      {kit.title}
                    </h3>
                    <p className="text-xs text-stone-400 font-sans leading-relaxed">{kit.description}</p>
                  </div>

                  {/* Packing Tiers selector */}
                  <div className="space-y-2 bg-stone-50 p-2.5 rounded-xl border border-stone-100">
                    <span className="text-[9px] text-stone-400 font-sans font-bold uppercase tracking-wider block">Choice Box Packing</span>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleTierToggle(kit.id, 'standard')}
                        className={`flex-1 py-1.5 text-[10px] font-bold font-sans rounded-sm transition-all shadow-3xs border ${
                          chosenTier === 'standard'
                            ? 'bg-white border-saffron-400 text-saffron-700 font-extrabold'
                            : 'bg-transparent border-transparent text-stone-500 hover:text-stone-700'
                        }`}
                      >
                        Standard (Core)
                      </button>
                      <button
                        onClick={() => handleTierToggle(kit.id, 'premium')}
                        className={`flex-1 py-1.5 text-[10px] font-bold font-sans rounded-sm transition-all shadow-3xs border ${
                          chosenTier === 'premium'
                            ? 'bg-white border-saffron-400 text-saffron-700 font-extrabold'
                            : 'bg-transparent border-transparent text-stone-500 hover:text-stone-700'
                        }`}
                      >
                        Premium (+Idols)
                      </button>
                    </div>
                  </div>

                  {/* Raw list checklists */}
                  <div className="space-y-2">
                    <span className="text-[10px] font-sans font-bold uppercase tracking-wider text-saffron-600">Sample Inclusions ({kit.checklist.length} items)</span>
                    <div className="space-y-1.5 text-[11px] text-stone-500">
                      {kit.checklist.slice(0, 4).map((chk, i) => (
                        <div key={i} className="flex items-center gap-1.5">
                          <Check className="w-3 h-3 text-saffron-500 text-xs shrink-0 font-extrabold" />
                          <span className="truncate">{chk}</span>
                        </div>
                      ))}
                      {kit.checklist.length > 4 && (
                        <span className="text-[9px] font-semibold text-marigold-500 block pl-4 font-sans uppercase">
                          + {kit.checklist.length - 4} more pure sacred materials...
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Footer price & action checkout */}
                <div className="p-5 border-t border-stone-100 bg-linear-to-b from-white to-stone-50/50 flex justify-between items-center gap-3">
                  <div>
                    <span className="text-[10px] text-stone-400 block font-sans uppercase">Pay On Delivery</span>
                    <span className="font-serif font-extrabold text-lg text-saffron-700">₹{price}</span>
                  </div>
                  <button
                    onClick={() => {
                      setCheckoutKit(kit);
                      setSuccessReceipt(null);
                    }}
                    className="bg-saffron-600 hover:bg-saffron-700 text-white font-serif font-bold text-xs py-2 px-4 rounded-lg flex items-center gap-1 leading-normal transition-colors cursor-pointer shadow-3xs"
                  >
                    <span>Express COD</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* CHECKOUT POPUP WINDOW */}
      {checkoutKit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 shadow-xl" id="checkout-modal-overlay">
          <div className="absolute inset-0 bg-stone-900/60 backdrop-blur-xs" onClick={resetForm} />
          
          <div className="relative bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto border border-saffron-100 shadow-2xl z-10 p-6 md:p-8">
            <button 
              onClick={resetForm}
              className="absolute top-4 right-4 text-stone-400 hover:text-stone-600 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {!successReceipt ? (
              <form onSubmit={handleCheckoutSubmit} className="space-y-5" id="checkout-form-block">
                <div className="text-center space-y-1">
                  <span className="text-[10px] font-sans font-bold uppercase text-saffron-600 block">Patna Express Dispatch</span>
                  <h3 className="text-2xl font-cinzel font-bold text-stone-800 tracking-wide uppercase leading-tight">Order Pooja Samagri</h3>
                  <p className="text-stone-400 text-xs font-sans">
                    COD Shipment of *{checkoutKit.title}* ({boxTiers[checkoutKit.id] || 'standard'})
                  </p>
                </div>

                <div className="space-y-4 font-sans text-xs">
                  {/* Name field */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-stone-500 block">Recipient Full Name</label>
                    <input
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="e.g. Abhinav Pathak"
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-sm focus:outline-hidden focus:border-saffron-500"
                    />
                  </div>

                  {/* Phone field */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-stone-500 block">Mobile Contact No. (WhatsApp)</label>
                    <input
                      type="tel"
                      required
                      value={contactPhone}
                      onChange={(e) => setStatusPhone(e.target.value)}
                      placeholder="e.g. 75494 25216"
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-sm focus:outline-hidden focus:border-saffron-500"
                    />
                  </div>

                  {/* Patna Delivery Address */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-stone-500 block">Patna Shipping Address (Bailey Road / Boring Road etc.)</label>
                    <textarea
                      required
                      value={deliveryAddress}
                      onChange={(e) => setDeliveryAddress(e.target.value)}
                      placeholder="Provide detailed Lane coordinates, Apartment No., Patna, Bihar"
                      className="w-full bg-stone-50 border border-stone-200 rounded-lg py-2 px-3 text-sm focus:outline-hidden focus:border-saffron-500 h-20 resize-none"
                    ></textarea>
                  </div>
                </div>

                <div className="space-y-1 text-center bg-stone-150/50 p-2.5 rounded-lg font-sans">
                  <span className="text-[10px] text-stone-400 block">Pay On Cash Delivery (COD)</span>
                  <span className="font-serif font-extrabold text-saffron-600 text-lg">
                    ₹{getKitPrice(checkoutKit)}
                  </span>
                  <p className="text-[9px] text-stone-400">Standard Express Patna Courier: FREE OF COST</p>
                </div>

                <button
                  type="submit"
                  className="w-full bg-saffron-600 hover:bg-saffron-700 text-white font-serif font-bold py-3 px-6 rounded-lg transition-colors flex items-center justify-center gap-2 shadow-xs text-sm cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Generate Cash-On-Delivery Order</span>
                </button>
              </form>
            ) : (
              // Success receipts block
              <div className="space-y-6 text-center" id="order-success-receipt">
                <div className="w-14 h-14 bg-emerald-50 border border-emerald-200 rounded-full flex items-center justify-center text-emerald-600 mx-auto animate-bounce">
                  <Check className="w-8 h-8" />
                </div>
                
                <div className="space-y-1">
                  <h4 className="text-xl font-cinzel font-bold text-stone-800 uppercase">Order Dispatched!</h4>
                  <p className="text-xs text-stone-500 font-sans">Your shipment entry is saved secure in local browser storage ledger.</p>
                </div>

                {/* Simulated Invoice Card */}
                <div className="bg-stone-50 border border-dashed border-stone-200 rounded-xl p-5 text-left font-mono text-xs text-stone-600 space-y-3 shadow-inner">
                  <div className="flex justify-between">
                    <span>ORDER ID:</span>
                    <span className="font-bold text-stone-800">{successReceipt.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>MANDIR SELECTION:</span>
                    <span className="font-bold text-stone-800 uppercase">{successReceipt.kitTitle}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>PACKING SIZE:</span>
                    <span className="font-bold text-stone-800 uppercase">{successReceipt.packageType} SIZE</span>
                  </div>
                  <div className="flex justify-between">
                    <span>RECIPIENT NAME:</span>
                    <span className="font-bold text-stone-800">{successReceipt.customerName}</span>
                  </div>
                  <div className="flex flex-col">
                    <span>SHIPPING TO LOCATION:</span>
                    <span className="font-normal text-stone-600 text-[11px] leading-snug">{successReceipt.deliveryAddress}</span>
                  </div>
                  <div className="flex justify-between border-t border-stone-200 pt-2 text-stone-800 font-bold">
                    <span>TOTAL COD VALUE:</span>
                    <span className="text-saffron-600 text-sm">₹{successReceipt.price}</span>
                  </div>
                </div>

                <div className="bg-emerald-50 rounded-lg p-2.5 text-left flex gap-2 border border-emerald-100">
                  <Gift className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <p className="text-[10px] font-sans text-emerald-700 leading-normal">
                    <strong>Purity Guarantee:</strong> Sourced with utmost care, ensuring the elements are pure, unadulterated, and packaged hygienically by sacred Satvik hands in Bailey Road, Patna.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
                  <button
                    onClick={() => handleWhatsAppForward(successReceipt)}
                    className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white font-sans font-bold py-2.5 px-4 rounded-lg flex items-center justify-center gap-1.5 transition-colors shadow-2xs text-sm cursor-pointer"
                  >
                    <span>Forward to WhatsApp</span>
                  </button>
                  <button
                    onClick={resetForm}
                    className="flex-1 bg-stone-100 hover:bg-stone-200 text-stone-600 py-2.5 px-4 rounded-lg transition-colors text-sm font-semibold cursor-pointer"
                  >
                    <span>Close Window</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );

  // Quick helper to bypass typescript issue in form set State
  function setStatusPhone(val: string) {
    setContactPhone(val);
  }
};
