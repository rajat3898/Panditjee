/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Calendar, Sparkles, Clock, ArrowRight, Heart } from 'lucide-react';
import { CalendarEvent } from '../types';

interface VedicCalendarProps {
  onSelectRecommendedPuja: (pujaId: string) => void;
}

export const VedicCalendar: React.FC<VedicCalendarProps> = ({ onSelectRecommendedPuja }) => {
  const events: CalendarEvent[] = [
    {
      id: 'shivratri',
      title: 'Maha Shivratri Mahaparv',
      date: 'February 15, 2026',
      tithi: 'Magha Krishna Chaturdashi',
      description: 'The night of Shiva-Parvati celestial marriage. Performing Rudra sacrifice on this night dissolves heavy health complications and financial debts.',
      recommendedPuja: 'Maha Rudrabhishek Puja',
      recommendedPujaId: 'rudrabhishek'
    },
    {
      id: 'ramnavami',
      title: 'Shree Ram Navami Special',
      date: 'March 27, 2026',
      tithi: 'Chaitra Shukla Navami',
      description: 'The divine appearance of Maryada Purushottam Shree Ram. Perfect to establish righteous intelligence, peace, and career gains in Patna families.',
      recommendedPuja: 'Vighnaharta Ganesha Havan',
      recommendedPujaId: 'ganeshahavan'
    },
    {
      id: 'navratri',
      title: 'Shardiya Navratri Mahotsav',
      date: 'October 11, 2026 to October 20, 2026',
      tithi: 'Ashvin Shukla Pratipada to Dashami',
      description: 'The sacred ten nights celebrating Mother Durga\'s triumph. Invoking planetary controllers (Navgraha) during Navratri releases family barriers and restores health.',
      recommendedPuja: 'Navgrah Shanti Puja',
      recommendedPujaId: 'navgrahshanti'
    },
    {
      id: 'diwali',
      title: 'Deepavali Laxmi Puja & Ganeshotsav',
      date: 'November 8, 2026',
      tithi: 'Kartik Amavasya',
      description: 'The return of Shree Ram to Ayodhya. Perfect Purnima-equivalent alignment to purge debts and start fresh businesses by performing Satyanarayan rituals.',
      recommendedPuja: 'Sri Satyanarayan Puja & Katha',
      recommendedPujaId: 'satyanarayan'
    },
    {
      id: 'chhath',
      title: 'Bihari Kartik Chhath Puja Mahaparv',
      date: 'November 14, 2026 to November 17, 2026',
      tithi: 'Kartik Shukla Shasthi',
      description: 'The historic, most disciplined multi-day solar worship traditionally belonging to Bihar. Brings unparalleled health and child protections.',
      recommendedPuja: 'Chhath Puja Vrat Special Mahaparv',
      recommendedPujaId: 'chhathspecial'
    }
  ];

  return (
    <section className="py-12 bg-white" id="vedic-calendar-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 space-y-10">
        
        {/* Header Block */}
        <div className="text-center space-y-3">
          <span className="text-xs font-sans font-bold tracking-widest text-saffron-600 bg-saffron-50 border border-saffron-100 py-1 px-3.5 rounded-full uppercase inline-block font-sans">
            Auspicious Muhurtas
          </span>
          <h2 className="text-3xl md:text-4xl font-cinzel font-bold text-stone-800 tracking-tight">
            Vedic Holiday & Festival Calendar 2026
          </h2>
          <p className="text-sm md:text-base text-stone-500 font-sans max-w-2xl mx-auto leading-relaxed">
            Stay aligned with Hindu calendar tithis and plan your remedial sacrifices beforehand. Secure certified Patna Pandits aligned specifically to each festival.
          </p>
        </div>

        {/* Timeline Event Cards */}
        <div className="max-w-4xl mx-auto space-y-6" id="calendar-timeline">
          {events.map((ev, i) => (
            <div 
              key={ev.id} 
              className="bg-stone-50/50 border border-stone-200/60 rounded-2xl p-6 md:p-8 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 shadow-3xs"
              id={`calendar-event-${ev.id}`}
            >
              {/* Left Column: Date & Title */}
              <div className="space-y-2 flex-1">
                <div className="flex items-center gap-2">
                  <div className="px-2.5 py-1 bg-saffron-600 text-white rounded-lg flex items-center gap-1.5 shrink-0 shadow-3xs">
                    <Calendar className="w-3.5 h-3.5 text-white" />
                    <span className="text-[10px] font-mono font-bold tracking-wide">{ev.date}</span>
                  </div>
                  <span className="text-[10px] text-marigold-600 bg-marigold-50 border border-marigold-100 px-2 py-0.5 rounded-sm font-semibold font-sans uppercase">
                    {ev.tithi}
                  </span>
                </div>
                
                <h3 className="font-serif font-bold text-stone-800 text-base md:text-lg">
                  {ev.title}
                </h3>
                <p className="text-xs text-stone-500 font-sans leading-relaxed">{ev.description}</p>
              </div>

              {/* Right Column: Remedy Box Shortcut */}
              <div className="w-full sm:w-60 bg-white border border-saffron-100 p-4 rounded-xl flex flex-col gap-3 justify-between items-stretch shrink-0">
                <div>
                  <span className="text-[9px] text-stone-400 font-sans block uppercase font-bold tracking-wider">Recommended Ritual</span>
                  <span className="font-serif font-bold text-sm text-saffron-700 leading-tight block mt-0.5">{ev.recommendedPuja}</span>
                </div>
                
                <button
                  onClick={() => onSelectRecommendedPuja(ev.recommendedPujaId)}
                  className="w-full bg-saffron-50 hover:bg-saffron-100 border border-saffron-250 text-saffron-700 font-sans font-bold text-xs py-2 px-3 rounded-lg flex items-center justify-center gap-1 leading-normal transition-all cursor-pointer shadow-3xs"
                >
                  <span>Reserve Date Now</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
