/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useEffect } from 'react';
import { Compass, Calendar, ShoppingBag, Heart, MessageSquare, Phone, BookOpen, Clock, Sparkles } from 'lucide-react';

// Data Sets
import { PUJAS_DATA } from './data/pujas';
import { SAMAGRI_DATA } from './data/samagri';
import { TRAVEL_DESTINATIONS_DATA } from './data/travel';

// Components
import { Header } from './components/Header';
import { HistoryPanel } from './components/HistoryPanel';
import { AskPanditChat } from './components/AskPanditChat';
import { SpiritualTravel } from './components/SpiritualTravel';
import { PujaCatalogue } from './components/PujaCatalogue';
import { PoojaSamagriStore } from './components/PoojaSamagriStore';
import { VedicCalendar } from './components/VedicCalendar';
import { AboutUs } from './components/AboutUs';

// Types
import { Puja, Booking, Order, TravelInquiry } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);

  // Devotion Ledger Storage
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [travelInquiries, setTravelInquiries] = useState<TravelInquiry[]>([]);

  // Redirection states for shortcuts
  const [redirectPuja, setRedirectPuja] = useState<Puja | null>(null);

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const storedBookings = localStorage.getItem('pandit_bookings');
      if (storedBookings) setBookings(JSON.parse(storedBookings));

      const storedOrders = localStorage.getItem('pandit_orders');
      if (storedOrders) setOrders(JSON.parse(storedOrders));

      const storedTravels = localStorage.getItem('pandit_travels');
      if (storedTravels) setTravelInquiries(JSON.parse(storedTravels));
    } catch (e) {
      console.warn("Could not retrieve devotion ledgers from local storage.", e);
    }
  }, []);

  // Save triggers
  const handleAddBooking = (newBooking: Booking) => {
    const updated = [newBooking, ...bookings];
    setBookings(updated);
    localStorage.setItem('pandit_bookings', JSON.stringify(updated));
  };

  const handleAddOrder = (newOrder: Order) => {
    const updated = [newOrder, ...orders];
    setOrders(updated);
    localStorage.setItem('pandit_orders', JSON.stringify(updated));
  };

  const handleAddTravelInquiry = (newTravel: TravelInquiry) => {
    const updated = [newTravel, ...travelInquiries];
    setTravelInquiries(updated);
    localStorage.setItem('pandit_travels', JSON.stringify(updated));
  };

  // Cancel triggers
  const handleCancelBooking = (id: string) => {
    const updated = bookings.filter(b => b.id !== id);
    setBookings(updated);
    localStorage.setItem('pandit_bookings', JSON.stringify(updated));
  };

  const handleCancelOrder = (id: string) => {
    const updated = orders.filter(o => o.id !== id);
    setOrders(updated);
    localStorage.setItem('pandit_orders', JSON.stringify(updated));
  };

  const handleCancelTravel = (id: string) => {
    const updated = travelInquiries.filter(t => t.id !== id);
    setTravelInquiries(updated);
    localStorage.setItem('pandit_travels', JSON.stringify(updated));
  };

  // Redirect shortcut link from calendar or chat
  const handleSelectRecommendedPuja = (pujaId: string) => {
    const matchedPuja = PUJAS_DATA.find(p => p.id === pujaId);
    if (matchedPuja) {
      setRedirectPuja(matchedPuja);
      setActiveTab('pujas');
    }
  };

  const handleWhatsAppContact = () => {
    const text = encodeURIComponent("Pranam Pandit Jee! I want to consult about auspicious griha pravesh and family pujas in Patna.");
    window.open(`https://wa.me/917549425216?text=${text}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-stone-50 text-stone-800 flex flex-col font-sans selection:bg-saffron-200">
      
      {/* Platform Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenHistory={() => setIsHistoryOpen(true)}
        historyCounts={{
          bookings: bookings.length,
          orders: orders.length,
          travels: travelInquiries.length
        }}
      />

      {/* Main Content Layout switcher */}
      <main className="flex-1 w-full">
        {activeTab === 'home' && (
          <div className="space-y-12">
            
            {/* HERO BANNER BLOCK: Immersive Vedic auric layout */}
            <div className="relative bg-linear-to-b from-saffron-50 to-white pt-12 pb-16 px-4 md:px-8 border-b border-saffron-100">
              {/* Decorative floating aura background */}
              <div className="absolute top-10 left-10 w-48 h-48 bg-marigold-500/10 rounded-full blur-3xl animate-pulse"></div>
              <div className="absolute bottom-10 right-10 w-60 h-60 bg-saffron-500/10 rounded-full blur-3xl animate-pulse delay-500"></div>

              <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-10 items-center relative">
                {/* Hero slogan words */}
                <div className="lg:col-span-7 space-y-6 text-left">
                  <div className="flex items-center gap-1.5 border border-saffron-200 bg-saffron-100/60 py-1.5 px-4 rounded-full text-xs font-sans text-saffron-700 font-bold inline-flex">
                    <span className="w-2 h-2 rounded-full bg-saffron-600"></span>
                    <span>PROUDLY SERVING ALL OF PATNA, BIHAR, INDIA</span>
                  </div>
                  
                  <h1 className="text-4xl md:text-5xl lg:text-6xl font-cinzel font-black tracking-tight text-stone-900 leading-tight">
                    Bring Vedic Purity <span className="text-saffron-600 block sm:inline">To Your Doorstep</span>
                  </h1>
                  
                  <p className="text-stone-600 text-sm md:text-base leading-relaxed font-sans max-w-xl">
                    Discover Bihar's premier portal for booking highly-educated Vedic Pandits on Bailey Road, ordering pure, hand-packed Pooja boxes, and planning sacred pilgrimages. Connect with ancient wisdom.
                  </p>

                  <div className="flex flex-col sm:flex-row gap-3 pt-2">
                    <button
                      onClick={() => setActiveTab('pujas')}
                      className="bg-saffron-600 hover:bg-saffron-700 text-white font-serif font-bold py-3.5 px-6 rounded-lg transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer text-sm"
                    >
                      <Heart className="w-4 h-4 fill-white" />
                      <span>Book Auspicious Priest</span>
                    </button>
                    <button
                      onClick={handleWhatsAppContact}
                      className="bg-emerald-500 hover:bg-emerald-600 text-white font-sans font-bold py-3.5 px-6 rounded-lg transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer text-sm"
                    >
                      <span>💬 WhatsApp Support</span>
                    </button>
                  </div>
                </div>

                {/* Hero side image artwork */}
                <div className="lg:col-span-5 relative">
                  <div className="aspect-video sm:aspect-square w-full rounded-2xl overflow-hidden border border-saffron-150 shadow-lg relative">
                    <img
                      src="https://images.unsplash.com/photo-1616036740257-9449ea1f6605?q=80&w=800&auto=format&fit=crop"
                      alt="Ganges Sunrise Altar"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover rounded-2xl"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-stone-950/70 via-stone-950/10 to-transparent flex flex-col justify-end p-6">
                      <span className="text-[10px] text-marigold-400 font-cinzel font-bold tracking-widest block uppercase">EXPERIENCED SCHOLARS</span>
                      <h4 className="font-serif font-bold text-white text-lg mt-1">Sankalpas aligned to Gotra</h4>
                      <p className="text-xs text-stone-200 mt-1 font-sans">Traditional rituals led by highly qualified Pandits from Varanasi & Patna.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* QUICK START SERVICES SECTION: Bento-style Actions Grid with Astro Chat Side-by-Side */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* LEFT Column Actions list (lg:col-span-7) */}
              <div className="lg:col-span-7 space-y-6">
                <div className="text-left space-y-2">
                  <h3 className="font-cinzel text-xl md:text-2xl font-bold tracking-normal text-stone-800">
                    Holistic Spiritual Modules
                  </h3>
                  <p className="text-stone-500 text-xs sm:text-sm font-sans max-w-lg">
                    Select a service below to configure customizable Vedic offerings, organic samagri, or plan yatra rosters.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Bento Card 1: Puja bookings */}
                  <div 
                    onClick={() => setActiveTab('pujas')}
                    className="group bg-white p-6 rounded-2xl border border-saffron-100 hover:border-saffron-300 transition-all cursor-pointer text-left shadow-3xs hover:shadow-xs space-y-4"
                  >
                    <div className="w-10 h-10 bg-saffron-50 rounded-xl flex items-center justify-center text-saffron-600 transition-colors group-hover:bg-saffron-100">
                      <Heart className="w-5 h-5 fill-saffron-600" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="font-serif font-bold text-stone-800">10+ Sacred Pujas</h4>
                      <p className="text-xs text-stone-400 font-sans leading-relaxed">
                        From Griha Pravesh to Maha Rudrabhishek. Specify Gotra and Nakshatras.
                      </p>
                    </div>
                    <span className="text-xs font-semibold text-saffron-600 group-hover:translate-x-1 transition-all inline-flex items-center gap-1">
                      Browse Pujas <span>→</span>
                    </span>
                  </div>

                  {/* Bento Card 2: Store */}
                  <div 
                    onClick={() => setActiveTab('samagri')}
                    className="group bg-white p-6 rounded-2xl border border-saffron-100 hover:border-saffron-300 transition-all cursor-pointer text-left shadow-3xs hover:shadow-xs space-y-4"
                  >
                    <div className="w-10 h-10 bg-saffron-50 rounded-xl flex items-center justify-center text-saffron-600 transition-colors group-hover:bg-saffron-100">
                      <ShoppingBag className="w-5 h-5" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="font-serif font-bold text-stone-800">Organic Samagri Box</h4>
                      <p className="text-xs text-stone-400 font-sans leading-relaxed">
                        Curated complete puja boxes delivered cash-on-delivery in Patna.
                      </p>
                    </div>
                    <span className="text-xs font-semibold text-saffron-600 group-hover:translate-x-1 transition-all inline-flex items-center gap-1">
                      Order Samagri <span>→</span>
                    </span>
                  </div>

                  {/* Bento Card 3: Travels expanded */}
                  <div 
                    onClick={() => setActiveTab('travel')}
                    className="group bg-white p-6 rounded-2xl border border-saffron-100 hover:border-saffron-300 transition-all cursor-pointer text-left shadow-3xs hover:shadow-xs space-y-4 sm:col-span-2"
                  >
                    <div className="w-10 h-10 bg-saffron-50 rounded-xl flex items-center justify-center text-saffron-600 transition-colors group-hover:bg-saffron-100">
                      <Compass className="w-5 h-5" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="font-serif font-bold text-stone-800">Spiritual Traveling Options (20 Holy Sites!)</h4>
                      <p className="text-xs text-stone-400 font-sans leading-relaxed">
                        Exquisite custom itineraries for all 12 Jyotirlingas, major Char Dhams, and sacred temples like Tirupati Swamy and Ayodhya Lalla. Choose Budget, Premium, or Royal Luxury tiers.
                      </p>
                    </div>
                    <span className="text-xs font-semibold text-saffron-600 group-hover:translate-x-1 transition-all inline-flex items-center gap-1">
                      Explore Holy Yatras <span>→</span>
                    </span>
                  </div>
                </div>

                {/* Direct office Coordinates Banner */}
                <div className="bg-stone-100/80 border border-stone-200 p-5 rounded-2xl space-y-3 text-left font-sans">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-saffron-600">Patna Regional Office Center</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-stone-600">
                    <div>
                      <span className="text-stone-400 block pb-0.5">Primary Office Coordinate:</span>
                      <strong className="text-stone-700">Bailey Road, Patna, Bihar, India</strong>
                    </div>
                    <div>
                      <span className="text-stone-400 block pb-0.5">WhatsApp / Phone Hotline:</span>
                      <strong className="text-stone-700">+91 75494 25216</strong>
                    </div>
                  </div>
                </div>
              </div>

              {/* RIGHT Column Floating Astro Pandit Chat AI Widget (lg:col-span-5) */}
              <div className="lg:col-span-5 space-y-4">
                <div className="text-left space-y-1.5 px-1">
                  <h3 className="font-serif font-extrabold text-lg text-stone-800 flex items-center gap-1.5">
                    <span> आचार्य वेदान्त </span>
                    <span className="text-xs bg-saffron-100 text-saffron-700 font-sans font-bold px-2 py-0.5 rounded-full uppercase">Ask Pandit AI</span>
                  </h3>
                  <p className="text-stone-400 text-xs font-sans">Seek instant remedial rituals and calendar muhurtas via Gemini.</p>
                </div>
                <AskPanditChat 
                  pujas={PUJAS_DATA} 
                  onOpenBookingModal={(p) => {
                    setRedirectPuja(p);
                    setActiveTab('pujas');
                  }}
                />
              </div>

            </div>

            {/* CLIENT REVIEWS TESTIMONIALS */}
            <div className="bg-stone-100/50 py-12 border-t border-b border-stone-150">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 space-y-8 text-center">
                <div className="space-y-1">
                  <h3 className="font-cinzel text-xl md:text-2xl font-bold text-stone-800">Patna Devotees Devotional Testimonials</h3>
                  <p className="text-stone-400 text-xs font-sans">Heartwarming feedback from verified Patna households.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
                  <div className="p-6 bg-white rounded-xl border border-stone-150 shadow-3xs space-y-4">
                    <div className="flex gap-1 text-marigold-500 text-xs">★★★★★</div>
                    <p className="text-xs text-stone-500 font-sans italic leading-relaxed">
                      "We scheduled a Griha Pravesh Puja for our new flat on Bailey Road. The Pandit Jee arrived exactly on time, conducted detailed gotra sankalpas, and explained the Sanskrit mantras beautifully. Highly recommended!"
                    </p>
                    <strong className="text-xs text-stone-700 block font-sans">— Rajeev Ranjan, Patna</strong>
                  </div>
                  <div className="p-6 bg-white rounded-xl border border-stone-150 shadow-3xs space-y-4">
                    <div className="flex gap-1 text-marigold-500 text-xs">★★★★★</div>
                    <p className="text-xs text-stone-500 font-sans italic leading-relaxed">
                      "Ordering the Satyanarayan Complete Katha Box saved us hours. We didn't have to search Patna market lanes. The ingredients were pristine and packaged hygienically. Exceptional service."
                    </p>
                    <strong className="text-xs text-stone-700 block font-sans">— Swati Sinha, Boring Road, Patna</strong>
                  </div>
                  <div className="p-6 bg-white rounded-xl border border-stone-150 shadow-3xs space-y-4">
                    <div className="flex gap-1 text-marigold-500 text-xs">★★★★★</div>
                    <p className="text-xs text-stone-500 font-sans italic leading-relaxed">
                      "The Deoghar Baidyanath Jyotirlinga travel package was perfectly managed. The Premium ride took care of our elderly parents with VIP entrance and comfortable stay. We compiled coordinates via their WhatsApp desk easily."
                    </p>
                    <strong className="text-xs text-stone-700 block font-sans">— Dr. Abhinav K. Jha, Patna</strong>
                  </div>
                </div>
              </div>
            </div>

            {/* ACTION TRIGGERS AREA: Spiritual Teaser Banner */}
            <div className="max-w-4xl mx-auto px-4 pb-12">
              <div className="bg-linear-to-r from-saffron-600 to-marigold-600 text-white rounded-2xl p-8 text-center space-y-4 shadow-md">
                <span className="text-[10px] bg-white/20 text-white font-sans font-bold uppercase tracking-widest px-3 py-1 rounded-sm">
                  Sacred Yatras Teaser
                </span>
                <h3 className="text-2xl md:text-3xl font-cinzel font-bold text-white leading-normal uppercase">
                  Ready to visit a sacred Jyotirlinga or Moksha Dham?
                </h3>
                <p className="text-xs md:text-sm text-saffron-50 leading-relaxed font-sans max-w-lg mx-auto">
                  Over 20 destinations throughout India are prepared with satvik meals, helicopter charters, 4-star stays, and customized priests.
                </p>
                <div className="pt-2">
                  <button
                    onClick={() => setActiveTab('travel')}
                    className="bg-white hover:bg-stone-50 text-saffron-700 font-serif font-bold text-sm py-2.5 px-6 rounded-lg shadow-xs hover:shadow-md transition-all cursor-pointer"
                  >
                    View All 20 Destinations Now
                  </button>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* 2. RITUAL CATALOG TAB */}
        {activeTab === 'pujas' && (
          <PujaCatalogue
            pujas={PUJAS_DATA}
            onAddBooking={handleAddBooking}
            preSelectedPuja={redirectPuja}
            onClearPreSelected={() => setRedirectPuja(null)}
          />
        )}

        {/* 3. SAMAGRI COMMERCE TAB */}
        {activeTab === 'samagri' && (
          <PoojaSamagriStore
            samagriKits={SAMAGRI_DATA}
            onAddOrder={handleAddOrder}
          />
        )}

        {/* 4. EXPANDED PILGRIM YATRAS TAB */}
        {activeTab === 'travel' && (
          <SpiritualTravel
            destinations={TRAVEL_DESTINATIONS_DATA}
            onAddTravelInquiry={handleAddTravelInquiry}
          />
        )}

        {/* 5. VEDIC HOLIDAYS CALENDAR TAB */}
        {activeTab === 'calendar' && (
          <VedicCalendar
            onSelectRecommendedPuja={handleSelectRecommendedPuja}
          />
        )}

        {/* 6. BRAND STORY STORY ABOUT TAB */}
        {activeTab === 'about' && (
          <AboutUs />
        )}
      </main>

      {/* PLATFORM FOOTER */}
      <footer className="bg-stone-900 text-stone-400 text-xs py-10 border-t border-stone-850 font-sans" id="universal-footer">
        <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 md:grid-cols-4 gap-8 text-left">
          {/* Logo block */}
          <div className="space-y-3">
            <span className="text-xl font-cinzel text-white font-bold tracking-wide">
              Pandit<span className="text-marigold-500 font-serif">Jee</span>.in
            </span>
            <p className="text-stone-500 leading-relaxed text-[11px]">
              Patna's premier digital spiritual portal bringing authentic Varanasi and local shastris, organic materials, and sacred travel yatras to your doorstep.
            </p>
          </div>

          {/* Nav links */}
          <div className="space-y-2">
            <h4 className="text-white font-bold uppercase text-[10px] tracking-wider">Useful Channels</h4>
            <div className="flex flex-col gap-1.5 text-[11px]">
              <span onClick={() => setActiveTab('home')} className="hover:text-white cursor-pointer transition-colors">Digital Dashboard</span>
              <span onClick={() => setActiveTab('pujas')} className="hover:text-white cursor-pointer transition-colors">Book Certified Priests</span>
              <span onClick={() => setActiveTab('samagri')} className="hover:text-white cursor-pointer transition-colors">Curated Samagri Kits</span>
              <span onClick={() => setActiveTab('travel')} className="hover:text-white cursor-pointer transition-colors">Jyotirlinga & Dham Yatras</span>
            </div>
          </div>

          {/* Regional details */}
          <div className="space-y-2">
            <h4 className="text-white font-bold uppercase text-[10px] tracking-wider font-sans">Contact Center</h4>
            <div className="space-y-1 text-stone-500 leading-snug text-[11px]">
              <address className="not-italic">
                📍 Bailey Road, Patna,<br />
                Bihar, India - 800001
              </address>
              <div className="pt-1.5">
                <span>📱 WhatsApp Support:</span>
                <a href="tel:+917549425216" className="text-white hover:text-marigold-500 font-bold block">+91 75494 25216</a>
              </div>
            </div>
          </div>

          {/* Legal mentions */}
          <div className="space-y-2">
            <h4 className="text-white font-bold uppercase text-[10px] tracking-wider">Scriptural Notice</h4>
            <p className="text-stone-500 leading-relaxed text-[11px]">
              All mantras, Sankalpa structures, and abhishek parameters are executed strictly following Vedic traditions and local customs unique to Bihar. Purity is guaranteed.
            </p>
          </div>
        </div>

        {/* Bar strip */}
        <div className="max-w-7xl mx-auto px-4 md:px-8 border-t border-stone-850 mt-8 pt-6 flex flex-col md:flex-row justify-between text-[11px] text-stone-600 gap-4">
          <p>© 2026 PanditJee.in. Sourced and handled hygienically. All Rights Reserved.</p>
          <p>Made with devotion at Bailey Road, Patna, Bihar.</p>
        </div>
      </footer>

      {/* DEVOTION LEDGER HISTORIC DRAWER */}
      <HistoryPanel
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        bookings={bookings}
        orders={orders}
        travelInquiries={travelInquiries}
        onCancelBooking={handleCancelBooking}
        onCancelOrder={handleCancelOrder}
        onCancelTravel={handleCancelTravel}
      />

    </div>
  );
}
